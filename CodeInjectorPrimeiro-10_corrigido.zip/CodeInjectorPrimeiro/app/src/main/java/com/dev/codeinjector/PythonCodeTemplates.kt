package com.dev.codeinjector

/**
 * Modelos de código do editor. Marcadores invisíveis definem o cursor ou selecionam o primeiro placeholder após a inserção.
 * Este arquivo não depende de Android/Compose para que a lógica possa ser testada isoladamente.
 */
data class TemplateInsertion(
    val text: String,
    val cursorBack: Int,
    /** Distâncias a partir do fim do texto inserido; quando presentes, selecionam um placeholder para substituição. */
    val selectionStartBack: Int? = null,
    val selectionEndBack: Int? = null
)

data class PythonCodeTemplate(
    val trigger: String,
    val label: String,
    val group: String,
    private val markedSource: String
) {
    fun insertion(): TemplateInsertion {
        val raw = markedSource
        fun cleanedOffset(rawOffset: Int): Int = raw.substring(0, rawOffset)
            .replace(PythonCodeTemplates.CURSOR_MARKER, "")
            .replace(PythonCodeTemplates.SELECTION_START_MARKER, "")
            .replace(PythonCodeTemplates.SELECTION_END_MARKER, "")
            .length

        val cursorIndex = raw.indexOf(PythonCodeTemplates.CURSOR_MARKER)
        val selectionStartIndex = raw.indexOf(PythonCodeTemplates.SELECTION_START_MARKER)
        val selectionEndIndex = raw.indexOf(PythonCodeTemplates.SELECTION_END_MARKER)
        val clean = raw.replace(PythonCodeTemplates.CURSOR_MARKER, "")
            .replace(PythonCodeTemplates.SELECTION_START_MARKER, "")
            .replace(PythonCodeTemplates.SELECTION_END_MARKER, "")
        val selected = selectionStartIndex >= 0 && selectionEndIndex > selectionStartIndex
        val cursorOffset = when {
            selected -> cleanedOffset(selectionEndIndex)
            cursorIndex >= 0 -> cleanedOffset(cursorIndex)
            else -> clean.length
        }
        return TemplateInsertion(
            text = clean,
            cursorBack = (clean.length - cursorOffset).coerceIn(0, clean.length),
            selectionStartBack = if (selected) clean.length - cleanedOffset(selectionStartIndex) else null,
            selectionEndBack = if (selected) clean.length - cleanedOffset(selectionEndIndex) else null
        )
    }
}

data class TemplateCompletion(
    val label: String,
    val insertion: TemplateInsertion,
    val isTemplate: Boolean
)

object PythonCodeTemplates {
    internal const val CURSOR_MARKER = "\uE000"
    internal const val SELECTION_START_MARKER = "\uE001"
    internal const val SELECTION_END_MARKER = "\uE002"
    private const val SELECT_START = SELECTION_START_MARKER
    private const val SELECT_END = SELECTION_END_MARKER
    private fun t(trigger: String, label: String, group: String, source: String) =
        PythonCodeTemplate(trigger, label, group, source)

    /** Modelos completos acessíveis pela barra de atalhos e pelo menu Snippets. */
    val all: List<PythonCodeTemplate> = listOf(
        // Estruturas básicas da linguagem
        t("def", "def — função", "Python", "def ${SELECT_START}name${SELECT_END}():\n    return"),
        t("class", "class — classe com método", "Python", "class ${SELECT_START}Name${SELECT_END}():\n    def method(self):\n        pass"),
        t("if", "if — condição", "Python", "if ${SELECT_START}condition${SELECT_END}:\n    pass"),
        t("elif", "elif — condição alternativa", "Python", "elif ${SELECT_START}condition${SELECT_END}:\n    pass"),
        t("else", "else — bloco alternativo", "Python", "else:\n    pass$CURSOR_MARKER"),
        t("for", "for — laço", "Python", "for ${SELECT_START}item${SELECT_END} in iterable:\n    pass"),
        t("while", "while — laço condicional", "Python", "while ${SELECT_START}condition${SELECT_END}:\n    pass"),
        t("try", "try/except — tratamento de erro", "Python", "try:\n    pass$CURSOR_MARKER\nexcept Exception as error:\n    print(error)"),
        t("except", "except — capturar exceção", "Python", "except ${SELECT_START}Exception${SELECT_END} as error:\n    print(error)"),
        t("finally", "finally — limpeza garantida", "Python", "finally:\n    pass$CURSOR_MARKER"),
        t("with", "with open — arquivo", "Python", "with open(\"${SELECT_START}file.txt${SELECT_END}\", \"r\", encoding=\"utf-8\") as file:\n    content = file.read()"),
        t("async", "async def — função assíncrona", "Python", "async def ${SELECT_START}name${SELECT_END}():\n    return"),
        t("asyncfor", "async for — laço assíncrono", "Python", "async for ${SELECT_START}item${SELECT_END} in iterable:\n    pass"),
        t("asyncwith", "async with — gerenciador assíncrono", "Python", "async with ${SELECT_START}resource${SELECT_END} as value:\n    pass"),
        t("match", "match/case — correspondência", "Python", "match ${SELECT_START}value${SELECT_END}:\n    case _:\n        pass"),
        t("case", "case — opção match", "Python", "case ${SELECT_START}value${SELECT_END}:\n    pass"),
        t("main", "main — ponto de entrada", "Python", "def main():\n    pass\n\nif __name__ == \"__main__\":\n    main()$CURSOR_MARKER"),
        t("import", "import — importar módulo", "Python", "import ${SELECT_START}module${SELECT_END}"),
        t("from", "from … import …", "Python", "from ${SELECT_START}module${SELECT_END} import name"),
        t("return", "return — devolver valor", "Python", "return ${SELECT_START}value${SELECT_END}"),
        t("yield", "yield — produzir valor", "Python", "yield ${SELECT_START}value${SELECT_END}"),
        t("break", "break — sair do laço", "Python", "break$CURSOR_MARKER"),
        t("continue", "continue — próxima iteração", "Python", "continue$CURSOR_MARKER"),
        t("pass", "pass — bloco vazio", "Python", "pass$CURSOR_MARKER"),
        t("global", "global — variável global", "Python", "global ${SELECT_START}name${SELECT_END}"),
        t("nonlocal", "nonlocal — variável externa", "Python", "nonlocal ${SELECT_START}name${SELECT_END}"),
        t("del", "del — remover nome/item", "Python", "del ${SELECT_START}target${SELECT_END}"),
        t("await", "await — aguardar operação", "Python", "await ${SELECT_START}expression${SELECT_END}"),
        t("raise", "raise — lançar exceção", "Python", "raise Exception(\"message\")$CURSOR_MARKER"),
        t("assert", "assert — verificar condição", "Python", "assert condition$CURSOR_MARKER, \"message\""),
        t("lambda", "lambda — função curta", "Python", "lambda ${SELECT_START}value${SELECT_END}: expression"),
        t("decorator", "Decorador de função", "Python", "@decorator\ndef ${SELECT_START}name${SELECT_END}():\n    pass"),
        t("contextmanager", "@contextmanager — recurso com limpeza", "Python", "from contextlib import contextmanager\n\n@contextmanager\ndef ${SELECT_START}managed_resource${SELECT_END}():\n    resource = acquire()\n    try:\n        yield resource\n    finally:\n        release(resource)"),
        t("property", "@property — propriedade", "Python", "@property\ndef name(self):\n    return self._name$CURSOR_MARKER"),
        t("setter", "@name.setter — alterar propriedade", "Python", "@name.setter\ndef name(self, value$CURSOR_MARKER):\n    self._name = value"),
        t("dataclass", "@dataclass — classe de dados", "Python", "from dataclasses import dataclass\n\n@dataclass\nclass Name:\n    value: str$CURSOR_MARKER"),
        t("listcomp", "Compreensão de lista", "Python", "[item$CURSOR_MARKER for item in iterable]"),
        t("dictcomp", "Compreensão de dicionário", "Python", "{key$CURSOR_MARKER: value for key, value in items}"),
        t("test", "Teste pytest", "Python", "def test_name$CURSOR_MARKER():\n    assert actual == expected"),
        t("docstring", "Docstring de função", "Python", "\"\"\"Description.$CURSOR_MARKER\n\nArgs:\n    value: Description.\n\nReturns:\n    Description.\n\"\"\""),

        // Frameworks gráficos: programas mínimos de exemplo, não apenas uma linha de import
        t("kivy", "Kivy — aplicação completa", "Frameworks", "from kivy.app import App\nfrom kivy.uix.label import Label\n\nclass MyApp$CURSOR_MARKER(App):\n    def build(self):\n        return Label(text=\"Hello, World!\")\n\nif __name__ == \"__main__\":\n    MyApp().run()"),
        t("kivyimports", "Kivy — imports comuns", "Frameworks", "from kivy.app import App\nfrom kivy.uix.label import Label\nfrom kivy.uix.boxlayout import BoxLayout$CURSOR_MARKER"),
        t("pygame", "Pygame — loop principal", "Frameworks", "import pygame\nimport sys\n\npygame.init()\nscreen = pygame.display.set_mode((800, 600))\npygame.display.set_caption(\"My Game\")\nclock = pygame.time.Clock()\nrunning = True\n\nwhile running:\n    for event in pygame.event.get():\n        if event.type == pygame.QUIT:\n            running = False\n\n    screen.fill((30, 30, 30))\n    pygame.display.flip()\n    clock.tick(60)\n\npygame.quit()$CURSOR_MARKER"),
        t("pygameimports", "Pygame — imports comuns", "Frameworks", "import pygame$CURSOR_MARKER\nimport sys\nfrom pygame.locals import QUIT"),
        t("tkinter", "Tkinter — janela e widget", "Frameworks", "import tkinter as tk\nfrom tkinter import ttk\n\nroot = tk.Tk()\nroot.title(\"My App\")\nroot.geometry(\"400x300\")\n\nlabel = ttk.Label(root, text=\"Hello, world!\")\nlabel.pack(padx=20, pady=20)\n\nroot.mainloop()$CURSOR_MARKER"),
        t("tkimports", "Tkinter — imports comuns", "Frameworks", "import tkinter as tk\nfrom tkinter import ttk, messagebox$CURSOR_MARKER"),
        t("pyglet", "Pyglet — janela OpenGL", "Frameworks", "import pyglet\n\nwindow = pyglet.window.Window(width=800, height=600, caption=\"My App\")\n\n@window.event\ndef on_draw():\n    window.clear()$CURSOR_MARKER\n\npyglet.app.run()"),
        t("pygletimports", "Pyglet — imports comuns", "Frameworks", "import pyglet$CURSOR_MARKER\nfrom pyglet.window import key"),
        t("arcade", "Arcade — jogo com classe", "Frameworks", "import arcade\n\nSCREEN_WIDTH = 800\nSCREEN_HEIGHT = 600\n\nclass MyGame$CURSOR_MARKER(arcade.Window):\n    def __init__(self):\n        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, \"My Game\")\n\n    def on_draw(self):\n        self.clear()\n\n    def on_update(self, delta_time):\n        pass\n\nif __name__ == \"__main__\":\n    game = MyGame()\n    arcade.run()"),
        t("arcadeimports", "Arcade — imports comuns", "Frameworks", "import arcade$CURSOR_MARKER"),
        t("pyqt", "PyQt6 — janela básica", "Frameworks", "import sys\nfrom PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel\n\napp = QApplication(sys.argv)\nwindow = QWidget()\nwindow.setWindowTitle(\"My App\")\nlayout = QVBoxLayout(window)\nlayout.addWidget(QLabel(\"Hello, world!\"))\nwindow.resize(400, 300)\nwindow.show()\n\nsys.exit(app.exec())$CURSOR_MARKER"),
        t("pyqtimports", "PyQt6 — imports comuns", "Frameworks", "from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel$CURSOR_MARKER"),
        t("pyside", "PySide6 — janela básica", "Frameworks", "import sys\nfrom PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel\n\napp = QApplication(sys.argv)\nwindow = QWidget()\nwindow.setWindowTitle(\"My App\")\nlayout = QVBoxLayout(window)\nlayout.addWidget(QLabel(\"Hello, world!\"))\nwindow.resize(400, 300)\nwindow.show()\n\nsys.exit(app.exec())$CURSOR_MARKER"),
        t("pysideimports", "PySide6 — imports comuns", "Frameworks", "from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel$CURSOR_MARKER"),
    )

    private val importModules = listOf(
        "arcade", "asyncio", "collections", "datetime", "functools", "json", "kivy", "logging",
        "math", "os", "pathlib", "pygame", "pyglet", "PyQt6", "PySide6", "random", "re", "requests", "subprocess",
        "sys", "threading", "time", "tkinter", "typing"
    )
    private val fromModules = importModules + listOf(
        "kivy.app", "kivy.uix.label", "kivy.uix.boxlayout", "pygame.locals", "tkinter.ttk",
        "tkinter.messagebox", "PyQt6.QtWidgets", "PySide6.QtWidgets"
    )
    private val importedNames = mapOf(
        "kivy.app" to listOf("App"),
        "kivy.uix.label" to listOf("Label"),
        "kivy.uix.boxlayout" to listOf("BoxLayout"),
        "pygame.locals" to listOf("QUIT", "KEYDOWN", "KEYUP", "K_ESCAPE"),
        "tkinter" to listOf("Tk", "StringVar", "IntVar", "BooleanVar", "END"),
        "tkinter.ttk" to listOf("Button", "Entry", "Frame", "Label", "Combobox", "Treeview"),
        "tkinter.messagebox" to listOf("showinfo", "showwarning", "showerror", "askyesno"),
        "PyQt6.QtWidgets" to listOf("QApplication", "QWidget", "QVBoxLayout", "QHBoxLayout", "QLabel", "QPushButton", "QLineEdit"),
        "PySide6.QtWidgets" to listOf("QApplication", "QWidget", "QVBoxLayout", "QHBoxLayout", "QLabel", "QPushButton", "QLineEdit")
    )
    private val fromImportContext = Regex("^\\s*from\\s+([\\w.]+)\\s+import\\s*$")

    fun isImportContext(lineBeforePrefix: String): Boolean =
        Regex("^\\s*import\\s*$").matches(lineBeforePrefix) ||
            Regex("^\\s*from\\s*$").matches(lineBeforePrefix) ||
            fromImportContext.matches(lineBeforePrefix)

    /** Completa nomes de módulos e símbolos importados; nos outros contextos sugere blocos completos. */
    fun suggestions(prefix: String, lineBeforePrefix: String): List<TemplateCompletion> {
        if (prefix.isBlank()) return emptyList()
        val fromImport = fromImportContext.find(lineBeforePrefix)
        if (Regex("^\\s*import\\s*$").matches(lineBeforePrefix) || Regex("^\\s*from\\s*$").matches(lineBeforePrefix) || fromImport != null) {
            val pool = when {
                fromImport != null -> importedNames[fromImport.groupValues[1]] ?: listOf("name")
                Regex("^\\s*from\\s*$").matches(lineBeforePrefix) -> fromModules
                else -> importModules
            }
            return pool.asSequence()
                .filter { it.startsWith(prefix, ignoreCase = true) }
                .distinct()
                .take(12)
                .map { TemplateCompletion(it, TemplateInsertion(it, 0), false) }
                .toList()
        }
        return all.asSequence()
            .filter { it.trigger.startsWith(prefix, ignoreCase = true) }
            .sortedWith(compareBy<PythonCodeTemplate>({ if (it.trigger.equals(prefix, true)) 0 else 1 }, { it.trigger.length }, { it.label }))
            .take(14)
            .map { template ->
                val shortcutLabel = if (template.group == "Python") template.trigger else template.label
                TemplateCompletion(shortcutLabel, template.insertion(), true)
            }
            .toList()
    }
}
