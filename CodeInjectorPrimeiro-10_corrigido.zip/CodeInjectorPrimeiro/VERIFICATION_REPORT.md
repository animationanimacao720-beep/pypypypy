# Relatório de verificação — Termux:X11 (correções de auditoria)

## Correções aplicadas nesta revisão

- Corrigido o tipo inferido no leitor de fontes do projeto em `TermuxX11Runner.kt`: o ramo de arquivo acima de 2 MB retorna `null`, para que a expressão tenha tipo `String?` consistente.
- Corrigidos os dois acumuladores de tamanho em `TermuxWorkspace.kt`, convertendo `ByteArray.size` (`Int`) para `Long`.
- O detector agora mascara strings Python simples/triplas e comentários antes de procurar imports, reduzindo falsos positivos em docstrings/comentários.
- O detector agora reconhece imports depois de ponto e vírgula, como `import os; import pygame`.
- Foram adicionados casos de regressão aos testes executáveis e aos testes JVM para os erros encontrados na auditoria.
- O verificador estático inclui guardas para evitar a regressão dos três bloqueadores Kotlin e dos dois defeitos do detector.

## Verificações disponíveis nesta revisão

Executar na raiz do projeto:

```sh
python tools/verify_project.py
python -m py_compile app/src/main/python/ci_runner.py
sh tools/run_detector_tests.sh
```

Resultado local desta revisão: verificador estático aprovado; sintaxe Python aprovada; 27 casos individuais do detector e 2 casos de projeto aprovados. As expressões Kotlin que causaram os três bloqueadores foram testadas também em um snippet mínimo com `kotlinc`.

## Limites

Não foi possível executar `gradle testDebugUnitTest` ou `gradle assembleDebug` neste ambiente, porque não há Gradle nem Android SDK instalados e a distribuição Gradle não pôde ser baixada (sem resolução de DNS). Portanto, a compilação completa Android permanece **não confirmada** e precisa ser verificada pelo workflow do GitHub Actions.

Os testes estáticos não substituem um teste no dispositivo. Ainda não foi validada a execução real do Termux:X11, nem a instalação/funcionamento de cada framework gráfico no celular.
