# CodeInjector — IDE Python (Chaquopy)

## O que mudou
- Removidos os runners antigos de Java, Termux e Judge0, que não eram usados pela IDE. A execução Python comum continua via Chaquopy.
- Novo: `PyRunner` (CPython via Chaquopy), `SyntaxAnalyzer` (CPython `compile()` + scanner rápido),
  `KeyboardSuggestionBar`, `FileExplorerSidebar`, `CodeEditorScreen` reescrito, `app/src/main/python/ci_runner.py`.
- Removidos também: `TextInjectorService`, serviço de acessibilidade, injeção de texto e sincronização/atalho do CodeAssist.
- Mantidos: `Session`, `Project` (SAF), `KeyBindingHandler`, snippets.
- Novidades: botão executar flutuante (menu ⋮), "↻ Repetir" no console, barra inferior só com tab, desfazer/refazer, setas, copiar e colar, guias de indentação (estilo Godot, ligam/desligam no menu ⋮), indentação só com tabs, seleção por arrasto e botões Tudo/Cortar/Apagar, e gerenciador de arquivos em árvore (arraste da borda esquerda ou toque em ☰).

## Atalhos (teclado físico)
Ctrl+R / F5 rodar · Shift+F5 / Ctrl+. parar · Ctrl+S salvar · Ctrl+F buscar · Ctrl+H substituir · Ctrl+B painel de arquivos
Ctrl+/ comentar · Ctrl+D duplicar linha · Alt+↑/↓ mover linha · Ctrl+G ir p/ linha · Ctrl+N/W/O aba nova/fechar/abrir

## Fontes
JetBrains Mono já vem em `app/src/main/assets/fonts/`. Para Fira Code, coloque `FiraCode-Regular.ttf` na mesma pasta
(o app detecta sozinho; menu ⋮ → Fonte).

## Build
Chaquopy é um plugin do Gradle: compile com Android Studio / Gradle (não só com o build interno do CodeAssist).
Python 3.11 no PATH do PC de build é opcional (só gera .pyc; sem ele o build segue com aviso).
Arquivos lidos/gravados pelos scripts ficam em `files/py_workspace` (as abas .py abertas são copiadas para lá para `import` funcionar).

## Como gerar o APK (Gradle)
**GitHub Actions (só pelo celular):** crie um repositório, envie esta pasta (a raiz do repo deve conter `settings.gradle.kts`),
abra a aba Actions → "Build APK" → Run workflow → baixe o artefato `CodeInjector-debug-apk` e instale.
**Android Studio:** File → Open na pasta, aguarde o sync e rode `assembleDebug` (precisa de JDK 17 e SDK 34).

## Novidades (v2.1)
- Console: Copiar, Limpar, ↻ Repetir, cores ANSI, tempo de execução e código de saída.
- Buscar no projeto e Símbolos (funções/classes) no menu ⋮.
- Dobrar blocos (seta no gutter) e breakpoints (toque no número da linha) com depurador simples: Continuar / Passo / variáveis.
- Linter com avisos amarelos: import e variável local não usados.
- Marcadores de tab (→), guias de indentação, indentação só com tabs.
- "Abrir com" para .py/texto de outros apps e Compartilhar.
- Entradas prontas para input() (menu ⋮).
- Biblioteca `requests` incluída (pip no build.gradle.kts; descomente numpy se quiser, mas o APK fica bem maior).

## Novidades (v2.2)
- Auto-completar de membros depois do ponto (`texto.`, `lista.`, `os.`, `self.`, objetos das suas classes), inferido do próprio código.
- Terminal Python (REPL) no console: botão "Terminal"; mantém variáveis entre comandos; blocos terminam com linha em branco.
  Com o terminal ligado, as variáveis do último script rodado ficam disponíveis nele (como `python -i`).


## Frameworks gráficos e Termux:X11

- O runner redireciona imports reconhecidos de Kivy, Pygame, Tkinter, Pyglet, Arcade e Qt (PyQt5/PyQt6/PySide2/PySide6) para o Python do Termux ou a distro PRoot configurada. Scripts comuns continuam no Chaquopy.
- O fluxo usa o diretório do projeto e a escolha do arquivo principal, preserva recursos/subpastas por execução direta ou por uma pasta-ponte SAF, registra `stdout.log`/`stderr.log` para saída incremental no console e tenta associar tracebacks do arquivo principal à linha do editor.
- O menu `⋮` inclui Diagnosticar Termux/X11, Configurar pasta compartilhada Termux, Executar arquivo principal do projeto, Instalar biblioteca Python (para imports faltantes), Ajustes de tela e Abrir Termux:X11 em tela dividida.
- É necessário o APK Termux:X11 **e** o pacote `termux-x11-nightly` no Termux. Conceda `com.termux.permission.RUN_COMMAND` ao CodeInjector e habilite `allow-external-apps=true` em `~/.termux/termux.properties`. Consulte [`docs/TERMUX_X11_SETUP.md`](docs/TERMUX_X11_SETUP.md).
- O modo de cópia por SAF tem limites defensivos de 4.000 arquivos e 180 MB por execução e exclui caches/builds comuns. A pasta-ponte deve estar no armazenamento compartilhado e fora do projeto. Projetos já salvos em armazenamento compartilhado são executados diretamente, sem cópia.
- A tela dividida é solicitada ao Android, mas não garantida pelo fabricante/sistema. Ajustes X11 variam conforme a versão do pacote instalado.
- Breakpoints e depuração passo a passo continuam exclusivos do Chaquopy: a execução gráfica ocorre num processo Python externo.

Siga [`docs/TERMUX_X11_SETUP.md`](docs/TERMUX_X11_SETUP.md) para configuração, diagnóstico e solução de problemas.

### Limitações de validação

Esta entrega foi revisada estaticamente e o ZIP/manifesto são verificados durante a preparação. Não declarar como validada a compilação Android, a instalação do APK, downloads em rede no aparelho nem a abertura real de janelas X11: esses testes exigem Android/Gradle/Termux no dispositivo. Para compilar, abra a pasta no Android Studio com JDK 17 e SDK Android 34 ou use o workflow GitHub Actions existente.


## Testes e integridade da compilação

O workflow do GitHub executa `gradle testDebugUnitTest` antes de compilar o APK. Os testes JVM verificam a detecção de frameworks em múltiplos arquivos Python, prioridade entre frameworks e falsos positivos comuns. O artefato do workflow inclui `source-integrity-sha256.txt`, com SHA-256 dos arquivos de fonte/configuração usados na compilação. Isso ajuda a comparar a versão compilada; não substitui testes gráficos no aparelho.

A detecção de framework considera o script principal, abas abertas e arquivos `.py` encontrados no projeto. Ela é uma heurística estática de imports, não uma análise completa do grafo de imports Python: imports dinâmicos (`importlib`, `__import__`) e código executado condicionalmente podem exigir seleção manual ou não ser detectados.
