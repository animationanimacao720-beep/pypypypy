package com.dev.codeinjector

import android.content.Context
import android.view.KeyEvent as AndroidKeyEvent
import org.json.JSONArray
import org.json.JSONObject

/** Uma combinação configurada pelo usuário para uma ação da IDE. */
data class CustomShortcutBinding(
    val actionId: String,
    val keyCode: Int,
    val ctrl: Boolean,
    val alt: Boolean,
    val shift: Boolean,
    val meta: Boolean
) {
    fun matches(keyCode: Int, ctrl: Boolean, alt: Boolean, shift: Boolean, meta: Boolean): Boolean =
        this.keyCode == keyCode && this.ctrl == ctrl && this.alt == alt && this.shift == shift && this.meta == meta

    fun display(): String = buildList {
        if (ctrl) add("Ctrl")
        if (alt) add("Alt")
        if (shift) add("Shift")
        if (meta) add("Meta")
        add(AndroidKeyEvent.keyCodeToString(keyCode).removePrefix("KEYCODE_").replace('_', ' '))
    }.joinToString("+")
}

data class ShortcutAction(val id: String, val label: String, val category: String)

/** Ações que podem receber uma combinação de teclas personalizada. */
object ShortcutCatalog {
    val actions = listOf(
        ShortcutAction("run", "Executar script", "Execução"),
        ShortcutAction("stop", "Parar execução", "Execução"),
        ShortcutAction("runProjectMain", "Executar arquivo principal do projeto", "Execução"),
        ShortcutAction("save", "Salvar", "Arquivos"),
        ShortcutAction("saveAs", "Salvar como", "Arquivos"),
        ShortcutAction("saveAll", "Salvar todas as abas", "Arquivos"),
        ShortcutAction("openFile", "Abrir arquivo", "Arquivos"),
        ShortcutAction("newTab", "Nova aba", "Abas"),
        ShortcutAction("closeTab", "Fechar aba atual", "Abas"),
        ShortcutAction("nextTab", "Próxima aba", "Abas"),
        ShortcutAction("previousTab", "Aba anterior", "Abas"),
        ShortcutAction("undo", "Desfazer", "Edição"),
        ShortcutAction("redo", "Refazer", "Edição"),
        ShortcutAction("copy", "Copiar", "Edição"),
        ShortcutAction("cut", "Recortar", "Edição"),
        ShortcutAction("paste", "Colar", "Edição"),
        ShortcutAction("selectLine", "Selecionar linha", "Edição"),
        ShortcutAction("selectAll", "Selecionar tudo", "Edição"),
        ShortcutAction("deleteLine", "Excluir linha", "Edição"),
        ShortcutAction("duplicateLine", "Duplicar linha", "Edição"),
        ShortcutAction("moveLineUp", "Mover linha para cima", "Edição"),
        ShortcutAction("moveLineDown", "Mover linha para baixo", "Edição"),
        ShortcutAction("indent", "Indentar", "Edição"),
        ShortcutAction("outdent", "Desindentar", "Edição"),
        ShortcutAction("toggleComment", "Comentar / descomentar", "Edição"),
        ShortcutAction("format", "Formatar código", "Edição"),
        ShortcutAction("convertTabs", "Converter espaços em tabs", "Edição"),
        ShortcutAction("find", "Buscar", "Navegação"),
        ShortcutAction("replace", "Buscar e substituir", "Navegação"),
        ShortcutAction("findNext", "Próxima ocorrência", "Navegação"),
        ShortcutAction("goToLine", "Ir para linha", "Navegação"),
        ShortcutAction("toggleSidebar", "Mostrar / ocultar explorador", "Interface"),
        ShortcutAction("toggleConsole", "Mostrar / ocultar console", "Interface"),
        ShortcutAction("toggleSnippets", "Abrir snippets", "Interface"),
        ShortcutAction("togglePresets", "Entradas prontas para input()", "Interface"),
        ShortcutAction("showSymbols", "Mostrar funções e classes", "Navegação"),
        ShortcutAction("searchProject", "Buscar no projeto", "Navegação"),
        ShortcutAction("importGitHub", "Importar projeto do GitHub", "Projeto"),
        ShortcutAction("installPackage", "Instalar biblioteca Python (Termux)", "Projeto"),
        ShortcutAction("termuxDiagnostics", "Diagnosticar Termux / X11", "Ambiente gráfico"),
        ShortcutAction("showX11Settings", "Ajustes do Termux:X11", "Ambiente gráfico"),
        ShortcutAction("setupSharedFolder", "Configurar pasta compartilhada Termux", "Ambiente gráfico"),
        ShortcutAction("openTermuxX11", "Abrir Termux:X11", "Ambiente gráfico"),
        ShortcutAction("openTermuxX11Split", "Abrir Termux:X11 em tela dividida", "Ambiente gráfico"),
        ShortcutAction("toggleTabMarks", "Alternar marcadores de tabs", "Editor"),
        ShortcutAction("toggleGuides", "Alternar guias de indentação", "Editor"),
        ShortcutAction("toggleWrap", "Alternar quebra de linha", "Editor"),
        ShortcutAction("toggleFloatRun", "Alternar botão Executar flutuante", "Editor"),
        ShortcutAction("increaseFont", "Aumentar fonte", "Editor"),
        ShortcutAction("decreaseFont", "Diminuir fonte", "Editor"),
        ShortcutAction("toggleAutoSave", "Alternar salvamento automático", "Editor"),
        ShortcutAction("foldAll", "Dobrar todos os blocos", "Editor"),
        ShortcutAction("unfoldAll", "Desdobrar todos os blocos", "Editor"),
        ShortcutAction("toggleBreakpoint", "Alternar breakpoint na linha atual", "Depuração"),
        ShortcutAction("clearBreakpoints", "Limpar breakpoints", "Depuração"),
        ShortcutAction("debugContinue", "Continuar depuração", "Depuração"),
        ShortcutAction("debugStep", "Avançar uma etapa na depuração", "Depuração"),
        ShortcutAction("clearConsole", "Limpar console", "Console"),
        ShortcutAction("toggleTerminalMode", "Alternar terminal Python interativo", "Console"),
        ShortcutAction("restartTerminal", "Reiniciar terminal Python", "Console"),
        ShortcutAction("sendEOF", "Enviar EOF ao script", "Console"),
        ShortcutAction("share", "Compartilhar código", "Arquivos"),
        ShortcutAction("nextTheme", "Próximo tema", "Aparência"),
        ShortcutAction("nextFont", "Próxima fonte", "Aparência")
    )
}

object CustomShortcutStore {
    private const val PREFS = "editor"
    private const val KEY = "custom_shortcuts_v1"

    fun load(context: Context): List<CustomShortcutBinding> = runCatching {
        val json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val array = JSONArray(json)
        buildList {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                val actionId = o.optString("actionId")
                val keyCode = o.optInt("keyCode", AndroidKeyEvent.KEYCODE_UNKNOWN)
                if (ShortcutCatalog.actions.none { it.id == actionId } || keyCode == AndroidKeyEvent.KEYCODE_UNKNOWN) continue
                add(CustomShortcutBinding(actionId, keyCode, o.optBoolean("ctrl"), o.optBoolean("alt"), o.optBoolean("shift"), o.optBoolean("meta")))
            }
        }
    }.getOrDefault(emptyList())

    fun save(context: Context, bindings: List<CustomShortcutBinding>) {
        val array = JSONArray()
        bindings.forEach { binding ->
            array.put(JSONObject().apply {
                put("actionId", binding.actionId)
                put("keyCode", binding.keyCode)
                put("ctrl", binding.ctrl)
                put("alt", binding.alt)
                put("shift", binding.shift)
                put("meta", binding.meta)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }
}
