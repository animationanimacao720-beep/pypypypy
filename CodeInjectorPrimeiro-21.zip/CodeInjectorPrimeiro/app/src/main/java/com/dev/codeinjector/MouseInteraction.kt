package com.dev.codeinjector

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material3.TextButton as MaterialTextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/** Faz o botão direito do mouse disparar a mesma ação do clique normal nos controles da IDE. */
fun Modifier.rightMouseAsPress(onClick: () -> Unit): Modifier = pointerInput(onClick) {
    awaitPointerEventScope {
        while (true) {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val change = event.changes.firstOrNull() ?: continue
            if (event.type == PointerEventType.Press && change.type == PointerType.Mouse && event.buttons.isSecondaryPressed) {
                onClick()
                event.changes.forEach { it.consume() }
            }
        }
    }
}

/** Versão de TextButton da IDE com a mesma ação no botão esquerdo e no botão direito do mouse. */
@Composable
fun RightClickableTextButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    contentPadding: PaddingValues = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
    content: @Composable RowScope.() -> Unit
) {
    MaterialTextButton(
        onClick = onClick,
        modifier = if (enabled) modifier.rightMouseAsPress(onClick) else modifier,
        enabled = enabled,
        contentPadding = contentPadding,
        content = content
    )
}
