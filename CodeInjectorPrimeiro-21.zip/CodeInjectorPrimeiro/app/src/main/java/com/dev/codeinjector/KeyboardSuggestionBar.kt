package com.dev.codeinjector

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

enum class SymKind { KEYWORD, FUNCTION, CLASS, VARIABLE, BUILTIN, MODULE, ATTRIBUTE, SNIPPET }

/** [insert] substitui o prefixo digitado; o cursor termina [cursorBack] caracteres antes do fim do texto inserido. */
data class Suggestion(
    val label: String,
    val insert: String,
    val cursorBack: Int,
    val kind: SymKind,
    val selectionStartBack: Int? = null,
    val selectionEndBack: Int? = null
)

/** Extrai nomes declarados no arquivo .py atual e monta as sugestões (estilo teclado de celular). */
object PySymbols {
    private class Sym(val name: String, val kind: SymKind, val hasParams: Boolean = false, val order: Int)
    private class Index(val syms: List<Sym>, val attrs: List<String>, val selfAttrs: List<String>)

    private val DEF = Regex("(?m)^[ \\t]*(?:async[ \\t]+)?def[ \\t]+([A-Za-z_]\\w*)[ \\t]*\\(([^)\\n]*)")
    private val CLS = Regex("(?m)^[ \\t]*class[ \\t]+([A-Za-z_]\\w*)")
    private val ASSIGN = Regex("(?m)^[ \\t]*([A-Za-z_]\\w*(?:[ \\t]*,[ \\t]*[A-Za-z_]\\w*)*)[ \\t]*(?:[-+*/%&|^@]|//|\\*\\*|<<|>>)?=(?!=)")
    private val FOR = Regex("(?m)\\bfor[ \\t]+([A-Za-z_]\\w*(?:[ \\t]*,[ \\t]*[A-Za-z_]\\w*)*)[ \\t]+in\\b")
    private val AS = Regex("\\bas[ \\t]+([A-Za-z_]\\w*)")
    private val IMPORT = Regex("(?m)^[ \\t]*import[ \\t]+([^\\n#]+)")
    private val FROM = Regex("(?m)^[ \\t]*from[ \\t]+[\\w.]+[ \\t]+import[ \\t]+([^\\n#]+)")
    private val ATTR = Regex("\\.([A-Za-z_]\\w*)")
    private val SELF_ATTR = Regex("\\bself\\.([A-Za-z_]\\w*)")
    private val ID = Regex("[A-Za-z_]\\w*")

    @Volatile private var cache: Pair<String, Index>? = null

    private fun index(text: String): Index {
        cache?.let { if (it.first == text) return it.second }
        val found = LinkedHashMap<String, Sym>()
        var order = 0
        fun add(name: String, kind: SymKind, params: Boolean = false) {
            if (name in SyntaxAnalyzer.KEYWORDS || name.length < 2 && kind == SymKind.VARIABLE) return
            found[name] = Sym(name, kind, params, order++)
        }
        DEF.findAll(text).forEach { m ->
            val ps = m.groupValues[2].split(',').map { it.trim().removePrefix("**").removePrefix("*").substringBefore(':').substringBefore('=').trim() }
                .filter { it.isNotEmpty() && it != "self" && it != "cls" && it != "/" }
            add(m.groupValues[1], SymKind.FUNCTION, ps.isNotEmpty())
            ps.forEach { add(it, SymKind.VARIABLE) }
        }
        CLS.findAll(text).forEach { add(it.groupValues[1], SymKind.CLASS) }
        ASSIGN.findAll(text).forEach { m -> m.groupValues[1].split(',').forEach { add(it.trim(), SymKind.VARIABLE) } }
        FOR.findAll(text).forEach { m -> m.groupValues[1].split(',').forEach { add(it.trim(), SymKind.VARIABLE) } }
        AS.findAll(text).forEach { add(it.groupValues[1], SymKind.VARIABLE) }
        IMPORT.findAll(text).forEach { m ->
            m.groupValues[1].split(',').forEach { part ->
                val p = part.trim()
                add(if (" as " in p) p.substringAfter(" as ").trim() else p.substringBefore('.').trim(), SymKind.MODULE)
            }
        }
        FROM.findAll(text).forEach { m ->
            m.groupValues[1].replace("(", "").replace(")", "").split(',').forEach { part ->
                val p = part.trim()
                val n = if (" as " in p) p.substringAfter(" as ").trim() else p
                if (ID.matches(n)) add(n, SymKind.VARIABLE)
            }
        }
        val attrs = ATTR.findAll(text).map { it.groupValues[1] }.distinct().toList()
        val selfAttrs = SELF_ATTR.findAll(text).map { it.groupValues[1] }.distinct().toList()
        return Index(found.values.toList(), attrs, selfAttrs).also { cache = text to it }
    }

    private val STARTERS = listOf("def", "class", "import", "return", "self", "if", "elif", "else", "try", "except", "for", "while", "from", "print")
    private val INLINE = listOf("self", "True", "False", "None", "and", "or", "not", "in", "len", "range", "print")

    private fun kwInsert(w: String): Pair<String, Int> = when (w) {
        "def", "class", "import", "return", "if", "elif", "while", "for", "with", "lambda", "from", "not", "and", "or", "in", "is",
        "raise", "assert", "del", "global", "nonlocal", "yield", "await", "except", "as" -> "$w " to 0
        "else", "try", "finally" -> "$w:" to 0
        else -> w to 0
    }

    private fun make(name: String, kind: SymKind, hasParams: Boolean): Suggestion = when (kind) {
        SymKind.KEYWORD -> kwInsert(name).let { Suggestion(name, it.first, it.second, kind) }
        SymKind.FUNCTION -> Suggestion(name, "$name()", if (hasParams) 1 else 0, kind)
        SymKind.CLASS -> Suggestion(name, "$name()", 1, kind)
        SymKind.BUILTIN -> if (name in SyntaxAnalyzer.BUILTIN_FUNCS) Suggestion(name, "$name()", 1, kind) else Suggestion(name, name, 0, kind)
        else -> Suggestion(name, name, 0, kind)
    }

    class MemberQuery(val prefix: String, val line: Int, val col: Int)

    /** Se o cursor está logo depois de "algo." (com ou sem prefixo), devolve onde perguntar ao Python. */
    fun memberQuery(text: String, cursor: Int): MemberQuery? {
        val cp = cursor.coerceIn(0, text.length)
        var p = cp
        while (p > 0 && (text[p - 1].isLetterOrDigit() || text[p - 1] == '_')) p--
        if (p == 0 || text[p - 1] != '.') return null
        var line = 1; var ls = 0
        for (i in 0 until p) if (text[i] == '\n') { line++; ls = i + 1 }
        return MemberQuery(text.substring(p, cp), line, p - ls)
    }

    /** Retorna (prefixo antes do cursor, sugestões ordenadas). */
    fun suggest(
        text: String, cursor: Int, limit: Int = 14,
        customSnippets: List<UserCodeSnippet> = emptyList()
    ): Pair<String, List<Suggestion>> {
        val cp = cursor.coerceIn(0, text.length)
        val prefix = text.substring(0, cp).takeLastWhile { it.isLetterOrDigit() || it == '_' }
        val before = text.substring(0, cp - prefix.length)
        val lineBefore = before.substringAfterLast('\n')
        val idx = index(text)
        val out = ArrayList<Suggestion>()

        if (before.endsWith(".")) {
            val isSelf = before.endsWith("self.")
            val pool = (if (isSelf) idx.selfAttrs + idx.syms.filter { it.kind == SymKind.FUNCTION }.map { it.name } else idx.attrs).distinct()
            pool.filter { it != prefix && it.startsWith(prefix, ignoreCase = true) }.sortedBy { it.length }.take(limit).forEach {
                val isFn = idx.syms.any { s -> s.name == it && s.kind == SymKind.FUNCTION }
                out += if (isFn) make(it, SymKind.FUNCTION, idx.syms.first { s -> s.name == it }.hasParams) else Suggestion(it, it, 0, SymKind.ATTRIBUTE)
            }
            return prefix to out.distinctBy { it.label }
        }

        if (prefix.isNotEmpty()) {
            if (!PythonCodeTemplates.isImportContext(lineBefore)) {
                customSnippets.asSequence()
                    .filter { it.trigger.startsWith(prefix, ignoreCase = true) }
                    .sortedWith(compareBy<UserCodeSnippet>({ if (it.trigger.equals(prefix, true)) 0 else 1 }, { it.trigger.length }, { it.name }))
                    .take(limit)
                    .forEach { snippet ->
                        val body = PythonCodeTemplates.normalizeIndentationToTabs(snippet.body)
                        out += Suggestion(
                            label = "${snippet.trigger} — ${snippet.name}",
                            insert = body,
                            cursorBack = 0,
                            kind = SymKind.SNIPPET
                        )
                    }
            }
            val templateCandidates = PythonCodeTemplates.suggestions(prefix, lineBefore)
            if (PythonCodeTemplates.isImportContext(lineBefore)) {
                return prefix to templateCandidates.map { candidate ->
                    Suggestion(candidate.label, candidate.insertion.text, candidate.insertion.cursorBack,
                        if (candidate.isTemplate) SymKind.SNIPPET else SymKind.MODULE,
                        candidate.insertion.selectionStartBack, candidate.insertion.selectionEndBack)
                }.take(limit)
            }
            templateCandidates.forEach { candidate ->
                out += Suggestion(candidate.label, candidate.insertion.text, candidate.insertion.cursorBack,
                    if (candidate.isTemplate) SymKind.SNIPPET else SymKind.MODULE,
                    candidate.insertion.selectionStartBack, candidate.insertion.selectionEndBack)
            }
        }

        if (prefix.isEmpty()) {
            val atLineStart = lineBefore.isBlank()
            val declared = idx.syms.sortedByDescending { it.order }.take(8).map { make(it.name, it.kind, it.hasParams) }
            val kws = (if (atLineStart) STARTERS else INLINE).map {
                if (it in SyntaxAnalyzer.KEYWORDS) make(it, SymKind.KEYWORD, false) else make(it, SymKind.BUILTIN, false)
            }
            out += if (atLineStart) kws + declared else declared + kws
            return prefix to out.distinctBy { it.label }.take(limit)
        }

        class Cand(val s: Suggestion, val rank: Int)
        val cands = ArrayList<Cand>()
        idx.syms.forEach { if (it.name != prefix) cands += Cand(make(it.name, it.kind, it.hasParams), if (it.name.startsWith(prefix)) 0 else 1) }
        SyntaxAnalyzer.KEYWORDS.forEach { cands += Cand(make(it, SymKind.KEYWORD, false), 2) }
        (SyntaxAnalyzer.BUILTIN_FUNCS + SyntaxAnalyzer.BUILTIN_OTHERS).forEach { cands += Cand(make(it, SymKind.BUILTIN, false), 3) }
        var hits = cands.filter { it.s.label.length > prefix.length && it.s.label.startsWith(prefix, ignoreCase = true) }
        if (hits.size < 3 && prefix.length >= 2)
            hits = hits + cands.filter { it.s.label.contains(prefix, ignoreCase = true) && !it.s.label.startsWith(prefix, ignoreCase = true) }
        hits.sortedWith(compareBy({ it.rank }, { it.s.label.length })).forEach { out += it.s }
        return prefix to out.distinctBy { it.label }.take(limit)
    }
}

private fun kindColor(s: Suggestion, t: CodeTheme): Color = when (s.kind) {
    SymKind.KEYWORD -> if (s.label == "True" || s.label == "False" || s.label == "None") t.constant else t.keyword
    SymKind.FUNCTION -> t.call
    SymKind.CLASS -> t.className
    SymKind.BUILTIN -> t.builtin
    SymKind.MODULE -> t.module
    SymKind.ATTRIBUTE -> t.attr
    SymKind.VARIABLE -> t.text
    SymKind.SNIPPET -> t.string
}

/**
 * Faixa de atalhos de sintaxe acima do teclado. Só aparece enquanto você digita uma palavra (ou logo depois de "."),
 * mostra até 9 sugestões numeradas e cada uma é aplicada com Alt+1 ... Alt+9 (ou tocando nela).
 * A lista visível é enviada para [onShown] para o tratador de teclas físicas saber qual sugestão é qual número.
 */
@Composable
fun KeyboardSuggestionBar(
    text: String, cursor: Int, theme: CodeTheme,
    onSuggestion: (prefixLen: Int, suggestion: Suggestion) -> Unit,
    onShown: (List<Suggestion>, Int) -> Unit,
    members: List<MemberSug> = emptyList(),
    userSnippets: List<UserCodeSnippet> = emptyList(),
    modifier: Modifier = Modifier
) {
    // prefixo barato (síncrono); o índice de símbolos (várias regex no arquivo todo) roda fora da thread principal
    val prefix = remember(text, cursor) {
        val cp = cursor.coerceIn(0, text.length)
        var p = cp
        while (p > 0 && (text[p - 1].isLetterOrDigit() || text[p - 1] == '_')) p--
        text.substring(p, cp)
    }
    val afterDot = remember(text, cursor) { cursor in 1..text.length && text[cursor - 1] == '.' }
    val computed by produceState(initialValue = emptyList<Suggestion>(), text, cursor, userSnippets) {
        delay(80)
        value = withContext(Dispatchers.Default) { PySymbols.suggest(text, cursor, customSnippets = userSnippets).second }
    }
    val base = computed
    val suggestions = remember(base, members, prefix) {
        if (members.isEmpty()) base else {
            val m = members
                .filter { it.name != prefix && (prefix.isEmpty() || it.name.startsWith(prefix, ignoreCase = true)) }
                .let { if (prefix.isEmpty()) it else it.sortedBy { x -> x.name.length } }
                .take(30)
                .map {
                    when (it.kind) {
                        "f" -> Suggestion(it.name, it.name + "()", if (it.hasParams) 1 else 0, SymKind.FUNCTION)
                        "c" -> Suggestion(it.name, it.name + "()", 1, SymKind.CLASS)
                        "m" -> Suggestion(it.name, it.name, 0, SymKind.MODULE)
                        else -> Suggestion(it.name, it.name, 0, SymKind.ATTRIBUTE)
                    }
                }
            (m + base).distinctBy { it.label }.take(40)
        }
    }
    val typing = prefix.isNotEmpty() || afterDot
    val shown = if (typing) suggestions.take(9) else emptyList()
    LaunchedEffect(shown, prefix) { onShown(shown, prefix.length) }
    DisposableEffect(Unit) { onDispose { onShown(emptyList(), 0) } }
    if (shown.isEmpty()) return

    Row(
        modifier.fillMaxWidth().height(40.dp).background(theme.bar).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Alt+", color = theme.gutterText, fontSize = 12.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
        LazyRow(
            Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            itemsIndexed(shown, key = { _, s -> s.kind.name + s.label }) { idx, s ->
                Row(
                    Modifier.clip(RoundedCornerShape(16.dp)).background(theme.chip)
                        .pointerInput(s, prefix) { detectTapGestures { onSuggestion(prefix.length, s) } }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${idx + 1}", color = theme.gutterText, fontSize = 11.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
                    Text(" " + s.label, color = kindColor(s, theme), fontSize = 14.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
                }
            }
        }
    }
}
