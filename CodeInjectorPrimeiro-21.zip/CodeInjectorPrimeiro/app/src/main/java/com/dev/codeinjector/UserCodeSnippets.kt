package com.dev.codeinjector

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Atalho personalizado definido pelo usuário. */
data class UserCodeSnippet(
    val trigger: String,
    val name: String,
    val body: String
)

/** Persistência local e formato portável JSON para os snippets do usuário. */
class SnippetStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("snippets", Context.MODE_PRIVATE)

    fun load(): List<UserCodeSnippet> {
        val raw = prefs.getString("l", "[]") ?: "[]"
        return runCatching { decode(raw) }.getOrDefault(emptyList())
    }

    fun save(snippets: List<UserCodeSnippet>) {
        prefs.edit().putString("l", encode(snippets)).apply()
    }

    companion object {
        private const val FORMAT = "codeinjector-snippets"
        private const val VERSION = 1
        private val VALID_TRIGGER = Regex("[A-Za-z_][A-Za-z0-9_]{0,39}")

        fun normalizeTrigger(raw: String): String = raw.trim().lowercase(Locale.ROOT)

        fun isValidTrigger(trigger: String): Boolean = VALID_TRIGGER.matches(normalizeTrigger(trigger))

        private fun fallbackTrigger(name: String): String {
            val slug = name.trim().lowercase(Locale.ROOT)
                .replace(Regex("[^a-z0-9_]+"), "_").trim('_')
                .ifEmpty { "snippet" }
            return (if (slug.firstOrNull()?.isLetter() == true || slug.startsWith('_')) slug else "s_$slug")
                .take(40)
        }

        private fun JSONObject.firstNonBlank(vararg keys: String): String {
            for (key in keys) {
                val value = optString(key, "").trimEnd()
                if (value.isNotBlank()) return value
            }
            return ""
        }

        /** Lê o formato atual, o formato de exportação e o formato legado {n,b}. */
        fun decode(json: String): List<UserCodeSnippet> {
            val trimmed = json.trim()
            val rows = when {
                trimmed.startsWith("[") -> JSONArray(trimmed)
                trimmed.startsWith("{") -> {
                    val root = JSONObject(trimmed)
                    val format = root.optString("format", "")
                    if (format.isNotEmpty() && format != FORMAT) {
                        throw IllegalArgumentException("Arquivo não é uma exportação de snippets do Code Injector.")
                    }
                    root.optJSONArray("snippets") ?: throw IllegalArgumentException("O arquivo JSON não contém a lista 'snippets'.")
                }
                else -> throw IllegalArgumentException("Arquivo JSON inválido.")
            }
            val out = ArrayList<UserCodeSnippet>()
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                val name = row.firstNonBlank("name", "n")
                val body = row.firstNonBlank("body", "b")
                if (name.isBlank() || body.isBlank()) continue
                val requestedTrigger = normalizeTrigger(row.firstNonBlank("trigger", "t"))
                val trigger = if (isValidTrigger(requestedTrigger)) requestedTrigger else fallbackTrigger(name)
                out += UserCodeSnippet(
                    trigger = trigger,
                    name = name.trim(),
                    body = PythonCodeTemplates.normalizeIndentationToTabs(body)
                )
            }
            if (out.isEmpty()) throw IllegalArgumentException("Nenhum snippet válido foi encontrado no arquivo.")
            // Snippets com o mesmo atalho no arquivo ficam determinísticos: o último prevalece.
            return out.associateBy { it.trigger }.values.toList()
        }

        fun encode(snippets: List<UserCodeSnippet>): String {
            val rows = JSONArray()
            snippets.forEach { snippet ->
                val trigger = normalizeTrigger(snippet.trigger)
                require(isValidTrigger(trigger)) { "Atalho inválido: ${snippet.trigger}" }
                require(snippet.name.isNotBlank()) { "Todo snippet precisa de um nome." }
                require(snippet.body.isNotBlank()) { "O código do atalho '${snippet.name}' está vazio." }
                rows.put(JSONObject()
                    .put("trigger", trigger)
                    .put("name", snippet.name.trim())
                    .put("body", PythonCodeTemplates.normalizeIndentationToTabs(snippet.body)))
            }
            return JSONObject()
                .put("format", FORMAT)
                .put("version", VERSION)
                .put("snippets", rows)
                .toString(2)
        }
    }
}
