package com.dev.codeinjector

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Estado do gerenciador de arquivos: pasta raiz escolhida (SAF), pastas expandidas e cache dos filhos
 * de cada pasta. A árvore é montada a partir disso (como no gerenciador de arquivos do CodeAssist).
 */
class ProjectExplorerState(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("project", Context.MODE_PRIVATE)
    var treeUri by mutableStateOf(prefs.getString("tree", null)?.let { Uri.parse(it) })
        private set
    var rootId by mutableStateOf<String?>(null)
        private set
    var rootName by mutableStateOf(prefs.getString("name", null) ?: "Projeto")
        private set
    val expanded = mutableStateListOf<String>()
    val children = mutableStateMapOf<String, List<DocEntry>>()
    var loading by mutableStateOf(false)
    var refreshTick by mutableIntStateOf(0)
    var showAll by mutableStateOf(prefs.getBoolean("showAll", true))
        private set

    init {
        rootId = treeUri?.let { u -> runCatching { DocumentsContract.getTreeDocumentId(u) }.getOrNull() }
    }

    fun setRoot(uri: Uri, name: String) {
        val id = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrNull() ?: return
        treeUri = uri; rootId = id; rootName = name
        expanded.clear(); children.clear(); refreshTick++
        prefs.edit().putString("tree", uri.toString()).putString("name", name).apply()
    }

    fun toggleShowAll() { showAll = !showAll; prefs.edit().putBoolean("showAll", showAll).apply() }
    fun refresh() { refreshTick++ }
    fun forget(docId: String) { expanded.removeAll { it == docId || it.startsWith("$docId/") } }
}

private val HIDDEN_DIRS = setOf("__pycache__", ".git", ".idea", ".venv", "venv", "node_modules", ".gradle", "build")

private data class TreeRow(val e: DocEntry, val depth: Int, val parentId: String)

private sealed interface Dlg {
    data class Create(val dir: Boolean, val parentId: String, val parentName: String) : Dlg
    data class Rename(val e: DocEntry) : Dlg
    data class Delete(val e: DocEntry) : Dlg
    data class Move(val e: DocEntry, val parentId: String) : Dlg
}

private fun fileIcon(e: DocEntry, open: Boolean): String = when {
    e.isDir -> if (open) "📂" else "📁"
    e.name.endsWith(".py") -> "🐍"
    e.name.endsWith(".md") || e.name.endsWith(".txt") -> "📝"
    e.name.endsWith(".json") || e.name.endsWith(".toml") || e.name.endsWith(".yml") || e.name.endsWith(".yaml") -> "⚙"
    else -> "📄"
}

/**
 * Gerenciador de arquivos em árvore: toque numa pasta expande/recolhe, toque num arquivo abre em aba,
 * toque longo abre o menu (novo arquivo/pasta, renomear, mover, excluir).
 * [onDocChanged] avisa que um documento mudou de id (renomear/mover) ou foi excluído (newId == null),
 * para as abas abertas atualizarem o Uri.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileExplorerSidebar(
    state: ProjectExplorerState, theme: CodeTheme, activeUri: Uri?,
    onPickFolder: () -> Unit,
    onOpenFile: (DocEntry) -> Unit,
    onDocChanged: (oldId: String, newId: String?) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    val tree = state.treeUri
    val rootId = state.rootId
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var topMenu by remember { mutableStateOf(false) }
    var lastTick by remember { mutableIntStateOf(-1) }
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    val expandedSnapshot = state.expanded.toList()
    LaunchedEffect(tree, rootId, state.refreshTick, expandedSnapshot) {
        if (tree == null || rootId == null) return@LaunchedEffect
        if (lastTick != state.refreshTick) { lastTick = state.refreshTick; state.children.clear() }
        val need = (listOf(rootId) + expandedSnapshot).filter { it !in state.children }
        if (need.isEmpty()) return@LaunchedEffect
        state.loading = true
        try {
            val res = withContext(Dispatchers.IO) { need.associateWith { ProjectFs.list(ctx, tree, it) } }
            state.children.putAll(res)
        } finally { state.loading = false }
    }

    val rows = ArrayList<TreeRow>()
    fun walk(dirId: String, depth: Int) {
        val list = state.children[dirId] ?: return
        for (e in list) {
            val show = if (e.isDir) e.name !in HIDDEN_DIRS else state.showAll || e.name.endsWith(".py")
            if (!show) continue
            rows += TreeRow(e, depth, dirId)
            if (e.isDir && e.id in state.expanded) walk(e.id, depth + 1)
        }
    }
    if (rootId != null) walk(rootId, 0)
    val activeId = activeUri?.let { runCatching { DocumentsContract.getDocumentId(it) }.getOrNull() }

    Column(modifier.background(theme.bar)) {
        // ---- cabeçalho: nome do projeto + ações
        Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (tree == null) "Arquivos" else state.rootName, Modifier.weight(1f),
                color = theme.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (tree != null) {
                SideBtn("📄＋", theme) { if (rootId != null) dlg = Dlg.Create(false, rootId, state.rootName) }
                SideBtn("📁＋", theme) { if (rootId != null) dlg = Dlg.Create(true, rootId, state.rootName) }
                SideBtn("↻", theme) { state.refresh() }
                Box {
                    SideBtn("⋮", theme) { topMenu = true }
                    DropdownMenu(topMenu, { topMenu = false }) {
                        DropdownMenuItem(text = { Text("Recolher tudo") }, modifier = Modifier.rightMouseAsPress { topMenu = false; state.expanded.clear() }, onClick = { topMenu = false; state.expanded.clear() })
                        DropdownMenuItem(
                            text = { Text(if (state.showAll) "Mostrar só .py" else "Mostrar todos os arquivos") },
                            modifier = Modifier.rightMouseAsPress { topMenu = false; state.toggleShowAll() },
                            onClick = { topMenu = false; state.toggleShowAll() }
                        )
                        DropdownMenuItem(text = { Text("Trocar pasta do projeto") }, modifier = Modifier.rightMouseAsPress { topMenu = false; onPickFolder() }, onClick = { topMenu = false; onPickFolder() })
                    }
                }
            }
            SideBtn("✕", theme) { onClose() }
        }
        if (tree == null || rootId == null) {
            Text(
                "Escolha a pasta do projeto. No seletor do Android, abra o menu lateral e procure a pasta onde ficam seus arquivos Python.",
                Modifier.padding(12.dp), color = theme.comment, fontSize = 13.sp
            )
            RightClickableTextButton(onPickFolder, Modifier.padding(horizontal = 4.dp)) { Text("Abrir pasta do projeto", color = theme.function) }
        } else LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            if (!state.loading && rows.isEmpty()) item {
                Text(
                    if (state.showAll) "Pasta vazia. Use 📄＋ ou 📁＋ para criar." else "Nenhum arquivo .py aqui. Use ⋮ para mostrar todos.",
                    Modifier.padding(12.dp), color = theme.comment, fontSize = 12.sp
                )
            }
            items(rows, key = { it.e.id }) { r ->
                val e = r.e
                val open = e.isDir && e.id in state.expanded
                Box {
                    Row(
                        Modifier.fillMaxWidth()
                            .background(if (e.id == activeId) theme.chip else Color.Transparent)
                            .combinedClickable(
                                onClick = {
                                    if (e.isDir) { if (open) state.expanded.remove(e.id) else state.expanded.add(e.id) }
                                    else onOpenFile(e)
                                },
                                onLongClick = { menuFor = e.id }
                            )
                            .padding(start = (8 + r.depth * 14).dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (e.isDir) (if (open) "▾" else "▸") else "", Modifier.width(16.dp), color = theme.comment, fontSize = 13.sp)
                        Text(fileIcon(e, open), fontSize = 14.sp)
                        Spacer(Modifier.width(6.dp))
                        Text(e.name, Modifier.weight(1f), color = theme.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    DropdownMenu(expanded = menuFor == e.id, onDismissRequest = { menuFor = null }) {
                        if (e.isDir) {
                            DropdownMenuItem(text = { Text("Novo arquivo") }, modifier = Modifier.rightMouseAsPress { menuFor = null; dlg = Dlg.Create(false, e.id, e.name) }, onClick = { menuFor = null; dlg = Dlg.Create(false, e.id, e.name) })
                            DropdownMenuItem(text = { Text("Nova pasta") }, modifier = Modifier.rightMouseAsPress { menuFor = null; dlg = Dlg.Create(true, e.id, e.name) }, onClick = { menuFor = null; dlg = Dlg.Create(true, e.id, e.name) })
                        }
                        DropdownMenuItem(text = { Text("Renomear") }, modifier = Modifier.rightMouseAsPress { menuFor = null; dlg = Dlg.Rename(e) }, onClick = { menuFor = null; dlg = Dlg.Rename(e) })
                        DropdownMenuItem(text = { Text("Mover para…") }, modifier = Modifier.rightMouseAsPress { menuFor = null; dlg = Dlg.Move(e, r.parentId) }, onClick = { menuFor = null; dlg = Dlg.Move(e, r.parentId) })
                        DropdownMenuItem(text = { Text("Excluir") }, modifier = Modifier.rightMouseAsPress { menuFor = null; dlg = Dlg.Delete(e) }, onClick = { menuFor = null; dlg = Dlg.Delete(e) })
                    }
                }
            }
        }
    }

    when (val d = dlg) {
        is Dlg.Create -> NameDialog(
            title = (if (d.dir) "Nova pasta em " else "Novo arquivo em ") + d.parentName, initial = "", onDismiss = { dlg = null }
        ) { raw ->
            var n = raw.trim()
            if (tree == null || n.isEmpty() || '/' in n) { toast("Nome inválido (não use '/')"); return@NameDialog }
            if (!d.dir && '.' !in n) n += ".py"
            val uri = ProjectFs.create(ctx, tree, d.parentId, n, d.dir)
            if (uri == null) toast("Não consegui criar \"$n\"")
            else {
                dlg = null
                if (d.parentId != rootId && d.parentId !in state.expanded) state.expanded.add(d.parentId)
                state.refresh()
                if (!d.dir) onOpenFile(DocEntry(DocumentsContract.getDocumentId(uri), n, false))
            }
        }
        is Dlg.Rename -> NameDialog("Renomear", d.e.name, { dlg = null }) { raw ->
            var n = raw.trim()
            if (tree == null || n.isEmpty() || '/' in n) { toast("Nome inválido"); return@NameDialog }
            if (!d.e.isDir && '.' !in n && d.e.name.endsWith(".py")) n += ".py"
            val newId = ProjectFs.rename(ctx, tree, d.e.id, n)
            if (newId == null) toast("O provedor de arquivos recusou renomear")
            else { dlg = null; state.forget(d.e.id); onDocChanged(d.e.id, newId); state.refresh() }
        }
        is Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("Excluir \"${d.e.name}\"?") },
            text = { Text(if (d.e.isDir) "A pasta e tudo que está dentro serão apagados." else "Esta ação não pode ser desfeita.") },
            confirmButton = {
                RightClickableTextButton({
                    if (tree != null && ProjectFs.delete(ctx, tree, d.e.id)) { state.forget(d.e.id); onDocChanged(d.e.id, null); state.refresh() }
                    else toast("Não consegui excluir")
                    dlg = null
                }) { Text("Excluir") }
            },
            dismissButton = { RightClickableTextButton({ dlg = null }) { Text("Cancelar") } }
        )
        is Dlg.Move -> if (tree != null && rootId != null) FolderPicker(
            ctx = ctx, tree = tree, root = rootId to state.rootName, moving = d.e,
            onDismiss = { dlg = null },
            onPick = { targetId ->
                val newId = ProjectFs.move(ctx, tree, d.e.id, d.parentId, targetId)
                if (newId == null) toast("Não consegui mover")
                else { state.forget(d.e.id); onDocChanged(d.e.id, newId); state.refresh() }
                dlg = null
            }
        )
        null -> {}
    }
}

@Composable
private fun SideBtn(label: String, theme: CodeTheme, onClick: () -> Unit) =
    RightClickableTextButton(onClick, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
        Text(label, fontSize = 13.sp, color = theme.function)
    }

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = { OutlinedTextField(v, { v = it }, singleLine = true, label = { Text("Nome (ex.: utils.py)") }) },
        confirmButton = { RightClickableTextButton({ onOk(v) }) { Text("OK") } },
        dismissButton = { RightClickableTextButton(onDismiss) { Text("Cancelar") } }
    )
}

/** Escolhe a pasta de destino navegando só entre diretórios. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderPicker(
    ctx: Context, tree: Uri, root: Pair<String, String>, moving: DocEntry,
    onDismiss: () -> Unit, onPick: (String) -> Unit
) {
    val stack = remember { mutableStateListOf(root) }
    var dirs by remember { mutableStateOf<List<DocEntry>>(emptyList()) }
    val cur = stack.last()
    LaunchedEffect(cur.first) {
        dirs = withContext(Dispatchers.IO) { ProjectFs.list(ctx, tree, cur.first).filter { it.isDir && it.name !in HIDDEN_DIRS } }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mover \"${moving.name}\" para", maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.heightIn(max = 320.dp)) {
                Text(stack.joinToString(" / ") { it.second }, fontSize = 12.sp)
                LazyColumn(Modifier.fillMaxWidth()) {
                    if (stack.size > 1) item {
                        Text("📁  .. (voltar)", Modifier.fillMaxWidth().combinedClickable(onClick = { stack.removeAt(stack.lastIndex) }).padding(10.dp))
                    }
                    items(dirs.filter { it.id != moving.id }, key = { it.id }) { d ->
                        Text("📁  ${d.name}", Modifier.fillMaxWidth().combinedClickable(onClick = { stack.add(d.id to d.name) }).padding(10.dp))
                    }
                }
            }
        },
        confirmButton = { RightClickableTextButton({ onPick(cur.first) }) { Text("Mover aqui") } },
        dismissButton = { RightClickableTextButton(onDismiss) { Text("Cancelar") } }
    )
}
