package com.dev.codeinjector

/** Detecta imports de frameworks gráficos num arquivo ou conjunto de fontes Python do projeto. */
object PythonFrameworkDetector {
    private val knownModules = setOf("kivy", "pygame", "tkinter", "pyglet", "arcade", "pyqt5", "pyqt6", "pyside2", "pyside6")

    // Strings e comentários são mascarados preservando quebras de linha. A regex vê apenas o código,
    // não exemplos como "import pygame" dentro de uma docstring ou de um comentário.
    private val importPattern = Regex(
        """(?m)(?:^|[;\n])[ \t]*(?:from[ \t]+([A-Za-z_][A-Za-z0-9_.]*)[ \t]+import\b|import[ \t]+([^;\n]+))"""
    )

    /** Retorna um identificador interno normalizado. */
    fun detect(source: String): String? {
        val code = maskStringsAndComments(source)
        val found = LinkedHashSet<String>()
        for (match in importPattern.findAll(code)) {
            val fromModule = match.groupValues.getOrNull(1).orEmpty()
            if (fromModule.isNotEmpty()) {
                normalize(fromModule)?.let(found::add)
            } else {
                val names = match.groupValues.getOrNull(2).orEmpty().substringBefore('#')
                names.split(',').forEach { raw ->
                    val module = raw.trim().removePrefix("(").trim()
                        .substringBefore(" as ").trim().substringBefore('[').trimEnd(')')
                    normalize(module)?.let(found::add)
                }
            }
        }
        val priority = listOf("kivy", "pygame", "arcade", "pyqt6", "pyqt5", "pyside6", "pyside2", "tkinter", "pyglet")
        return priority.firstOrNull { it in found }
    }

    /** Combina fontes do projeto inteiro. A ordem de prioridade é a mesma de [detect]. */
    fun detectSources(sources: Iterable<String>): String? = detect(sources.joinToString("\n\n"))

    /**
     * Mascara strings Python simples/triplas e comentários. A função preserva CR/LF para que
     * posições de statements e imports em linhas diferentes continuem reconhecíveis. Escapes
     * são respeitados em strings comuns e triplas.
     */
    private fun maskStringsAndComments(source: String): String {
        val chars = source.toCharArray()
        fun blank(index: Int) {
            if (index in chars.indices && chars[index] != '\n' && chars[index] != '\r') chars[index] = ' '
        }
        var i = 0
        while (i < chars.size) {
            when (chars[i]) {
                '#' -> {
                    while (i < chars.size && chars[i] != '\n' && chars[i] != '\r') {
                        blank(i)
                        i++
                    }
                }
                '\'', '"' -> {
                    val quote = chars[i]
                    val triple = i + 2 < chars.size && chars[i + 1] == quote && chars[i + 2] == quote
                    val delimiterLength = if (triple) 3 else 1
                    repeat(delimiterLength) { offset -> blank(i + offset) }
                    i += delimiterLength
                    while (i < chars.size) {
                        if (chars[i] == '\\') {
                            blank(i)
                            i++
                            if (i < chars.size) {
                                // Não apague CR/LF: continua uma linha física separada.
                                blank(i)
                                i++
                            }
                            continue
                        }
                        val ends = if (triple) {
                            i + 2 < chars.size && chars[i] == quote && chars[i + 1] == quote && chars[i + 2] == quote
                        } else chars[i] == quote
                        if (ends) {
                            repeat(delimiterLength) { offset -> blank(i + offset) }
                            i += delimiterLength
                            break
                        }
                        blank(i)
                        i++
                    }
                }
                else -> i++
            }
        }
        return String(chars)
    }

    private fun normalize(module: String): String? {
        val root = module.trim().substringBefore('.').lowercase()
        return root.takeIf { it in knownModules }
    }
}
