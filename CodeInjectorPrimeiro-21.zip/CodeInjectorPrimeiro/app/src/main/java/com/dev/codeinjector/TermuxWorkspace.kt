package com.dev.codeinjector

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.File
import java.util.Locale

/** Snapshot dos arquivos abertos no momento em que o usuário toca em Executar. */
data class TermuxProjectInput(
    val treeUri: Uri?,
    val rootId: String?,
    val mainDocumentId: String?,
    /** Conteúdo atual por documentId, para incluir edições ainda não gravadas. */
    val openDocuments: Map<String, String> = emptyMap(),
    /** Abas sem arquivo salvo, por caminho relativo/nome. */
    val looseFiles: Map<String, String> = emptyMap(),
    /** Document IDs das abas alteradas no editor. Essas alterações nunca devem sobrescrever o original silenciosamente. */
    val dirtyDocuments: Set<String> = emptySet(),
    /** Pasta raiz de um projeto importado para o armazenamento privado do app, se aplicável. */
    val localProjectRoot: String? = null,
    /** Caminho relativo do arquivo principal dentro de um projeto privado importado. */
    val mainRelativePath: String? = null,
    /** Texto atual das abas de um projeto privado, indexado pelo caminho relativo. */
    val localOpenDocuments: Map<String, String> = emptyMap(),
)


data class TermuxProjectScript(val entry: DocEntry?, val relativePath: String, val localFile: File? = null)

data class PreparedTermuxWorkspace(
    val projectPath: String,
    val workDirPath: String,
    val mainScriptPath: String,
    val mainRelativePath: String,
    val runDirPath: String,
    val stdoutUri: Uri,
    val stderrUri: Uri,
    val projectName: String,
    val isDirectProject: Boolean,
)

/**
 * Transfere projetos pela Storage Access Framework, não pelo Intent do Termux. Isso remove o limite
 * de tamanho do payload e permite levar arquivos binários e subpastas quando a origem não é
 * diretamente visível ao Termux. A pasta-ponte escolhida precisa estar no armazenamento compartilhado.
 */
object TermuxWorkspace {
    private const val PREFS = "termux_workspace"
    private const val PREF_TREE = "bridge_tree"
    private const val PREF_ROOT_ID = "bridge_root_id"
    private const val PREF_PATH = "bridge_path"
    private const val MAX_FILES = 4000
    private const val MAX_TOTAL_BYTES = 180L * 1024L * 1024L
    private val SKIP_DIRS = setOf(".git", ".venv", "venv", "__pycache__", ".gradle", ".idea", "node_modules", "build", "dist")

    data class BridgeLocation(val tree: Uri, val rootId: String, val path: String)

    fun saveBridge(context: Context, uri: Uri): Result<BridgeLocation> = runCatching {
        val rootId = DocumentsContract.getTreeDocumentId(uri)
        val path = externalStoragePath(rootId)
            ?: error("Escolha uma pasta no armazenamento interno compartilhado (por exemplo Documents/CodeInjectorTermux). Pastas de app ou nuvem não funcionam como caminho do shell.")
        require(path != "/storage/emulated/0" && path != "/sdcard") {
            "Escolha uma subpasta, não a raiz inteira do armazenamento. Exemplo: Documents/CodeInjectorTermux."
        }
        context.contentResolver.takePersistableUriPermission(
            uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(PREF_TREE, uri.toString()).putString(PREF_ROOT_ID, rootId).putString(PREF_PATH, path).apply()
        BridgeLocation(uri, rootId, path)
    }

    fun bridge(context: Context): BridgeLocation? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val tree = p.getString(PREF_TREE, null)?.let(Uri::parse) ?: return null
        val rootId = p.getString(PREF_ROOT_ID, null) ?: return null
        val path = p.getString(PREF_PATH, null) ?: externalStoragePath(rootId) ?: return null
        return BridgeLocation(tree, rootId, path)
    }

    /** Lista possíveis arquivos de entrada do projeto, mantendo caminhos relativos para subpastas. */
    fun listPythonScripts(context: Context, tree: Uri, rootId: String, maxScripts: Int = 600): List<TermuxProjectScript> {
        val found = ArrayList<TermuxProjectScript>()
        val visited = HashSet<String>()
        fun visit(directoryId: String, prefix: String, depth: Int) {
            if (depth > 32 || found.size >= maxScripts || !visited.add(directoryId)) return
            for (entry in ProjectFs.list(context, tree, directoryId)) {
                if (found.size >= maxScripts) break
                val relative = if (prefix.isEmpty()) entry.name else "$prefix/${entry.name}"
                if (entry.isDir) {
                    if (entry.name !in SKIP_DIRS && !entry.name.startsWith(".codeinjector")) visit(entry.id, relative, depth + 1)
                } else if (entry.name.endsWith(".py", ignoreCase = true)) {
                    found += TermuxProjectScript(entry, relative)
                }
            }
        }
        visit(rootId, "", 0)
        return found.sortedBy { it.relativePath.lowercase(Locale.ROOT) }
    }

    /** Lista scripts de um projeto importado no armazenamento privado do app, sem achatar subpastas. */
    fun listPythonScripts(localRoot: File, maxScripts: Int = 600): List<TermuxProjectScript> {
        val root = runCatching { localRoot.canonicalFile }.getOrNull()?.takeIf { it.isDirectory } ?: return emptyList()
        val rootPrefix = root.path.trimEnd(File.separatorChar) + File.separator
        val found = ArrayList<TermuxProjectScript>()
        val visited = HashSet<String>()
        fun visit(dir: File, prefix: String, depth: Int) {
            if (depth > 32 || found.size >= maxScripts) return
            val canonical = runCatching { dir.canonicalFile }.getOrNull() ?: return
            if (!canonical.path.startsWith(rootPrefix) && canonical != root) return
            if (!visited.add(canonical.path)) return
            val children = canonical.listFiles()?.sortedBy { it.name.lowercase(Locale.ROOT) } ?: return
            for (child in children) {
                if (found.size >= maxScripts) break
                if (child.name in SKIP_DIRS || child.name.startsWith(".codeinjector")) continue
                val safeChild = runCatching { child.canonicalFile }.getOrNull() ?: continue
                if (!safeChild.path.startsWith(rootPrefix)) continue
                val relative = if (prefix.isEmpty()) child.name else "$prefix/${child.name}"
                if (safeChild.isDirectory) visit(safeChild, relative, depth + 1)
                else if (safeChild.isFile && safeChild.name.endsWith(".py", ignoreCase = true)) {
                    found += TermuxProjectScript(null, relative, safeChild)
                }
            }
        }
        visit(root, "", 0)
        return found.sortedBy { it.relativePath.lowercase(Locale.ROOT) }
    }

    /** Responde apenas por URIs SAF do provedor de armazenamento externo do Android. */
    fun externalStoragePath(documentId: String): String? {
        val colon = documentId.indexOf(':')
        if (colon <= 0) return null
        val volume = documentId.substring(0, colon)
        if (!volume.equals("primary", ignoreCase = true)) return null
        val relative = documentId.substring(colon + 1).trim('/')
        val segments = if (relative.isEmpty()) emptyList() else relative.split('/')
        if (segments.any { it.isEmpty() || it == "." || it == ".." || it.contains('\u0000') }) return null
        // /storage/emulated/0 is the same shared volume exposed as /sdcard in Termux.
        return if (segments.isEmpty()) "/storage/emulated/0" else "/storage/emulated/0/" + segments.joinToString("/")
    }

    fun relativePath(rootId: String, documentId: String): String? {
        val rootColon = rootId.indexOf(':')
        val docColon = documentId.indexOf(':')
        if (rootColon <= 0 || docColon <= 0) return null
        if (!rootId.substring(0, rootColon).equals(documentId.substring(0, docColon), ignoreCase = true)) return null
        val rootPath = rootId.substring(rootColon + 1).trim('/')
        val docPath = documentId.substring(docColon + 1).trim('/')
        if (rootPath.isEmpty()) return sanitizeRelative(docPath)
        if (docPath == rootPath) return ""
        if (!docPath.startsWith("$rootPath/")) return null
        return sanitizeRelative(docPath.removePrefix("$rootPath/"))
    }

    fun sanitizeRelative(path: String): String? {
        val normalized = path.replace('\\', '/').trim('/')
        if (normalized.isEmpty()) return null
        val parts = normalized.split('/')
        if (parts.any { it.isBlank() || it == "." || it == ".." || it.contains(':') || it.contains('\u0000') }) return null
        if (parts.any { it.startsWith("/") }) return null
        return parts.joinToString("/")
    }

    /** Prepara uma cópia de execução, ou usa a pasta real se o projeto já estiver no armazenamento compartilhado. */
    fun prepare(
        context: Context,
        input: TermuxProjectInput?,
        runId: String,
        fileName: String,
        source: String,
        siblings: Map<String, String>,
    ): PreparedTermuxWorkspace {
        val tree = input?.treeUri
        val rootId = input?.rootId
        val mainId = input?.mainDocumentId
        val localRoot = input?.localProjectRoot?.let(::File)?.let { runCatching { it.canonicalFile }.getOrNull() }?.takeIf { it.isDirectory }
        val directRoot = if (localRoot == null && tree != null && rootId != null) externalStoragePath(rootId) else null
        val directMainRel = if (rootId != null && mainId != null) relativePath(rootId, mainId) else null
        val direct = input != null && input.dirtyDocuments.isEmpty() && input.looseFiles.isEmpty() &&
            directRoot != null && !directMainRel.isNullOrBlank() && directMainRel.endsWith(".py", ignoreCase = true)

        if (direct && tree != null && rootId != null && directMainRel != null && directRoot != null) {
            // Quando todos os arquivos estão salvos, execute do diretório real: assets e imports
            // ficam no lugar. Com buffers modificados, a execução cai na cópia isolada abaixo.
            val runDirId = ensureDirectories(context, tree, rootId, listOf(".codeinjector-runs", runId))
            val outUri = ensureFile(context, tree, runDirId, "stdout.log")
            val errUri = ensureFile(context, tree, runDirId, "stderr.log")
            ProjectFs.writeText(context, outUri, "")
            ProjectFs.writeText(context, errUri, "")
            val rel = sanitizeRelative(directMainRel) ?: error("Caminho principal inválido")
            val scriptPath = "$directRoot/$rel"
            return PreparedTermuxWorkspace(
                directRoot, directRoot, scriptPath, rel,
                "$directRoot/.codeinjector-runs/$runId", outUri, errUri,
                directRoot.substringAfterLast('/').ifBlank { "Projeto" }, true
            )
        }

        val bridge = bridge(context)
            ?: error("Não há uma pasta compartilhada configurada para Termux. No menu ⋮, escolha ‘Configurar pasta compartilhada Termux…’ e selecione uma subpasta do armazenamento interno (ex.: Documents/CodeInjectorTermux). Depois execute termux-setup-storage no Termux.")
        val sourceSharedPath = if (rootId != null) externalStoragePath(rootId) else null
        val workspacePath = "${bridge.path}/.codeinjector-workspace"
        if (sourceSharedPath != null &&
            (workspacePath == sourceSharedPath || workspacePath.startsWith(sourceSharedPath.trimEnd('/') + "/"))) {
            error("A pasta-ponte está dentro da pasta do projeto; isso faria a cópia entrar em si mesma. No menu ⋮, escolha uma pasta-ponte fora do projeto, por exemplo Documents/CodeInjectorTermux.")
        }
        val rootRunId = ensureDirectories(context, bridge.tree, bridge.rootId, listOf(".codeinjector-runs", runId))
        val workspaceId = ensureDirectories(context, bridge.tree, bridge.rootId, listOf(".codeinjector-workspace"))
        // Reutiliza o mesmo diretório de execução entre as chamadas, removendo arquivos antigos
        // antes de sincronizar para não deixar módulos obsoletos que já foram apagados do projeto.
        clearDirectory(context, bridge.tree, workspaceId)

        var mainRel = input?.mainRelativePath?.let(::sanitizeRelative)
            ?: if (rootId != null && mainId != null) relativePath(rootId, mainId) else null
        if (mainRel.isNullOrBlank() || !mainRel.endsWith(".py", true)) mainRel = safePythonPath(fileName)
        mainRel = sanitizeRelative(mainRel!!) ?: "main.py"

        val copied = intArrayOf(0)
        val totalBytes = longArrayOf(0L)
        if (tree != null && rootId != null) {
            copyDirectory(context, tree, rootId, bridge.tree, workspaceId, "", input?.openDocuments.orEmpty(), rootId, copied, totalBytes)
        } else if (localRoot != null) {
            copyLocalDirectory(context, localRoot, bridge.tree, workspaceId, copied, totalBytes)
            for ((rawPath, text) in input?.localOpenDocuments.orEmpty()) {
                val rel = sanitizeRelative(rawPath) ?: continue
                writeRelativeText(context, bridge.tree, workspaceId, rel, text)
            }
        }
        // Abas temporárias fora da árvore só são anexadas quando não há um projeto local explícito.
        val loose = if (localRoot == null) input?.looseFiles.orEmpty() + if (input == null) siblings else emptyMap() else emptyMap()
        for ((rawName, text) in loose) {
            val rel = sanitizeRelative(rawName) ?: continue
            writeRelativeText(context, bridge.tree, workspaceId, rel, text)
        }
        // Sempre prioriza exatamente o texto do arquivo que o usuário mandou executar.
        writeRelativeText(context, bridge.tree, workspaceId, mainRel, source)

        val outUri = ensureFile(context, bridge.tree, rootRunId, "stdout.log")
        val errUri = ensureFile(context, bridge.tree, rootRunId, "stderr.log")
        ProjectFs.writeText(context, outUri, "")
        ProjectFs.writeText(context, errUri, "")
        return PreparedTermuxWorkspace(
            workspacePath, workspacePath, "$workspacePath/$mainRel", mainRel,
            "${bridge.path}/.codeinjector-runs/$runId", outUri, errUri,
            localRoot?.name ?: bridge.path.substringAfterLast('/').ifBlank { "Projeto copiado" }, false
        )
    }

    private fun copyDirectory(
        context: Context, srcTree: Uri, srcDirId: String, dstTree: Uri, dstDirId: String,
        prefix: String, overrides: Map<String, String>, rootId: String,
        count: IntArray, totalBytes: LongArray,
    ) {
        for (entry in ProjectFs.list(context, srcTree, srcDirId)) {
            if (entry.isDir && (entry.name in SKIP_DIRS || entry.name.startsWith(".codeinjector"))) continue
            val rel = if (prefix.isEmpty()) entry.name else "$prefix/${entry.name}"
            val safeRel = sanitizeRelative(rel) ?: continue
            if (entry.isDir) {
                // Keep dstDirId as the workspace root: safeRel already contains the full relative path.
                copyDirectory(context, srcTree, entry.id, dstTree, dstDirId, safeRel, overrides, rootId, count, totalBytes)
            } else {
                count[0]++
                check(count[0] <= MAX_FILES) { "O projeto contém mais de $MAX_FILES arquivos. Remova pastas de build/cache antes de executar." }
                val override = overrides[entry.id] ?: overrides[relativeDocumentId(rootId, entry.id)]
                val bytes = if (override != null) override.toByteArray(Charsets.UTF_8) else readBytes(context, ProjectFs.docUri(srcTree, entry.id), MAX_TOTAL_BYTES - totalBytes[0])
                totalBytes[0] += bytes.size.toLong()
                check(totalBytes[0] <= MAX_TOTAL_BYTES) { "O projeto excede 180 MB; remova recursos grandes ou arquivos gerados." }
                writeRelativeBytes(context, dstTree, dstDirId, safeRel, bytes)
            }
        }
    }

    private fun copyLocalDirectory(
        context: Context, sourceRoot: File, dstTree: Uri, dstRootId: String,
        count: IntArray, totalBytes: LongArray,
    ) {
        val root = sourceRoot.canonicalFile
        val rootPrefix = root.path.trimEnd(File.separatorChar) + File.separator
        val visited = HashSet<String>()
        fun withinRoot(file: File): Boolean = file.path.startsWith(rootPrefix)
        fun visit(dir: File, prefix: String, depth: Int) {
            check(depth <= 32) { "O projeto contém subpastas profundas demais." }
            val canonicalDir = dir.canonicalFile
            check(canonicalDir == root || withinRoot(canonicalDir)) { "Foi encontrado um caminho fora da raiz do projeto." }
            check(visited.add(canonicalDir.path)) { "Foi encontrada uma referência circular de pasta no projeto." }
            val entries = canonicalDir.listFiles() ?: error("Não consegui ler a pasta ${canonicalDir.name}.")
            for (child in entries.sortedBy { it.name.lowercase(Locale.ROOT) }) {
                if (child.name in SKIP_DIRS || child.name.startsWith(".codeinjector")) continue
                val canonical = runCatching { child.canonicalFile }.getOrNull() ?: continue
                if (!withinRoot(canonical)) continue
                val rel = if (prefix.isEmpty()) child.name else "$prefix/${child.name}"
                val safeRel = sanitizeRelative(rel) ?: continue
                if (canonical.isDirectory) {
                    visit(canonical, safeRel, depth + 1)
                } else if (canonical.isFile) {
                    count[0]++
                    check(count[0] <= MAX_FILES) { "O projeto contém mais de $MAX_FILES arquivos. Remova pastas de build/cache antes de executar." }
                    val size = canonical.length()
                    check(size <= MAX_TOTAL_BYTES - totalBytes[0]) { "O projeto excede 180 MB; remova recursos grandes ou arquivos gerados." }
                    val bytes = canonical.readBytes()
                    totalBytes[0] += bytes.size.toLong()
                    writeRelativeBytes(context, dstTree, dstRootId, safeRel, bytes)
                }
            }
        }
        visit(root, "", 0)
    }

    private fun relativeDocumentId(rootId: String, docId: String): String = relativePath(rootId, docId) ?: docId

    private fun readBytes(context: Context, uri: Uri, remaining: Long): ByteArray {
        if (remaining <= 0) error("O projeto excede 180 MB.")
        val out = ByteArrayOutputStream()
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(16 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                check(out.size().toLong() + n <= remaining) { "O projeto excede 180 MB; remova recursos grandes ou arquivos gerados." }
                out.write(buffer, 0, n)
            }
        } ?: throw IOException("Não consegui ler o arquivo $uri")
        return out.toByteArray()
    }

    private fun clearDirectory(context: Context, tree: Uri, directoryId: String) {
        for (entry in ProjectFs.list(context, tree, directoryId)) {
            if (entry.isDir) clearDirectory(context, tree, entry.id)
            check(ProjectFs.delete(context, tree, entry.id)) {
                "Não consegui limpar '${entry.name}' da pasta-ponte. Confira as permissões da pasta compartilhada e tente novamente."
            }
        }
    }

    private fun ensureDirectories(context: Context, tree: Uri, initialParent: String, segments: List<String>): String {
        var parent = initialParent
        for (segment in segments) {
            val clean = sanitizeRelative(segment)?.substringAfterLast('/') ?: error("Nome de pasta inválido")
            var hit = ProjectFs.list(context, tree, parent).firstOrNull { it.isDir && it.name == clean }
            if (hit == null) {
                val uri = ProjectFs.create(context, tree, parent, clean, true) ?: error("Não consegui criar a pasta $clean no armazenamento compartilhado")
                hit = DocEntry(DocumentsContract.getDocumentId(uri), clean, true)
            }
            parent = hit.id
        }
        return parent
    }

    private fun ensureFile(context: Context, tree: Uri, parentId: String, name: String): Uri {
        val existing = ProjectFs.list(context, tree, parentId).firstOrNull { !it.isDir && it.name == name }
        return existing?.let { ProjectFs.docUri(tree, it.id) }
            ?: ProjectFs.create(context, tree, parentId, name, false)
            ?: error("Não consegui criar o arquivo de log $name")
    }

    private fun writeRelativeText(context: Context, tree: Uri, rootId: String, relPath: String, text: String) =
        writeRelativeBytes(context, tree, rootId, relPath, text.toByteArray(Charsets.UTF_8))

    private fun writeRelativeBytes(context: Context, tree: Uri, rootId: String, relPath: String, bytes: ByteArray) {
        val rel = sanitizeRelative(relPath) ?: error("Caminho de arquivo inválido: $relPath")
        val parts = rel.split('/')
        val parent = ensureDirectories(context, tree, rootId, parts.dropLast(1))
        val name = parts.last()
        val uri = ensureFile(context, tree, parent, name)
        context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) }
            ?: error("Não consegui gravar $rel")
    }

    private fun safePythonPath(name: String): String {
        val leaf = name.replace('\\', '/').substringAfterLast('/').trim().replace(Regex("[^A-Za-z0-9_.-]"), "_")
        val safe = leaf.takeIf { it.endsWith(".py", true) && it != ".py" } ?: "main.py"
        val stem = safe.dropLast(3).lowercase(Locale.ROOT)
        return if (stem in setOf("kivy", "pygame", "kivymd", "numpy", "random", "math", "time", "os", "sys", "json", "re", "tkinter"))
            "${safe.dropLast(3)}_script.py" else safe
    }
}
