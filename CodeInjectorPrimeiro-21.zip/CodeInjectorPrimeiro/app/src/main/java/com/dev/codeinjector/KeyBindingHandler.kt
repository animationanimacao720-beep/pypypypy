package com.dev.codeinjector

import androidx.compose.ui.input.key.*

interface EditorActions {
    fun save(); fun saveAs(); fun openFile(); fun newTab(); fun closeTab(); fun switchTab(delta: Int)
    fun runCode(); fun stopCode(); fun undo(); fun redo()
    fun copy(); fun paste(); fun cut()
    fun find(); fun replace(); fun findNext(); fun toggleComment()
    fun indent(); fun outdent()
    fun duplicateLine(); fun moveLine(up: Boolean); fun deleteLine(); fun selectLine()
    fun goToLine(); fun format(); fun toggleSidebar()
    /** Setas do teclado físico: [extend] = Shift (estende a seleção), [word] = Ctrl (pula palavra). */
    fun moveCursorKey(dx: Int, dy: Int, extend: Boolean, word: Boolean)
    /** Alt+1..Alt+9: aplica a n-ésima sugestão de sintaxe visível (1 = primeira). Retorna false se não há. */
    fun pickSuggestion(n: Int): Boolean
    /** Retorna true se fechou algo (busca, console...). */
    fun escape(): Boolean
}

/**
 * Atalhos do teclado físico; atalhos personalizados são avaliados antes dos padrões e substituem o padrão da mesma ação.
 * Setas (com Shift/Ctrl) são tratadas aqui; Home/End, Ctrl+A, Delete etc. pelo BasicTextField. Alt+1..9 aplica sugestões.
 */
class KeyBindingHandler(
    private val a: EditorActions,
    private val customBindings: () -> List<CustomShortcutBinding> = { emptyList() },
    private val runCustomAction: (String) -> Unit = {}
) {
    private fun hasCustom(actionId: String): Boolean = customBindings().any { it.actionId == actionId }

    fun handle(e: KeyEvent): Boolean {
        if (e.type != KeyEventType.KeyDown) return false
        val keyCode = e.key.nativeKeyCode
        val custom = customBindings().firstOrNull {
            it.matches(keyCode, e.isCtrlPressed, e.isAltPressed, e.isShiftPressed, e.isMetaPressed)
        }
        if (custom != null) {
            runCustomAction(custom.actionId)
            return true
        }
        val ctrl = e.isCtrlPressed; val shift = e.isShiftPressed; val alt = e.isAltPressed
        val k = e.key
        val digit = when (k) {
            Key.One -> 1; Key.Two -> 2; Key.Three -> 3; Key.Four -> 4; Key.Five -> 5
            Key.Six -> 6; Key.Seven -> 7; Key.Eight -> 8; Key.Nine -> 9; else -> 0
        }
        return when {
            alt && !ctrl && digit > 0 -> a.pickSuggestion(digit)
            !alt && (k == Key.DirectionLeft || k == Key.DirectionRight || k == Key.DirectionUp || k == Key.DirectionDown) -> {
                val dx = if (k == Key.DirectionLeft) -1 else if (k == Key.DirectionRight) 1 else 0
                val dy = if (k == Key.DirectionUp) -1 else if (k == Key.DirectionDown) 1 else 0
                a.moveCursorKey(dx, dy, extend = shift, word = ctrl && dy == 0); true
            }
            alt && k == Key.DirectionUp -> { if (!hasCustom("moveLineUp")) a.moveLine(true); true }
            alt && k == Key.DirectionDown -> { if (!hasCustom("moveLineDown")) a.moveLine(false); true }
            shift && k == Key.F5 -> { if (!hasCustom("stop")) a.stopCode(); true }
            ctrl && k == Key.Period -> { if (!hasCustom("stop")) a.stopCode(); true }
            (ctrl && k == Key.R) || (ctrl && k == Key.Enter) || k == Key.F5 -> { if (!hasCustom("run")) a.runCode(); true }
            ctrl && shift && k == Key.Z -> { if (!hasCustom("redo")) a.redo(); true }
            ctrl && shift && k == Key.S -> { if (!hasCustom("saveAs")) a.saveAs(); true }
            ctrl && shift && k == Key.K -> { if (!hasCustom("deleteLine")) a.deleteLine(); true }
            ctrl && shift && k == Key.F -> { if (!hasCustom("format")) a.format(); true }
            ctrl && k == Key.Tab -> {
                if (shift) { if (!hasCustom("previousTab")) a.switchTab(-1) }
                else if (!hasCustom("nextTab")) a.switchTab(1)
                true
            }
            ctrl && k == Key.Z -> { if (!hasCustom("undo")) a.undo(); true }
            ctrl && k == Key.Y -> { if (!hasCustom("redo")) a.redo(); true }
            ctrl && k == Key.S -> { if (!hasCustom("save")) a.save(); true }
            ctrl && k == Key.C -> { if (!hasCustom("copy")) a.copy(); true }
            ctrl && k == Key.V -> { if (!hasCustom("paste")) a.paste(); true }
            ctrl && k == Key.X -> { if (!hasCustom("cut")) a.cut(); true }
            ctrl && k == Key.F -> { if (!hasCustom("find")) a.find(); true }
            ctrl && k == Key.H -> { if (!hasCustom("replace")) a.replace(); true }
            ctrl && k == Key.B -> { if (!hasCustom("toggleSidebar")) a.toggleSidebar(); true }
            ctrl && k == Key.Slash -> { if (!hasCustom("toggleComment")) a.toggleComment(); true }
            ctrl && k == Key.D -> { if (!hasCustom("duplicateLine")) a.duplicateLine(); true }
            ctrl && k == Key.L -> { if (!hasCustom("selectLine")) a.selectLine(); true }
            ctrl && k == Key.G -> { if (!hasCustom("goToLine")) a.goToLine(); true }
            ctrl && k == Key.N -> { if (!hasCustom("newTab")) a.newTab(); true }
            ctrl && k == Key.O -> { if (!hasCustom("openFile")) a.openFile(); true }
            ctrl && k == Key.W -> { if (!hasCustom("closeTab")) a.closeTab(); true }
            k == Key.F3 -> { if (!hasCustom("findNext")) a.findNext(); true }
            k == Key.Escape -> a.escape()
            k == Key.Tab -> {
                if (shift) { if (!hasCustom("outdent")) a.outdent() }
                else if (!hasCustom("indent")) a.indent()
                true
            }
            else -> false
        }
    }
}
