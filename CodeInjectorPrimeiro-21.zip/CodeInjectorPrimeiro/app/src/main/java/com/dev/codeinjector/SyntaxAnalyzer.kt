package com.dev.codeinjector

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle

enum class Severity { ERROR, WARNING }

/** Correção rápida: substitui [start, end) por [replacement]. */
data class QuickFix(val label: String, val start: Int, val end: Int, val replacement: String)

data class Diagnostic(
    val start: Int, val end: Int,          // intervalo absoluto no texto (para sublinhado)
    val line: Int, val column: Int,        // 1-based
    val severity: Severity,
    val kind: String,                      // SyntaxError, IndentationError, NameError...
    val message: String,                   // mensagem amigável (pt-BR)
    val suggestion: String? = null,
    val fix: QuickFix? = null
)

/** Problema bruto: mensagem original do CPython (ou gerada pelo scanner rápido no mesmo formato). */
data class PyIssue(
    val kind: String, val type: String, val msg: String,
    val line: Int, val col: Int, val endLine: Int, val endCol: Int,
    val suggest: String = ""
)

enum class Tok { KEYWORD, BUILTIN, STRING, COMMENT, NUMBER, DECORATOR, FUNCTION, CLASS, SELF, CONSTANT, CALL, ATTR, OPERATOR, BRACKET, MODULE }
class TokSpan(val start: Int, val end: Int, val tok: Tok)

private class LexResult(
    val spans: List<TokSpan>, val issues: List<PyIssue>,
    val inStr: BooleanArray, val comment: IntArray,
    val depthStart: IntArray, val depthEnd: IntArray, val cont: BooleanArray
)

object SyntaxAnalyzer {
    val KEYWORDS = listOf(
        "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class", "continue", "def", "del",
        "elif", "else", "except", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "nonlocal",
        "not", "or", "pass", "raise", "return", "try", "while", "with", "yield", "match", "case"
    )
    val BUILTIN_FUNCS = listOf(
        "print", "input", "len", "range", "int", "str", "float", "bool", "list", "dict", "set", "tuple", "open",
        "enumerate", "zip", "map", "filter", "sorted", "reversed", "sum", "min", "max", "abs", "round", "isinstance",
        "type", "super", "any", "all", "chr", "ord", "repr", "format", "hasattr", "getattr", "setattr", "iter", "next",
        "divmod", "pow", "hex", "bin", "id", "dir", "vars", "callable", "bytes", "frozenset", "object", "slice"
    )
    val BUILTIN_OTHERS = listOf(
        "Exception", "ValueError", "TypeError", "KeyError", "IndexError", "NameError", "AttributeError", "ZeroDivisionError",
        "FileNotFoundError", "ImportError", "RuntimeError", "StopIteration", "KeyboardInterrupt", "SystemExit",
        "OSError", "NotImplementedError", "AssertionError", "Ellipsis", "NotImplemented"
    )
    private val KW_SET = KEYWORDS.toHashSet()
    private val BUILTIN_SET = (BUILTIN_FUNCS + BUILTIN_OTHERS).toHashSet()

    // ------------------------------------------------------------------ lexer (realce + estrutura)
    @Volatile private var lexCache: Pair<String, LexResult>? = null

    private fun lexCached(text: String): LexResult {
        lexCache?.let { if (it.first == text) return it.second }
        return lex(text).also { lexCache = text to it }
    }

    private fun lex(text: String): LexResult {
        val n = text.length
        val lineCount = text.count { it == '\n' } + 1
        val spans = ArrayList<TokSpan>()
        val issues = ArrayList<PyIssue>()
        val inStr = BooleanArray(lineCount)
        val comment = IntArray(lineCount) { -1 }
        val depthStart = IntArray(lineCount)
        val depthEnd = IntArray(lineCount)
        val cont = BooleanArray(lineCount)
        class Open(val ch: Char, val line: Int, val col: Int)
        val stack = ArrayList<Open>()
        var i = 0; var line = 0; var lineStart = 0
        var expectName: Tok? = null
        var importLine = false

        fun endLine(p: Int) {
            depthEnd[line] = stack.size; line++; lineStart = p + 1
            if (line < lineCount) depthStart[line] = stack.size
        }

        fun scanString(startPos: Int, q: Int): Int {
            val quote = text[q]
            val triple = text.startsWith("$quote$quote$quote", q)
            val startLine = line; val startCol = startPos - lineStart
            var j = q + if (triple) 3 else 1
            while (j < n) {
                val ch = text[j]
                if (ch == '\\') {
                    if (j + 1 < n && text[j + 1] == '\n') { endLine(j + 1); if (line < lineCount) inStr[line] = true }
                    j += 2; continue
                }
                if (ch == '\n') {
                    if (!triple) {
                        issues += PyIssue("syntax", "SyntaxError", "unterminated string literal (detected at line ${startLine + 1})",
                            startLine + 1, startCol + 1, startLine + 1, startCol + 2)
                        spans += TokSpan(startPos, j, Tok.STRING); return j
                    }
                    endLine(j); if (line < lineCount) inStr[line] = true
                    j++; continue
                }
                if (triple) {
                    if (ch == quote && text.startsWith("$quote$quote$quote", j)) { j += 3; spans += TokSpan(startPos, j, Tok.STRING); return j }
                } else if (ch == quote) { j++; spans += TokSpan(startPos, j, Tok.STRING); return j }
                j++
            }
            issues += if (triple)
                PyIssue("syntax", "SyntaxError", "unterminated triple-quoted string literal (detected at line $lineCount)",
                    startLine + 1, startCol + 1, startLine + 1, startCol + 4)
            else PyIssue("syntax", "SyntaxError", "unterminated string literal (detected at line ${startLine + 1})",
                startLine + 1, startCol + 1, startLine + 1, startCol + 2)
            spans += TokSpan(startPos, n, Tok.STRING); return n
        }

        fun prevSig(p: Int): Char {
            var k = p - 1
            while (k >= lineStart && (text[k] == ' ' || text[k] == '\t')) k--
            return if (k >= lineStart) text[k] else '\u0000'
        }
        fun nextSig(p: Int): Char {
            var k = p
            while (k < n && (text[k] == ' ' || text[k] == '\t')) k++
            return if (k < n) text[k] else '\u0000'
        }

        while (i < n) {
            val c = text[i]
            when {
                c == '\n' -> { endLine(i); importLine = false; i++ }
                c == '\\' && i + 1 < n && text[i + 1] == '\n' -> { cont[line] = true; i++ }
                c == '#' -> {
                    val e = text.indexOf('\n', i).let { if (it < 0) n else it }
                    comment[line] = i; spans += TokSpan(i, e, Tok.COMMENT); i = e
                }
                c == '"' || c == '\'' -> i = scanString(i, i)
                c.isLetter() || c == '_' -> {
                    var j = i
                    while (j < n && (text[j].isLetterOrDigit() || text[j] == '_')) j++
                    val word = text.substring(i, j)
                    if (j < n && (text[j] == '"' || text[j] == '\'') && word.length <= 2 && word.lowercase().all { it in "rbuf" }) {
                        i = scanString(i, j)
                    } else {
                        val isAttr = prevSig(i) == '.'
                        val was = expectName; expectName = null
                        val atStmtStart = text.substring(lineStart, i).isBlank()
                        val tok: Tok? = when {
                            was != null -> was
                            importLine && word !in KW_SET -> Tok.MODULE
                            isAttr -> if (nextSig(j) == '(') Tok.CALL else Tok.ATTR
                            word == "True" || word == "False" || word == "None" -> Tok.CONSTANT
                            word in KW_SET -> Tok.KEYWORD
                            word == "self" || word == "cls" -> Tok.SELF
                            word in BUILTIN_SET -> Tok.BUILTIN
                            word[0].isUpperCase() && word.any { it.isLowerCase() } -> Tok.CLASS
                            word.length > 1 && word.none { it.isLowerCase() } && word.any { it.isLetter() } && nextSig(j) != '(' -> Tok.CONSTANT
                            nextSig(j) == '(' -> Tok.CALL
                            else -> null
                        }
                        if (!isAttr && was == null) {
                            if (word == "def") expectName = Tok.FUNCTION
                            else if (word == "class") expectName = Tok.CLASS
                            else if ((word == "import" || word == "from") && atStmtStart) importLine = true
                        }
                        if (tok != null) spans += TokSpan(i, j, tok)
                        i = j
                    }
                }
                c.isDigit() || (c == '.' && i + 1 < n && text[i + 1].isDigit()) -> {
                    var j = i + 1
                    while (j < n) {
                        val d = text[j]
                        if (d.isLetterOrDigit() || d == '_' || d == '.') j++
                        else if ((d == '+' || d == '-') && (text[j - 1] == 'e' || text[j - 1] == 'E') && !text.startsWith("0x", i)) j++
                        else break
                    }
                    spans += TokSpan(i, j, Tok.NUMBER); i = j
                }
                c == '@' && text.substring(lineStart, i).isBlank() -> {
                    var j = i + 1
                    while (j < n && (text[j].isLetterOrDigit() || text[j] == '_' || text[j] == '.')) j++
                    spans += TokSpan(i, j, Tok.DECORATOR); i = j
                }
                c == '(' || c == '[' || c == '{' -> { stack += Open(c, line, i - lineStart); spans += TokSpan(i, i + 1, Tok.BRACKET); i++ }
                c == ')' || c == ']' || c == '}' -> {
                    val want = when (c) { ')' -> '('; ']' -> '['; else -> '{' }
                    val col = i - lineStart
                    if (stack.isEmpty()) issues += PyIssue("syntax", "SyntaxError", "unmatched '$c'", line + 1, col + 1, line + 1, col + 2)
                    else {
                        val top = stack.removeAt(stack.lastIndex)
                        if (top.ch != want) issues += PyIssue("syntax", "SyntaxError",
                            "closing parenthesis '$c' does not match opening parenthesis '${top.ch}'" +
                                (if (top.line != line) " on line ${top.line + 1}" else ""),
                            line + 1, col + 1, line + 1, col + 2)
                    }
                    spans += TokSpan(i, i + 1, Tok.BRACKET)
                    i++
                }
                else -> {
                    if (c in "+-*/%=<>!&|^~:,;.@") spans += TokSpan(i, i + 1, Tok.OPERATOR)
                    i++
                }
            }
        }
        depthEnd[line.coerceAtMost(lineCount - 1)] = stack.size
        stack.forEach { issues += PyIssue("syntax", "SyntaxError", "'${it.ch}' was never closed", it.line + 1, it.col + 1, it.line + 1, it.col + 2) }
        return LexResult(spans, issues, inStr, comment, depthStart, depthEnd, cont)
    }

    fun highlight(text: String, theme: CodeTheme): AnnotatedString = buildAnnotatedString {
        append(text)
        for (s in lexCached(text).spans) {
            val st = when (s.tok) {
                Tok.KEYWORD -> SpanStyle(color = theme.keyword)
                Tok.BUILTIN -> SpanStyle(color = theme.builtin)
                Tok.STRING -> SpanStyle(color = theme.string)
                Tok.COMMENT -> SpanStyle(color = theme.comment, fontStyle = FontStyle.Italic)
                Tok.NUMBER -> SpanStyle(color = theme.number)
                Tok.DECORATOR -> SpanStyle(color = theme.decorator)
                Tok.FUNCTION -> SpanStyle(color = theme.function)
                Tok.CLASS -> SpanStyle(color = theme.className)
                Tok.SELF -> SpanStyle(color = theme.self, fontStyle = FontStyle.Italic)
                Tok.CONSTANT -> SpanStyle(color = theme.constant)
                Tok.CALL -> SpanStyle(color = theme.call)
                Tok.ATTR -> SpanStyle(color = theme.attr)
                Tok.OPERATOR -> SpanStyle(color = theme.operator)
                Tok.BRACKET -> SpanStyle(color = theme.bracket)
                Tok.MODULE -> SpanStyle(color = theme.module)
            }
            addStyle(st, s.start.coerceIn(0, text.length), s.end.coerceIn(0, text.length))
        }
    }

    // ------------------------------------------------------------------ análise rápida (Kotlin, instantânea)
    private val COMPOUND = Regex("^(?:async\\s+)?(?:def|class|if|elif|else|for|while|try|except|finally|with)\\b")
    private val PY2_PRINT = Regex("^print\\s+(?![=(.,\\s])")

    private fun fastIssues(text: String): List<PyIssue> {
        val lx = lexCached(text)
        val out = ArrayList<PyIssue>(lx.issues)
        val lines = text.split("\n")
        val ls = IntArray(lines.size); var off = 0
        lines.forEachIndexed { i, l -> ls[i] = off; off += l.length + 1 }
        val stack = arrayListOf(0)
        var prevIndent = 0; var prevHeader = false; var headerKw = ""; var headerLine = -1
        for (idx in lines.indices) {
            if (lx.inStr[idx] || lx.depthStart[idx] > 0 || (idx > 0 && lx.cont[idx - 1])) continue
            val raw = lines[idx].trimEnd('\r')
            val cs = lx.comment[idx]
            val codePart = if (cs >= 0) text.substring(ls[idx], cs) else raw
            val trimmed = codePart.trim()
            if (trimmed.isEmpty()) continue
            val lead = raw.takeWhile { it == ' ' || it == '\t' }
            val indent = lead.count { it == ' ' } + 8 * lead.count { it == '\t' }
            if (' ' in lead && '\t' in lead)
                out += PyIssue("syntax", "TabError", "inconsistent use of tabs and spaces in indentation", idx + 1, 1, idx + 1, lead.length + 1)
            if (prevHeader) {
                if (indent <= prevIndent)
                    out += PyIssue("syntax", "IndentationError", "expected an indented block after '$headerKw' statement on line ${headerLine + 1}",
                        idx + 1, lead.length + 1, idx + 1, lead.length + 2)
                else stack.add(indent)
            } else if (indent > prevIndent) {
                out += PyIssue("syntax", "IndentationError", "unexpected indent", idx + 1, lead.length + 1, idx + 1, lead.length + 2)
            } else if (indent < prevIndent) {
                while (stack.size > 1 && stack.last() > indent) stack.removeAt(stack.lastIndex)
                if (stack.last() != indent)
                    out += PyIssue("syntax", "IndentationError", "unindent does not match any outer indentation level", idx + 1, lead.length + 1, idx + 1, lead.length + 2)
            }
            val codeEndCol = codePart.trimEnd().length
            if (lx.depthEnd[idx] == 0 && !lx.cont[idx] && COMPOUND.containsMatchIn(trimmed) && ':' !in trimmed)
                out += PyIssue("syntax", "SyntaxError", "expected ':'", idx + 1, codeEndCol + 1, idx + 1, codeEndCol + 2)
            if (PY2_PRINT.containsMatchIn(trimmed))
                out += PyIssue("syntax", "SyntaxError", "Missing parentheses in call to 'print'. Did you mean print(...)?", idx + 1, lead.length + 1, idx + 1, codeEndCol + 1)
            prevIndent = indent
            prevHeader = COMPOUND.containsMatchIn(trimmed) && trimmed.endsWith(":")
            if (prevHeader) { headerKw = trimmed.removePrefix("async").trim().takeWhile { it.isLetter() }; headerLine = idx }
        }
        if (prevHeader) out += PyIssue("syntax", "IndentationError",
            "expected an indented block after '$headerKw' statement on line ${headerLine + 1}", headerLine + 1, 1, headerLine + 1, 2)
        return out
    }

    fun analyzeFast(text: String): List<Diagnostic> = toDiagnostics(fastIssues(text), text)

    /** Parser real do CPython (via Chaquopy); se ainda não iniciou, cai na análise rápida. */
    fun analyze(text: String, fileName: String = "<editor>"): List<Diagnostic> {
        val issues = PyRunner.check(text, fileName) ?: return analyzeFast(text)
        return toDiagnostics(issues, text)
    }

    // ------------------------------------------------------------------ conversão + tradução amigável
    private class Ctx(val text: String, val lines: List<String>, val ls: IntArray, val lx: LexResult)

    private fun toDiagnostics(issues: List<PyIssue>, text: String): List<Diagnostic> {
        if (issues.isEmpty()) return emptyList()
        val lines = text.split("\n")
        val ls = IntArray(lines.size); var off = 0
        lines.forEachIndexed { i, l -> ls[i] = off; off += l.length + 1 }
        val ctx = Ctx(text, lines, ls, lexCached(text))
        val out = ArrayList<Diagnostic>()
        for (i in issues.sortedWith(compareBy({ it.line }, { it.col })).take(100)) {
            val li = (i.line - 1).coerceIn(0, lines.lastIndex)
            val lineText = lines[li]
            val colIdx = (i.col - 1).coerceIn(0, lineText.length)
            var start = ls[li] + colIdx
            var end = if (i.endLine == i.line) ls[li] + (i.endCol - 1).coerceIn(colIdx, lineText.length) else ls[li] + lineText.length
            if (end <= start) end = start + 1
            if (start >= text.length && text.isNotEmpty()) { start = text.length - 1; end = text.length }
            if (colIdx >= lineText.trimEnd().length && lineText.isNotBlank()) { start = ls[li] + lineText.trimEnd().length - 1; end = start + 1 }
            val (msg, sug, fix) = translate(i, ctx, li, start, end)
            val sev = if (i.kind == "warn") Severity.WARNING else Severity.ERROR
            val d = Diagnostic(start.coerceAtLeast(0), end.coerceAtLeast(start + 1), li + 1, colIdx + 1, sev, i.type, msg, sug, fix)
            if (out.none { it.line == d.line && it.message == d.message }) out += d
        }
        return out
    }

    private fun closerOf(c: Char) = when (c) { '(' -> ')'; '[' -> ']'; else -> '}' }
    private fun openerOf(c: Char) = when (c) { ')' -> '('; ']' -> '['; else -> '{' }
    private fun leadingWs(s: String) = s.takeWhile { it == ' ' || it == '\t' }
    private fun codeEndOffset(c: Ctx, li: Int): Int {
        val cs = c.lx.comment.getOrElse(li) { -1 }
        val code = if (cs >= 0) c.text.substring(c.ls[li], cs) else c.lines[li]
        return c.ls[li] + code.trimEnd().length
    }
    private fun prevIndent(c: Ctx, li: Int): String {
        var k = li - 1
        while (k >= 0 && c.lines[k].isBlank()) k--
        return if (k >= 0) leadingWs(c.lines[k]) else ""
    }

    private fun translate(i: PyIssue, c: Ctx, li: Int, start: Int, end: Int): Triple<String, String?, QuickFix?> {
        val m = i.msg
        val ls = c.ls[li]
        val lineText = c.lines[li]
        val wsLen = leadingWs(lineText).length
        if (i.kind == "warn") {
            val name = Regex("'(.+)'").find(m)?.groupValues?.get(1) ?: "?"
            return if (i.type == "UnusedImport") {
                val fix = if (i.suggest == "line") QuickFix("Remover import", ls, minOf(ls + lineText.length + 1, c.text.length), "") else null
                Triple("Aviso: '$name' foi importado mas não é usado", "Remova o import se não precisar dele", fix)
            } else Triple("Aviso: a variável '$name' recebe um valor mas nunca é usada", "Use o valor ou remova a variável", null)
        }
        if (i.kind == "name") {
            val name = Regex("name '(.+)' is not defined").find(m)?.groupValues?.get(1) ?: "?"
            return if (i.suggest.isNotBlank())
                Triple("O nome '$name' não está definido", "Você quis dizer '${i.suggest}'?", QuickFix("Trocar por '${i.suggest}'", start, end, i.suggest))
            else Triple("O nome '$name' não está definido",
                "Defina '$name' antes de usar, importe-o ou confira a digitação (maiúsculas importam)", null)
        }
        return when {
            m == "expected ':'" -> Triple("Falta ':' no final desta linha", "Adicione ':' ao fim da linha ${i.line}",
                codeEndOffset(c, li).let { QuickFix("Inserir ':'", it, it, ":") })
            m.startsWith("unterminated triple-quoted") -> Triple("String de aspas triplas não fechada",
                "Feche com \"\"\" (ou ''') — ela começa na linha ${i.line}", null)
            m.startsWith("unterminated string literal") -> {
                val q = lineText.drop((i.col - 1).coerceAtLeast(0)).firstOrNull { it == '"' || it == '\'' } ?: '"'
                val e = ls + lineText.trimEnd().length
                Triple("String não fechada: falta a aspa de fechamento", "Feche a string com $q no fim da linha", QuickFix("Inserir $q", e, e, q.toString()))
            }
            m.endsWith("was never closed") -> {
                val ch = m[1]; val cl = closerOf(ch); val e = codeEndOffset(c, li)
                Triple("O '$ch' da linha ${i.line} nunca foi fechado", "Feche com '$cl'", QuickFix("Inserir '$cl' no fim da linha", e, e, cl.toString()))
            }
            m.startsWith("unmatched '") -> {
                val ch = m[11]
                Triple("'$ch' sobrando: não há '${openerOf(ch)}' correspondente", "Remova o '$ch'", QuickFix("Remover '$ch'", start, start + 1, ""))
            }
            m.startsWith("closing parenthesis") -> {
                val g = Regex("closing parenthesis '(.)' does not match opening parenthesis '(.)'").find(m)?.groupValues
                if (g == null) Triple("Parênteses/colchetes não combinam", null, null) else {
                    val cl = g[1][0]; val op = g[2][0]; val right = closerOf(op)
                    Triple("O '$cl' não fecha o '$op' aberto", "Use '$right' no lugar de '$cl'", QuickFix("Trocar por '$right'", start, start + 1, right.toString()))
                }
            }
            m.startsWith("expected an indented block") -> {
                val hl = Regex("on line (\\d+)").find(m)?.groupValues?.get(1)?.toIntOrNull() ?: i.line
                val what = Regex("after (.+?) on line").find(m)?.groupValues?.get(1)?.removeSuffix(" statement")?.trim('\'') ?: "bloco"
                val hIndent = leadingWs(c.lines.getOrElse(hl - 1) { "" })
                if (li == hl - 1) {
                    val e = codeEndOffset(c, li)
                    Triple("Falta o bloco indentado depois de '$what' (linha $hl)", "Escreva o corpo do bloco, nem que seja 'pass'",
                        QuickFix("Inserir 'pass'", e, e, "\n$hIndent\tpass"))
                } else Triple("Falta indentar o bloco depois de '$what' (linha $hl)", "Recue esta linha com um tab a mais que a linha $hl",
                    QuickFix("Indentar com tab", ls, ls + wsLen, "$hIndent\t"))
            }
            m == "unexpected indent" -> Triple("Indentação inesperada", "Remova os espaços extras no início da linha",
                QuickFix("Alinhar com a linha anterior", ls, ls + wsLen, prevIndent(c, li)))
            m.startsWith("unindent does not match") -> {
                val levels = (0 until li).filter { c.lines[it].isNotBlank() }.map { leadingWs(c.lines[it]).length }.distinct()
                val best = levels.minByOrNull { kotlin.math.abs(it - wsLen) } ?: 0
                Triple("A indentação desta linha não coincide com nenhum bloco anterior", "Alinhe com um nível já usado acima (use 4 espaços por nível)",
                    QuickFix("Alinhar em $best espaços", ls, ls + wsLen, " ".repeat(best)))
            }
            m.contains("inconsistent use of tabs") -> Triple("Mistura de tabs e espaços na indentação", "Use só espaços (4 por nível)",
                QuickFix("Trocar tabs por espaços", ls, ls + wsLen, leadingWs(lineText).replace("\t", "    ")))
            m.startsWith("Missing parentheses in call to 'print'") -> {
                val code = lineText.substring(0, (codeEndOffset(c, li) - ls).coerceIn(0, lineText.length))
                val g = Regex("^(\\s*)print\\s+(.*)$").find(code)
                Triple("No Python 3, print precisa de parênteses", "Escreva print(...) com o que quer mostrar dentro",
                    g?.let { QuickFix("Trocar por print(...)", ls + it.groupValues[1].length, ls + code.length, "print(${it.groupValues[2]})") })
            }
            m.contains("Maybe you meant '==' or ':='") || m.contains("Maybe you meant '=='") -> {
                val code = lineText.substring(0, (codeEndOffset(c, li) - ls).coerceIn(0, lineText.length))
                var k = -1
                for (p in code.indices) if (code[p] == '=' && (p == 0 || code[p - 1] !in "=!<>+-*/%&|^:") && code.getOrNull(p + 1) != '=') { k = p; break }
                Triple("Use '==' para comparar (um único '=' é atribuição)", "Troque '=' por '=='",
                    if (k >= 0) QuickFix("Trocar por '=='", ls + k, ls + k + 1, "==") else null)
            }
            m.startsWith("cannot assign to") -> Triple("Não dá para atribuir a isso", "À esquerda do '=' deve haver um nome de variável (para comparar, use '==')", null)
            m.contains("Perhaps you forgot a comma") -> Triple("Talvez falte uma vírgula entre os itens", "Confira se não falta ',' entre os elementos desta linha", null)
            m.startsWith("expected 'except' or 'finally'") -> Triple("O 'try' precisa de um 'except' ou 'finally'", "Adicione 'except Exception:' depois do bloco try", null)
            m.contains("outside function") -> Triple("'return' só pode ser usado dentro de uma função (def)", "Mova esta linha para dentro de uma função", null)
            m.contains("outside loop") || m.contains("not properly in loop") -> Triple("'break'/'continue' só funcionam dentro de for ou while", null, null)
            m.startsWith("invalid character") -> {
                val ch = Regex("invalid character '(.)'").find(m)?.groupValues?.get(1)?.firstOrNull()
                val rep = when (ch) { '“', '”' -> "\""; '‘', '’' -> "'"; '–', '—' -> "-"; else -> null }
                Triple("Caractere inválido '${ch ?: "?"}' (provavelmente copiado de um editor de texto)",
                    rep?.let { "Troque por $it" }, rep?.let { QuickFix("Trocar por $it", start, start + 1, it) })
            }
            m.startsWith("invalid decimal literal") -> Triple("Número inválido: há letras coladas num número", "Nomes de variáveis não podem começar com dígito", null)
            m.startsWith("unexpected EOF") -> Triple("O arquivo terminou antes de fechar um bloco ou parêntese", null, null)
            m.startsWith("positional argument follows keyword") -> Triple("Argumento posicional depois de argumento nomeado", "Coloque os argumentos sem nome antes dos nome=valor", null)
            m.startsWith("f-string") -> Triple("Erro dentro do f-string: ${m.removePrefix("f-string: ")}", null, null)
            m == "invalid syntax" -> invalidSyntax(i, c, li, start, end)
            else -> Triple("${i.type}: $m", null, null)
        }
    }

    private fun invalidSyntax(i: PyIssue, c: Ctx, li: Int, start: Int, end: Int): Triple<String, String?, QuickFix?> {
        val ls = c.ls[li]; val line = c.lines[li]
        Regex("^(\\s*)else\\s+if\\b").find(line)?.let {
            val s = ls + it.groupValues[1].length
            return Triple("'else if' não existe em Python", "Use 'elif'", QuickFix("Trocar por 'elif'", s, ls + it.value.length, "elif"))
        }
        val op = Regex("&&|\\|\\|").find(line)
        if (op != null) {
            val rep = if (op.value == "&&") "and" else "or"
            return Triple("'${op.value}' não existe em Python", "Use '$rep'", QuickFix("Trocar por '$rep'", ls + op.range.first, ls + op.range.last + 1, rep))
        }
        return Triple("Sintaxe inválida neste ponto", "Confira o trecho marcado e a linha anterior (parênteses, aspas ou vírgulas faltando)", null)
    }

    // ------------------------------------------------------------------ erro de execução -> diagnóstico
    fun fromRuntime(e: PyRuntimeError, text: String): Diagnostic? {
        val lines = text.split("\n")
        if (e.line < 1 || e.line > lines.size) return null
        val li = e.line - 1
        var ls = 0; for (k in 0 until li) ls += lines[k].length + 1
        val raw = lines[li]
        val lead = leadingWs(raw).length
        val start = ls + if (e.col > 0) (e.col - 1).coerceIn(0, raw.length) else lead
        val end = ls + raw.trimEnd().length.coerceAtLeast(lead + 1)
        val msg: String; var sug: String? = null; var fix: QuickFix? = null
        when (e.type) {
            "NameError" -> {
                val name = Regex("name '(.+)' is not defined").find(e.message)?.groupValues?.get(1)
                msg = "O nome '${name ?: "?"}' não está definido"
                if (e.suggestion.isNotBlank() && name != null) {
                    sug = "Você quis dizer '${e.suggestion}'?"
                    val p = raw.indexOf(name)
                    if (p >= 0) fix = QuickFix("Trocar por '${e.suggestion}'", ls + p, ls + p + name.length, e.suggestion)
                } else sug = "Defina a variável/função antes de usá-la"
            }
            "ZeroDivisionError" -> { msg = "Divisão por zero"; sug = "Verifique o divisor antes de dividir" }
            "IndexError" -> { msg = "Índice fora dos limites da lista"; sug = "Use um índice entre 0 e len(lista)-1" }
            "KeyError" -> { msg = "A chave ${e.message} não existe no dicionário"; sug = "Use dicionario.get(chave) ou confira a chave" }
            "ValueError" -> { msg = "Valor inválido: ${e.message}"; sug = if ("invalid literal for int" in e.message) "O texto não é um número inteiro válido" else null }
            "TypeError" -> { msg = "Tipos incompatíveis: ${e.message}"; sug = "Converta com int(), str() ou float() quando necessário" }
            "AttributeError" -> { msg = "Atributo inexistente: ${e.message}"; sug = null }
            "ModuleNotFoundError", "ImportError" -> { msg = "Módulo não disponível: ${e.message}"; sug = "Só a biblioteca padrão do Python está incluída" }
            "FileNotFoundError" -> { msg = "Arquivo não encontrado: ${e.message}"; sug = "Arquivos são lidos/gravados na pasta de trabalho do app" }
            "RecursionError" -> { msg = "Recursão infinita"; sug = "Falta uma condição de parada na função recursiva" }
            else -> { msg = "${e.type}: ${e.message}" }
        }
        return Diagnostic(start, end.coerceAtLeast(start + 1), e.line, (start - ls) + 1, Severity.ERROR, e.type, msg, sug, fix)
    }
}
