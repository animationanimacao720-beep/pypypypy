package com.dev.codeinjector

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PythonCodeTemplatesUnitTest {
    @Test fun defShortcutInsertsFunctionBodyAndPlacesCursorAfterName() {
        val candidate = PythonCodeTemplates.suggestions("de", "").first { it.label == "def" }
        assertEquals("def name():\n\treturn", candidate.insertion.text)
        val insertion = candidate.insertion
        assertEquals(insertion.text.length - "def ".length, insertion.selectionStartBack!!)
        assertEquals(insertion.text.length - "def name".length, insertion.selectionEndBack!!)
    }

    @Test fun classShortcutIncludesMethodBody() {
        val candidate = PythonCodeTemplates.suggestions("cla", "").first { it.label == "class" }
        assertTrue(candidate.insertion.text.startsWith("class Name():\n\tdef method(self):"))
        assertTrue(candidate.insertion.text.endsWith("\t\tpass"))
    }

    @Test fun builtInSnippetsUseTabIndentation() {
        val converted = PythonCodeTemplates.normalizeIndentationToTabs("if ok:\n    pass\n        run()")
        assertEquals("if ok:\n\tpass\n\t\trun()", converted)
        PythonCodeTemplates.all.forEach { template ->
            val code = template.insertion().text
            assertFalse("Four-space indent remains in ${template.trigger}", Regex("(?m)^ {4}").containsMatchIn(code))
        }
    }

    @Test fun frameworkShortcutsInsertCompleteExamplesAndImportVariants() {
        val kivy = PythonCodeTemplates.suggestions("kiv", "").first { it.label.contains("Kivy — aplicação") }
        assertTrue(kivy.insertion.text.contains("from kivy.app import App"))
        assertTrue(kivy.insertion.text.contains("MyApp().run()"))
        val pygame = PythonCodeTemplates.suggestions("pygame", "").first { it.label.contains("Pygame — loop") }
        assertTrue(pygame.insertion.text.contains("while running:"))
        assertTrue(pygame.insertion.text.contains("pygame.event.get()"))
        assertTrue(PythonCodeTemplates.suggestions("kiv", "").any { it.label.contains("imports comuns") })
    }

    @Test fun importContextSuggestsModuleNamesInsteadOfReplacingImportStatement() {
        val candidates = PythonCodeTemplates.suggestions("ki", "import ")
        assertTrue(candidates.any { it.label == "kivy" && !it.isTemplate && it.insertion.text == "kivy" })
        assertFalse(candidates.any { it.label.contains("aplicação") })
        val fromCandidates = PythonCodeTemplates.suggestions("PyS", "from ")
        assertTrue(fromCandidates.any { it.label == "PySide6.QtWidgets" && !it.isTemplate })
        val importedSymbols = PythonCodeTemplates.suggestions("Ap", "from kivy.app import ")
        assertTrue(importedSymbols.any { it.label == "App" && !it.isTemplate })
    }

    @Test fun everyTemplateHasValidCaretOffsetAndNoMarkerLeaksIntoInsertedText() {
        assertTrue(PythonCodeTemplates.all.size >= 45)
        assertEquals(PythonCodeTemplates.all.size, PythonCodeTemplates.all.map { it.trigger }.distinct().size)
        listOf("kivy", "pygame", "tkinter", "pyglet", "arcade", "pyqt", "pyside").forEach { trigger ->
            assertTrue("Missing framework template: $trigger", PythonCodeTemplates.all.any { it.trigger == trigger })
        }
        PythonCodeTemplates.all.forEach { template ->
            val insert = template.insertion()
            assertFalse("Cursor marker leaked from ${template.trigger}", insert.text.contains(PythonCodeTemplates.CURSOR_MARKER))
            assertFalse("Selection-start marker leaked from ${template.trigger}", insert.text.contains(PythonCodeTemplates.SELECTION_START_MARKER))
            assertFalse("Selection-end marker leaked from ${template.trigger}", insert.text.contains(PythonCodeTemplates.SELECTION_END_MARKER))
            assertTrue("Bad cursor offset for ${template.trigger}", insert.cursorBack in 0..insert.text.length)
            if (insert.selectionStartBack != null && insert.selectionEndBack != null) {
                val start = insert.text.length - insert.selectionStartBack
                val end = insert.text.length - insert.selectionEndBack
                assertTrue("Bad placeholder selection for ${template.trigger}", start in 0..end && end <= insert.text.length)
            }
            assertTrue("Empty template ${template.trigger}", insert.text.isNotBlank())
        }
    }
}
