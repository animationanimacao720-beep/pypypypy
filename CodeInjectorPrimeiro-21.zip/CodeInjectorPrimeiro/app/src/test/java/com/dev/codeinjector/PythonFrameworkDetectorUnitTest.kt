package com.dev.codeinjector

import org.junit.Assert.assertEquals
import org.junit.Test

class PythonFrameworkDetectorUnitTest {
    @Test fun detectsFrameworksAcrossProjectSources() {
        val sources = listOf(
            "import os\nfrom helpers.assets import load_assets",
            "# main helper module\nfrom pygame.sprite import Sprite",
        )
        assertEquals("pygame", PythonFrameworkDetector.detectSources(sources))
    }

    @Test fun prioritizesKivyWhenMultipleFrameworksAreImported() {
        assertEquals("kivy", PythonFrameworkDetector.detectSources(listOf("import pygame", "from kivy.app import App")))
    }

    @Test fun ignoresFrameworkNamesInsideCommentsAndStrings() {
        assertEquals(null, PythonFrameworkDetector.detectSources(listOf("# import pygame\nprint('import kivy')", "import requests")))
    }

    @Test fun recognizesFrameworkImportWithTrailingComment() {
        assertEquals("pygame", PythonFrameworkDetector.detect("import pygame  # graphics"))
    }

    @Test fun ignoresImportsInsideMultilineStrings() {
        val source = "\"\"\"Example only:\nimport pygame\n\"\"\"\nprint('plain python')"
        assertEquals(null, PythonFrameworkDetector.detect(source))
    }

    @Test fun detectsImportAfterSemicolon() {
        assertEquals("pygame", PythonFrameworkDetector.detect("import os; import pygame"))
        assertEquals("pygame", PythonFrameworkDetector.detect("value = 1; import pygame"))
    }
}
