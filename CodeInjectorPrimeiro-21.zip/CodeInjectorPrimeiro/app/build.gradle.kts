plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.chaquopy)
}

android {
    namespace = "com.dev.codeinjector"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.dev.codeinjector"
        minSdk = 26              // Chaquopy 17 exige minSdk >= 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0-python"
        ndk {
            // Só os ABIs necessários (cada ABI soma alguns MB). Adicione "armeabi-v7a" para celulares 32 bits.
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
        // APK debuggable deixa o Compose/ART bem mais lentos; o APK de debug continua assinado e instalável
        debug { isDebuggable = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/MANIFEST.MF", "META-INF/*.SF", "META-INF/*.RSA", "META-INF/*.DSA",
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/*.kotlin_module", "META-INF/versions/**"
            )
        }
    }
}

chaquopy {
    defaultConfig {
        // CPython embutido. 3.11 = mensagens de erro detalhadas (linha/coluna) e suporte a 32 e 64 bits.
        version = "3.11"
        // Bytecode (.pyc) usa o Python do PC de build (precisa ser 3.11). Se não houver, o build continua só com aviso.
        // Bibliotecas Python extras (instaladas no build). requests é leve; numpy/pandas deixam o APK bem maior.
        pip {
            install("requests")
            // install("numpy")
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.foundation)
    implementation(libs.androidx.material3)
    implementation(libs.kotlinx.coroutines.android)
    testImplementation("junit:junit:4.13.2")
}
