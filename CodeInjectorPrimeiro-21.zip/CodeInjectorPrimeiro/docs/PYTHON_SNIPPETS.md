# Atalhos e modelos de código Python

O Code Injector oferece modelos completos na barra de sugestões e no menu **Snippets…**. Ao começar a digitar o atalho (por exemplo `def`, `class`, `if`, `kiv` ou `pygame`), toque na sugestão ou use `Alt+1` a `Alt+9`. Os modelos integrados também estão listados em **Snippets…**. O primeiro placeholder é selecionado automaticamente quando possível, para ser substituído pelo texto digitado.

## Estruturas Python

| Atalho | Inserção |
|---|---|
| `def` | Função `def name():` com `return` |
| `class` | Classe com método de exemplo |
| `if`, `elif`, `else` | Blocos condicionais |
| `for`, `while` | Laços com corpo indentado |
| `try`, `except`, `finally` | Estrutura de tratamento de exceções |
| `with` | Bloco `with open(...)` com leitura de arquivo |
| `async`, `asyncfor`, `asyncwith` | Funções, laços e gerenciadores assíncronos |
| `match`, `case` | Estruturas de correspondência (Python 3.10+) |
| `main` | Função principal e guarda `if __name__ == "__main__"` |
| `import`, `from` | Modelos de importação; em contexto de import, a barra sugere módulos em vez de substituir a instrução toda |
| `return`, `yield`, `raise`, `assert`, `lambda`, `await` | Modelos de expressões e fluxo de execução |
| `break`, `continue`, `pass`, `global`, `nonlocal`, `del` | Instruções auxiliares de controle/escopo |
| `decorator`, `contextmanager`, `property`, `setter`, `dataclass` | Decoradores, gerenciamento de recursos, propriedades e classes de dados |
| `listcomp`, `dictcomp` | Compreensões de lista e dicionário |
| `test`, `docstring` | Teste pytest e documentação de função |

## Frameworks gráficos

| Atalho | Modelo |
|---|---|
| `kivy`, `kivyimports` | Aplicação Kivy mínima e imports comuns |
| `pygame`, `pygameimports` | Loop principal de jogo e imports comuns |
| `tkinter`, `tkimports` | Janela Tkinter com widget e imports comuns |
| `pyglet`, `pygletimports` | Janela Pyglet e imports comuns |
| `arcade`, `arcadeimports` | Janela de jogo Arcade e imports comuns |
| `pyqt`, `pyqtimports` | Janela PyQt6 e imports comuns |
| `pyside`, `pysideimports` | Janela PySide6 e imports comuns |

Em linhas iniciadas por `import ` ou `from `, os resultados da barra são nomes de módulos/submódulos compatíveis com o prefixo digitado. Para inserir o programa completo de um framework, use o atalho do framework fora do contexto de importação ou abra **Snippets…** e escolha o modelo pelo nome.

Os modelos são exemplos editáveis, não uma garantia de que o framework está instalado no ambiente Python do aparelho. Kivy/Pygame e os demais frameworks continuam sujeitos à disponibilidade de seus módulos e bibliotecas nativas no ambiente de execução escolhido.


## Atalhos personalizados e compartilhamento

No menu **Snippets…**, em **Meus snippets**, defina o nome, o atalho (letras, números e `_`, começando por letra ou `_`) e o código a inserir. Use **Usar seleção/arquivo** para preencher o código a partir da seleção atual ou do arquivo inteiro. Ao digitar o atalho, ele aparece na barra de sugestões; toque nele ou use `Alt+1` a `Alt+9`. Os snippets personalizados ficam salvos no dispositivo.

Os botões **Exportar** e **Importar** usam um arquivo JSON portátil. A importação mescla snippets pelo atalho: itens que já existam com o mesmo atalho são atualizados, os demais são adicionados. O formato legado local `{\"n\": ..., \"b\": ...}` continua sendo lido.

Os modelos integrados e os snippets personalizados convertem a indentação de quatro espaços no início de linha em tabs para acompanhar a configuração atual do editor; espaços dentro do restante do código não são substituídos.
