package com.dev.codeinjector

private fun checkThat(ok: Boolean, message: String) {
    if (!ok) error(message)
}

fun main() {
    val def = PythonCodeTemplates.suggestions("de", "").first { it.label == "def" }.insertion
    checkThat(def.text == "def name():\n\treturn", "def shortcut body was not expanded")
    checkThat(def.selectionStartBack != null && def.selectionEndBack != null, "def should select the name placeholder")
    checkThat(def.text.length - def.selectionStartBack!! == "def ".length, "def placeholder start is wrong")
    checkThat(def.text.length - def.selectionEndBack!! == "def name".length, "def placeholder end is wrong")

    val clazz = PythonCodeTemplates.suggestions("cla", "").first { it.label == "class" }.insertion.text
    checkThat(clazz.contains("class Name():\n\tdef method(self):\n\t\tpass"), "class shortcut does not include method")

    val kivy = PythonCodeTemplates.suggestions("kiv", "").first { it.label.contains("Kivy — aplicação") }
    checkThat(kivy.insertion.text.contains("from kivy.app import App"), "Kivy imports are missing")
    checkThat(kivy.insertion.text.contains("MyApp().run()"), "Kivy application runner is missing")

    val pygame = PythonCodeTemplates.suggestions("pygame", "").first { it.label.contains("Pygame — loop") }
    checkThat(pygame.insertion.text.contains("pygame.event.get()"), "Pygame event loop is missing")
    checkThat("\n\tfor event in pygame.event.get():" in pygame.insertion.text, "built-in indentation must use tabs")
    checkThat(PythonCodeTemplates.normalizeIndentationToTabs("if ok:\n    pass\n        run()") == "if ok:\n\tpass\n\t\trun()", "four-space indentation must convert to tabs")

    val modules = PythonCodeTemplates.suggestions("ki", "import ")
    checkThat(modules.any { it.label == "kivy" && !it.isTemplate }, "import context should complete a module name")
    checkThat(PythonCodeTemplates.suggestions("PyS", "from ").any { it.label == "PySide6.QtWidgets" }, "from-import submodule suggestions are missing")
    checkThat(PythonCodeTemplates.suggestions("Ap", "from kivy.app import ").any { it.label == "App" }, "from-import symbol suggestions are missing")

    PythonCodeTemplates.all.forEach { template ->
        val expanded = template.insertion()
        checkThat(!expanded.text.contains(PythonCodeTemplates.CURSOR_MARKER), "cursor marker leaked into ${template.trigger}")
        checkThat(!expanded.text.contains(PythonCodeTemplates.SELECTION_START_MARKER), "selection-start marker leaked into ${template.trigger}")
        checkThat(!expanded.text.contains(PythonCodeTemplates.SELECTION_END_MARKER), "selection-end marker leaked into ${template.trigger}")
        checkThat(expanded.cursorBack in 0..expanded.text.length, "invalid cursor in ${template.trigger}")
        if (expanded.selectionStartBack != null && expanded.selectionEndBack != null) {
            val start = expanded.text.length - expanded.selectionStartBack
            val end = expanded.text.length - expanded.selectionEndBack
            checkThat(start in 0..end && end <= expanded.text.length, "invalid placeholder selection in ${template.trigger}")
        }
    }
    println("PYTHON CODE TEMPLATES: PASS (${PythonCodeTemplates.all.size} templates)")
}
