package com.dev.codeinjector

fun main() {
    val cases = listOf(
        "import kivy" to "kivy",
        "from kivy.app import App" to "kivy",
        "import pygame as pg" to "pygame",
        "import pygame # setup the display later" to "pygame",
        "import pygame.locals, os" to "pygame",
        "  from pygame.sprite import Sprite" to "pygame",
        "import mypygame" to null,
        "# import pygame\nprint('hello')" to null,
        "print(1)\nimport os" to null,
        "print('import kivy')" to null,
        "import requests" to null,
        "from tkinter import Tk" to "tkinter",
        "import tkinter as tk" to "tkinter",
        "from pyglet.window import Window" to "pyglet",
        "import arcade" to "arcade",
        "import pyglet\nimport arcade" to "arcade",
        "from PyQt5.QtWidgets import QApplication" to "pyqt5",
        "from PyQt6.QtWidgets import QApplication" to "pyqt6",
        "from PySide6.QtWidgets import QApplication" to "pyside6",
        "import PyQtish" to null,
        "from mytkinter import Tk" to null,
        "import importlib\nmod = 'pygame'" to null,
        "\"\"\"Example only:\nimport pygame\n\"\"\"\nprint('plain python')" to null,
        "import os; import pygame" to "pygame",
        "value = 1; import pygame" to "pygame",
        "# import pygame\nvalue = 1; import requests" to null,
        "text = \"# import pygame\"\nimport requests" to null,
    )
    var failures = 0
    for ((source, expected) in cases) {
        val actual = PythonFrameworkDetector.detect(source)
        if (actual != expected) {
            failures++
            System.err.println("FAIL expected=$expected actual=$actual source=$source")
        }
    }
    check(PythonFrameworkDetector.detectSources(listOf("import os", "from pygame.sprite import Sprite")) == "pygame") {
        "project-wide detection did not find a framework in a secondary module"
    }
    check(PythonFrameworkDetector.detectSources(listOf("import pygame", "from kivy.app import App")) == "kivy") {
        "project-wide detector priority mismatch"
    }
    check(failures == 0) { "$failures detector test(s) failed" }
    println("PASS: ${cases.size} single-source cases + 2 project-wide cases")
}
