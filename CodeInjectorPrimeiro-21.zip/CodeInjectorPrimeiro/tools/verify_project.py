#!/usr/bin/env python3
"""Static sanity checks for the CodeInjector source tree; not a substitute for Android build/device tests."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []

def require(condition, message):
    if not condition:
        errors.append(message)

manifest = ROOT / 'app/src/main/AndroidManifest.xml'
try:
    tree = ET.parse(manifest)
    root = tree.getroot()
    ns = '{http://schemas.android.com/apk/res/android}'
    perms = {p.attrib.get(ns + 'name') for p in root.findall('uses-permission')}
    require('android.permission.INTERNET' in perms, 'Manifest missing INTERNET permission')
    require('com.termux.permission.RUN_COMMAND' in perms, 'Manifest missing Termux RUN_COMMAND permission')
    package_queries = {p.attrib.get(ns + 'name') for p in root.findall('./queries/package')}
    require('com.termux' in package_queries, 'Manifest missing package visibility for Termux')
    require('com.termux.x11' in package_queries, 'Manifest missing package visibility for Termux:X11')
except Exception as exc:
    errors.append(f'Manifest XML parse failed: {exc}')

required_files = [
    'app/src/main/java/com/dev/codeinjector/TermuxX11Runner.kt',
    'app/src/main/java/com/dev/codeinjector/TermuxWorkspace.kt',
    'docs/TERMUX_X11_WORKFLOW_V2.md',
    'app/src/main/java/com/dev/codeinjector/TermuxCommandResultReceiver.kt',
    'app/src/main/java/com/dev/codeinjector/PythonFrameworkDetector.kt',
    'tests/PythonFrameworkDetectorTest.kt',
    'app/src/test/java/com/dev/codeinjector/PythonFrameworkDetectorUnitTest.kt',
    'tools/run_detector_tests.sh',
    'app/src/main/java/com/dev/codeinjector/GitHubRepoImporter.kt',
    'app/src/main/java/com/dev/codeinjector/PyRunner.kt',
    'app/src/main/java/com/dev/codeinjector/CodeEditorScreen.kt',
    'app/src/main/java/com/dev/codeinjector/CustomShortcuts.kt',
    'app/src/main/java/com/dev/codeinjector/MouseInteraction.kt',
    'app/src/main/java/com/dev/codeinjector/UserCodeSnippets.kt',
    'app/src/main/java/com/dev/codeinjector/PythonCodeTemplates.kt',
    'app/src/test/java/com/dev/codeinjector/PythonCodeTemplatesUnitTest.kt',
    'tests/PythonCodeTemplatesTest.kt',
    'tools/run_snippet_tests.sh',
    'docs/PYTHON_SNIPPETS.md',
    'app/src/main/python/ci_runner.py',
    'docs/TERMUX_X11_SETUP.md',
]
for rel in required_files:
    require((ROOT / rel).is_file(), f'Missing required file: {rel}')

runner = (ROOT / 'app/src/main/java/com/dev/codeinjector/TermuxX11Runner.kt').read_text()
py_runner = (ROOT / 'app/src/main/java/com/dev/codeinjector/PyRunner.kt').read_text()
ui = (ROOT / 'app/src/main/java/com/dev/codeinjector/CodeEditorScreen.kt').read_text()
receiver = (ROOT / 'app/src/main/java/com/dev/codeinjector/TermuxCommandResultReceiver.kt').read_text()
require('fun detectFramework' in runner, 'Framework detection function missing')
require('com.termux.RUN_COMMAND' in runner, 'Termux RUN_COMMAND action missing')
require('SDL_VIDEODRIVER=x11' in runner, 'SDL X11 environment missing')
require('export DISPLAY=:1' in runner, 'Runner does not use the documented X11 display :1')
require('CODEINJECTOR_PROOT_DISTRO' in runner, 'Optional proot-distro backend missing')
require('importlib.util.find_spec' in runner, 'Runner does not preflight the requested framework module')
require('fun stop(' in runner, 'External process stop function missing')
require('MAX_ARCHIVE_BYTES' not in runner and 'ZipOutputStream' not in runner and 'Intent payload size guard' not in runner, 'Project payload should not be embedded in the RUN_COMMAND Intent')
require('.X11-unix/X1' in runner and 'pgrep -f' not in runner, 'X11 display :1 startup verification missing')
require('termux-x11 :1 -legacy-drawing' in runner, 'X11 legacy drawing fallback missing')
require('termux-x11.log' in runner, 'X11 startup diagnostics log missing')
require('termux-x11-legacy.log' in runner, 'X11 legacy-mode diagnostics log missing')
require('python3-kivy' in runner and 'python3-pygame' in runner, 'Distro installer does not map graphical frameworks to system packages')
require('termux-x11-preference' in runner and 'fun applyX11Preferences' in runner, 'X11 preferences integration missing')
require('Modulo PRoot' in runner and 'allow-external-apps' in runner, 'Integrated diagnostics missing')
require('setsid bash -c' in runner and 'kill -KILL --' in runner, 'Process-group lifecycle handling missing')
require('ci-proot-runner.sh' in runner, 'Proot runner wrapper missing')
require('detectProjectFramework(ctx.applicationContext, source, fileName, siblings, externalProject)' in py_runner, 'Execution path does not detect frameworks across project sources')
require('readExternalLogDelta' in py_runner and 'AutoCloseInputStream' in py_runner, 'Incremental external log reader missing')
require('externalMainRelativePath = launched.mainRelativePath' in py_runner, 'External traceback mapping does not use relative project path')
require('logsWereRead' in py_runner and 'não a imprima outra vez' in py_runner, 'External output transcript may be duplicated after live log streaming')
workspace = (ROOT / 'app/src/main/java/com/dev/codeinjector/TermuxWorkspace.kt').read_text()
detector = (ROOT / 'app/src/main/java/com/dev/codeinjector/PythonFrameworkDetector.kt').read_text()
require('MAX_TOTAL_BYTES = 180L * 1024L * 1024L' in workspace and 'MAX_FILES = 4000' in workspace, 'SAF workspace safety bounds missing')
require('copyDirectory' in workspace and 'writeRelativeBytes' in workspace, 'Project resource staging missing')
for module in ['kivy', 'pygame', 'tkinter', 'pyglet', 'arcade', 'pyqt5', 'pyqt6', 'pyside2', 'pyside6']:
    require(f'\"{module}\"' in detector, f'Framework detector missing {module}')
require('listPythonScripts' in workspace and 'Executar arquivo principal do projeto' in ui, 'Project entrypoint picker missing')
require('detectSources' in detector and 'detectProjectFramework' in runner, 'Project-wide framework detection missing')
require('maskStringsAndComments' in detector, 'Framework detector must ignore imports inside strings/comments')
require('totalBytes[0] += bytes.size.toLong()' in workspace and workspace.count('totalBytes[0] += bytes.size.toLong()') == 2, 'Workspace byte counters must convert ByteArray sizes to Long')
require('): String? = detectFramework(source)' in runner and 'Não varre abas vizinhas' in runner, 'Framework routing must depend only on the selected script, not unrelated project files')
require('copyLocalDirectory' in workspace and 'localProjectRoot' in workspace, 'Imported local project resources/subdirectories are not staged')
require('FLAG_ACTIVITY_LAUNCH_ADJACENT' in runner and 'Abrir Termux:X11 em tela dividida' in ui, 'Adjacent-window request missing')
require('missingExternalPackage' in py_runner and 'Instalar ${' in ui, 'Missing-framework installer UI missing')
require("substringAfterLast('.').uppercase() in acceptedNames" in receiver, 'Result receiver does not match exact result keys')
require('Cancelando a inicialização' in py_runner, 'Startup stop race handling missing')
require('GitHubRepoImporter.importPublicRepo' in ui, 'GitHub import UI is not wired')
require('installPythonPackage' in ui, 'Package manager UI is not wired')
templates = (ROOT / 'app/src/main/java/com/dev/codeinjector/PythonCodeTemplates.kt').read_text()
suggestions = (ROOT / 'app/src/main/java/com/dev/codeinjector/KeyboardSuggestionBar.kt').read_text()
require('PythonCodeTemplates.suggestions(prefix, lineBefore)' in suggestions, 'Syntax suggestion bar does not integrate code templates')
require('SymKind.SNIPPET' in suggestions, 'Suggestion bar does not style code templates')
require('selectionStartBack' in suggestions and 'selectionEndBack' in suggestions, 'Syntax suggestions do not support editable placeholders')
require('selectionStartBack = if (selected)' in templates and 'selectionEndBack = if (selected)' in templates, 'Template placeholder selection offsets are missing')
require('PythonCodeTemplates.all.forEach' in ui and 'insertWithBack(expanded.text, expanded.cursorBack, expanded.selectionStartBack, expanded.selectionEndBack)' in ui, 'Integrated code templates are not available from the Snippets dialog')
require('from kivy.app import App' in templates and 'pygame.event.get()' in templates and 'from PyQt6.QtWidgets' in templates and 'from PySide6.QtWidgets' in templates, 'Framework templates are missing expected runnable examples')
require('def name' in templates and 'class ' in templates and 'except Exception as error' in templates, 'Python structure templates are incomplete')
require('fromImportContext' in templates and 'kivy.app' in templates and 'QApplication' in templates, 'Context-aware import completions are incomplete')
require('PythonCodeTemplatesUnitTest' in ''.join(p.read_text() for p in (ROOT / 'app/src/test').rglob('*.kt')), 'Template JVM regression tests are missing')
require('Importar projeto do GitHub' in ui, 'GitHub import UI text missing')
require('Btn("⚡ Atalhos"' in ui, 'Shortcut center is not visible in the main toolbar')
require('Btn("⌨ Teclas"' in ui, 'Keyboard shortcut settings do not have a direct main-toolbar button')
require('Configurar atalhos de teclado…' in ui and 'Configurar atalhos de teclado' in ui, 'Keyboard shortcut settings are not easy to find')
require('SnippetStore.encode' in ui and 'fun decode(json: String)' in (ROOT / 'app/src/main/java/com/dev/codeinjector/UserCodeSnippets.kt').read_text(), 'Snippet import/export JSON is missing')
require('importSnippetsLauncher' in ui and 'exportSnippetsLauncher' in ui, 'Snippet import/export UI is not wired')
require('PythonCodeTemplates.normalizeIndentationToTabs' in ui and 'normalizeIndentationToTabs' in templates, 'TAB indentation normalization is missing')
require('userSnippets = snippets.toList()' in ui and 'customSnippets: List<UserCodeSnippet>' in suggestions, 'Custom snippets are not offered by autocomplete')
require('ShortcutCatalog.actions' in ui and 'CustomShortcutStore.save' in ui, 'Configurable keyboard shortcuts are not persisted')

if errors:
    print('STATIC CHECKS: FAILED')
    for error in errors:
        print(' -', error)
    sys.exit(1)
print('STATIC CHECKS: PASS')
print(f'Checked manifest and {len(required_files)} required files plus integration markers.')
print('This script does not compile Kotlin/Gradle or run the app on Android.')
