#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
command -v kotlinc >/dev/null 2>&1 || { echo 'kotlinc not found; install Kotlin compiler to run these optional tests.' >&2; exit 2; }
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
kotlinc "$ROOT/app/src/main/java/com/dev/codeinjector/PythonCodeTemplates.kt" "$ROOT/tests/PythonCodeTemplatesTest.kt" -include-runtime -d "$OUT/template-tests.jar"
java -jar "$OUT/template-tests.jar"
