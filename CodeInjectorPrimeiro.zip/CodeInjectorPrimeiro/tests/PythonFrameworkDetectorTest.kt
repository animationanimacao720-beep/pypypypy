package com.dev.codeinjector

fun main() {
    val cases = listOf(
        "import kivy" to "kivy",
        "from kivy.app import App" to "kivy",
        "import pygame as pg" to "pygame",
        "import pygame.locals, os" to "pygame",
        "  from pygame.sprite import Sprite" to "pygame",
        "import mypygame" to null,
        "# import pygame\nprint('hello')" to null,
        "print(1)\nimport os" to null,
        "print('import kivy')" to null,
        "import requests" to null
    )
    var failures = 0
    for ((source, expected) in cases) {
        val actual = PythonFrameworkDetector.detect(source)
        if (actual != expected) {
            failures++
            System.err.println("FAIL expected=$expected actual=$actual source=$source")
        }
    }
    check(failures == 0) { "$failures detector test(s) failed" }
    println("PASS: ${cases.size} framework detector cases")
}
