# Configurar Termux + Termux:X11 para o CodeInjector

Este guia descreve a integração externa. O botão flutuante da IDE abre três modos: **Executar Kivy · Termux:X11**, **Executar Pygame · Termux:X11** e **Executar dentro da IDE**. Os dois modos gráficos enviam explicitamente o arquivo atual ao Termux mesmo quando o detector automático não encontra um `import`; o script é preparado com `DISPLAY=:1` e `SDL_VIDEODRIVER=x11`, e o runner tenta abrir a Activity do Termux:X11 depois de iniciar o servidor. O terceiro modo usa o Python embutido na IDE e não encaminha o código ao Termux. A integração não instala uma distro Linux completa nem as bibliotecas gráficas automaticamente.

## 1. Instalar os aplicativos

1. Instale o Termux e o APK Termux:X11 de fontes oficiais (links no README).
2. Abra o Termux pelo menos uma vez e conclua a configuração inicial.
3. No Termux, execute:

```sh
pkg update
pkg upgrade
pkg install x11-repo termux-x11-nightly python coreutils unzip procps proot-distro
```

## 2. Permitir comandos externos

No Termux, execute este bloco (não digite somente `allow-external-apps=true` como se fosse um comando):

```sh
mkdir -p ~/.termux
touch ~/.termux/termux.properties
if grep -q '^allow-external-apps=' ~/.termux/termux.properties; then
  sed -i 's/^allow-external-apps=.*/allow-external-apps=true/' ~/.termux/termux.properties
else
  printf '\nallow-external-apps=true\n' >> ~/.termux/termux.properties
fi
termux-reload-settings
```

Depois abra **Configurações Android → Aplicativos → CodeInjector → Permissões adicionais** e permita **Executar comandos no Termux** (o texto pode variar). O Termux também pode solicitar permissão para aparecer sobre outros apps; isso pode ser necessário para abrir automaticamente a sessão gráfica.

## 3. Iniciar o servidor X11

O runner padroniza **`termux-x11 :1` + `DISPLAY=:1`**, que é a forma usada nos exemplos oficiais do Termux:X11. Ao rodar um script gráfico, a IDE procura um servidor no display `:1`; se não encontrar, tenta iniciá-lo, espera até 8 segundos e tenta novamente com `-legacy-drawing` se o primeiro modo falhar. Os logs ficam em `~/.codeinjector/runs/ci-*/termux-x11.log` e `termux-x11-legacy.log`.

A IDE também tenta abrir a Activity do Termux:X11. A janela gráfica só poderá aparecer se o APK Android do Termux:X11 e o pacote `termux-x11-nightly` dentro do Termux forem compatíveis, se o servidor iniciar e se o ambiente Python selecionado tiver bibliotecas gráficas funcionais. Conforme a versão do Android e as permissões de atividade em segundo plano, pode ser necessário abrir o app Termux:X11 manualmente.

## 4. Python, Kivy e Pygame

- O Python integrado do CodeInjector (Chaquopy) continua para scripts Python comuns.
- Os botões gráficos flutuantes **Executar Kivy · Termux:X11** e **Executar Pygame · Termux:X11** sempre selecionam o interpretador externo e verificam `importlib.util.find_spec()` no módulo escolhido. O botão **Executar dentro da IDE** força o Python embutido mesmo que o arquivo importe Kivy/Pygame. O botão comum na barra de ferramentas mantém a detecção automática.
- Sem configuração adicional, a execução externa usa `~/kv/bin/python` se existir; caso contrário, usa `python` ou `python3` do Termux.
- O Python nativo do Termux é diferente do Python Linux (glibc). Se Kivy/Pygame não estiver instalado ou não for compatível com ele, configure uma distro Linux opcional conforme o próximo passo.

### Opção recomendada para maior compatibilidade: Debian via PRoot

No Termux, instale e crie a distro:

```sh
pkg install proot-distro
proot-distro install debian
proot-distro login debian -- apt-get update
proot-distro login debian -- apt-get install -y python3 python3-kivy python3-pygame python3-pip
```

Depois, **no Termux normal (fora da sessão Debian)**, configure a IDE para usar essa distro:

```sh
mkdir -p ~/.codeinjector
printf 'CODEINJECTOR_PROOT_DISTRO=debian\n' > ~/.codeinjector/termux-x11.conf
```

A partir daí, os scripts gráficos executam com o Python da distro; o runner usa `proot-distro login ... --shared-tmp`, monta temporariamente os arquivos Python em `/tmp/codeinjector-run` e exporta `DISPLAY=:1` dentro da distro. O menu “Instalar biblioteca Python (Termux)…” instala `kivy`/`pygame` com os pacotes `python3-kivy`/`python3-pygame` do Debian quando esse modo está configurado.

Se preferir permanecer no Python nativo do Termux, teste a disponibilidade usando o mesmo interpretador escolhido pela IDE:

```sh
python -c 'import pygame; print(pygame.__version__)'
python -c 'import kivy; print(kivy.__version__)'
```

O runner não assume que um `pip install` teve sucesso: o script é interrompido com uma mensagem clara se o módulo não estiver disponível. O ambiente Debian e suas bibliotecas precisam ser instalados pelo usuário; não são baixados automaticamente pela IDE.

## 5. Limitações conhecidas

- A detecção automática identifica imports explícitos de `kivy` ou `pygame` no arquivo principal. Importação dinâmica (`importlib`), nomes construídos em tempo de execução e dependências indiretas podem não ser detectados.
- Por segurança com o limite de tamanho dos Intents Android, o pacote enviado é limitado a 160 KB compactados. Ao executar um arquivo de um projeto importado pelo GitHub, a IDE inclui os módulos `.py`, layouts `.kv` e recursos de runtime reconhecidos (imagens, áudio, fontes e arquivos de configuração), preservando caminhos relativos. A leitura do projeto é limitada a 150 arquivos e 4 MB descompactados. Projetos que excedem esses limites precisam ser reduzidos ou executados diretamente no Termux.
- Projetos escolhidos pelo seletor Android (SAF) também podem ser percorridos para enviar os recursos de runtime, desde que a aba principal pertença à pasta selecionada. A varredura para após 2.000 itens; nomes de arquivo fora do padrão aceito e extensões não listadas são ignorados.
- O botão Parar envia um sinal ao processo principal. Um programa que cria subprocessos pode deixar processos filhos ativos; se isso ocorrer, feche a sessão Termux correspondente.
- O importador do GitHub baixa repositórios públicos para o armazenamento privado do CodeInjector. Não é um cliente Git: não faz push, commits, autenticação de repositórios privados nem sincronização posterior.

## Diagnóstico rápido

| Sintoma | O que verificar |
|---|---|
| `command not found` para `allow-external-apps=true` | A opção precisa estar em `~/.termux/termux.properties`, não ser executada no shell. |
| `Permission denied` / falha ao iniciar serviço | Permissão adicional RUN_COMMAND e `allow-external-apps=true`. |
| `termux-x11: command not found` | `pkg install x11-repo termux-x11-nightly`; confirme que o repositório oficial Termux está configurado. |
| `No module named kivy/pygame` | Instale a biblioteca no interpretador selecionado; para Debian configurado, use `apt-get install python3-kivy python3-pygame`. |
| Janela preta / `DISPLAY` | Confirme que Termux:X11 está aberto no display `:1`; veja `termux-x11.log` e `termux-x11-legacy.log`. |
| Imagem ou áudio não encontrado | Recursos do projeto ainda precisam ser copiados para o ambiente Termux; apenas arquivos Python abertos são empacotados automaticamente. |
