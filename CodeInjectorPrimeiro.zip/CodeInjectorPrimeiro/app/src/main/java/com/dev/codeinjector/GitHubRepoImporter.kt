package com.dev.codeinjector

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Importa somente repositórios públicos do GitHub; limita tamanho e impede Zip Slip. */
object GitHubRepoImporter {
    data class Imported(val folder: File, val pythonFiles: List<File>)

    fun importPublicRepo(context: Context, input: String): Imported {
        val uri = android.net.Uri.parse(input.trim())
        require(uri.scheme == "https" && uri.host.equals("github.com", true)) {
            "Informe uma URL HTTPS de um repositório público github.com/usuario/repositorio."
        }
        val parts = uri.path.orEmpty().trim('/').split('/').filter { it.isNotBlank() }
        require(parts.size >= 2 && parts[0].matches(Regex("[A-Za-z0-9_.-]+")) && parts[1].matches(Regex("[A-Za-z0-9_.-]+"))) {
            "URL inválida. Use https://github.com/usuario/repositorio"
        }
        val owner = parts[0]
        val repo = parts[1].removeSuffix(".git")
        val api = URL("https://api.github.com/repos/$owner/$repo")
        val metadata = api.openConnection() as HttpURLConnection
        metadata.connectTimeout = 12000; metadata.readTimeout = 12000
        metadata.setRequestProperty("Accept", "application/vnd.github+json")
        metadata.setRequestProperty("User-Agent", "CodeInjector-Android")
        val branch = try {
            if (metadata.responseCode !in 200..299) throw IllegalStateException("GitHub respondeu HTTP ${metadata.responseCode}. Confira se o repositório é público.")
            val body = metadata.inputStream.bufferedReader().use { it.readText() }
            org.json.JSONObject(body).getString("default_branch")
        } finally { metadata.disconnect() }
        val connection = URL("https://api.github.com/repos/$owner/$repo/zipball/$branch").openConnection() as HttpURLConnection
        connection.connectTimeout = 15000; connection.readTimeout = 30000
        connection.setRequestProperty("User-Agent", "CodeInjector-Android")
        val root = File(context.filesDir, "github_projects").apply { mkdirs() }
        val folder = File(root, repo.replace(Regex("[^A-Za-z0-9_.-]"), "_") + "_" + System.currentTimeMillis())
        folder.mkdirs()
        try {
            if (connection.responseCode !in 200..299) throw IllegalStateException("Falha ao baixar o repositório (HTTP ${connection.responseCode}).")
            var total = 0L
            var entryCount = 0
            ZipInputStream(connection.inputStream.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    entryCount++
                    require(entryCount <= 10_000) { "Repositório contém mais de 10.000 itens; importação cancelada." }
                    val clean = entry.name.replace('\\', '/')
                    val relative = clean.substringAfter('/', "")
                    if (relative.isBlank()) continue
                    val out = File(folder, relative).canonicalFile
                    require(out.toPath().startsWith(folder.canonicalFile.toPath())) { "O ZIP contém um caminho inválido." }
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        out.outputStream().buffered().use { output ->
                            val buffer = ByteArray(8192)
                            while (true) {
                                val n = zip.read(buffer); if (n < 0) break
                                total += n
                                require(total <= 25L * 1024 * 1024) { "Repositório maior que 25 MB; importação cancelada." }
                                output.write(buffer, 0, n)
                            }
                        }
                    }
                    zip.closeEntry()
                }
            }
        } catch (e: Throwable) {
            folder.deleteRecursively(); throw e
        } finally { connection.disconnect() }
        val py = folder.walkTopDown().filter { it.isFile && it.extension.equals("py", true) }.take(500).toList()
        return Imported(folder, py)
    }
}
