package com.dev.codeinjector

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Tela principal mínima: só o botão de execução (▶ / ■).
 * Executa a aba atual da última sessão salva pelo editor (filesDir/session.json).
 * O editor completo continua em CodeEditorScreen.kt; para voltar a ele, troque
 * RunOnlyScreen() por CodeEditorScreen() no MainActivity.
 */
@Composable
fun RunOnlyScreen() {
    val ctx = LocalContext.current
    val state by PyRunner.state.collectAsState()
    val running = state != RunState.IDLE
    Box(Modifier.fillMaxSize().background(Color(0xFF111111)), contentAlignment = Alignment.Center) {
        Box(
            Modifier.size(120.dp).clip(CircleShape)
                .background(if (running) Color(0xFFE5484D) else Color(0xFF3DD68C))
                .clickable { if (running) PyRunner.stop() else runSavedSession(ctx) },
            contentAlignment = Alignment.Center
        ) { Text(if (running) "■" else "▶", color = Color(0xFF111111), fontSize = 52.sp) }
    }
}

private fun runSavedSession(ctx: Context) {
    val restored = SessionStore(ctx).load()
    if (restored == null) {
        Toast.makeText(ctx, "Nenhum arquivo salvo para executar", Toast.LENGTH_SHORT).show()
        return
    }
    val tab = restored.tabs[restored.cur]
    val siblings = restored.tabs
        .filter { it !== tab && it.name.endsWith(".py") }
        .associate { it.name to it.value.text }
    PyRunner.run(ctx, tab.value.text, tab.name, siblings)
}
