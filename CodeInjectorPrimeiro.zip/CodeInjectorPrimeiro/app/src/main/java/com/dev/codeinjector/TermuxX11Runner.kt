package com.dev.codeinjector

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Encaminha scripts Kivy/Pygame ao Python do Termux e usa Termux:X11 para a janela gráfica. */
object TermuxX11Runner {
    const val TERMUX_PACKAGE = "com.termux"
    const val X11_PACKAGE = "com.termux.x11"
    const val RUN_ID_EXTRA = "com.dev.codeinjector.extra.TERMUX_RUN_ID"
    const val X11_DISPLAY = ":1"
    private const val RUN_COMMAND_ACTION = "com.termux.RUN_COMMAND"
    private const val RUN_COMMAND_SERVICE = "com.termux.app.RunCommandService"
    private const val EXTRA_PATH = "com.termux.RUN_COMMAND_PATH"
    private const val EXTRA_ARGUMENTS = "com.termux.RUN_COMMAND_ARGUMENTS"
    private const val EXTRA_STDIN = "com.termux.RUN_COMMAND_STDIN"
    private const val EXTRA_WORKDIR = "com.termux.RUN_COMMAND_WORKDIR"
    private const val EXTRA_BACKGROUND = "com.termux.RUN_COMMAND_BACKGROUND"
    private const val EXTRA_SESSION_ACTION = "com.termux.RUN_COMMAND_SESSION_ACTION"
    private const val EXTRA_LABEL = "com.termux.RUN_COMMAND_COMMAND_LABEL"
    private const val EXTRA_DESCRIPTION = "com.termux.RUN_COMMAND_COMMAND_DESCRIPTION"
    private const val EXTRA_PENDING_INTENT = "com.termux.RUN_COMMAND_PENDING_INTENT"
    private const val MAX_ARCHIVE_BYTES = 160 * 1024
    private const val MAX_PROJECT_FILES = 150
    private const val MAX_PROJECT_RAW_BYTES = 4 * 1024 * 1024
    private val PROJECT_RUNTIME_EXTENSIONS = setOf(
        "py", "kv", "json", "txt", "ini", "cfg", "toml", "yaml", "yml", "properties",
        "png", "jpg", "jpeg", "webp", "gif", "bmp", "svg", "ttf", "otf", "ttc",
        "wav", "ogg", "mp3", "flac", "m4a", "mp4", "avi", "ico", "atlas", "fnt", "glsl", "frag", "vert", "csv", "xml"
    )
    private val PROJECT_SKIP_DIRS = setOf(
        ".git", ".github", ".idea", "__pycache__", ".venv", "venv", "node_modules", "build", "dist", ".gradle"
    )

    /** Wrapper executado dentro de uma distro Debian/Ubuntu opcional, com /tmp compartilhado para X11. */
    private const val PROOT_RUNNER_SCRIPT = """#!/bin/sh
set -eu
FRAMEWORK_MODULE="${'$'}{1:?módulo gráfico ausente}"
MAIN_SCRIPT="${'$'}{2:?arquivo Python ausente}"
export DISPLAY=:1
export SDL_VIDEODRIVER=x11
export PYGAME_HIDE_SUPPORT_PROMPT=1
cd "/tmp/codeinjector-run"
export PYTHONPATH="/tmp/codeinjector-run${'$'}{PYTHONPATH:+:${'$'}PYTHONPATH}"
if ! python3 -c 'import importlib.util,sys; sys.exit(0 if importlib.util.find_spec(sys.argv[1]) else 1)' "${'$'}FRAMEWORK_MODULE"; then
  echo "[CodeInjector] O módulo ${'$'}FRAMEWORK_MODULE não está instalado nesta distro." >&2
  case "${'$'}FRAMEWORK_MODULE" in
    kivy) echo "[CodeInjector] Instale com: apt-get update && apt-get install -y python3-kivy" >&2 ;;
    pygame) echo "[CodeInjector] Instale com: apt-get update && apt-get install -y python3-pygame" >&2 ;;
  esac
  exit 127
fi
exec python3 "${'$'}MAIN_SCRIPT"
"""

    data class LaunchResult(val runId: String, val framework: String)

    /** Mantém compatibilidade com os chamadores; lógica pura testada em PythonFrameworkDetector. */
    fun detectFramework(source: String): String? = PythonFrameworkDetector.detect(source)

    fun launch(
        context: Context,
        source: String,
        fileName: String,
        siblings: Map<String, String>,
        framework: String,
        runId: String,
        projectRoot: String? = null,
        projectPath: String? = null,
        projectTreeUri: String? = null,
        projectRootDocId: String? = null,
        projectMainDocId: String? = null,
    ): Result<LaunchResult> = runCatching {
        val app = context.applicationContext
        check(framework == "kivy" || framework == "pygame") { "Framework gráfico não suportado: $framework" }
        check(runId.matches(Regex("[A-Za-z0-9_-]{1,64}"))) { "Identificador de execução inválido." }
        check(isInstalled(app, TERMUX_PACKAGE)) {
            "Termux não está instalado. Instale o Termux e abra-o uma vez antes de executar scripts gráficos."
        }
        check(isInstalled(app, X11_PACKAGE)) {
            "O aplicativo Termux:X11 não foi encontrado. Instale o APK do Termux:X11 e o pacote termux-x11-nightly no Termux."
        }
        if (Build.VERSION.SDK_INT >= 23) {
            check(app.checkSelfPermission("com.termux.permission.RUN_COMMAND") == PackageManager.PERMISSION_GRANTED) {
                "Permissão ausente: abra Configurações do Android → Apps → CodeInjector → Permissões adicionais e permita ‘Executar comandos no Termux’. Depois habilite allow-external-apps=true em ~/.termux/termux.properties."
            }
        }

        val safBundle = if (
            projectRoot == null && projectTreeUri != null && projectRootDocId != null && projectMainDocId != null
        ) loadSafProjectFiles(app, projectTreeUri, projectRootDocId, projectMainDocId) else null
        val mainFile = projectPath?.let { safeProjectPath(it) } ?: safBundle?.first
            ?: safeProjectPath(fileName) ?: safePythonFileName(fileName)
        val projectFiles = projectRoot?.let { loadProjectFiles(app, it) } ?: safBundle?.second.orEmpty()
        val archive = createArchive(mainFile, source, siblings, projectFiles)
        check(archive.size <= MAX_ARCHIVE_BYTES) {
            "O projeto gráfico (código, layouts e recursos) ultrapassa 160 KB compactados. Reduza/otimize os assets ou execute o projeto diretamente no Termux."
        }
        val stdinPayload = Base64.encodeToString(archive, Base64.NO_WRAP)
        val prootRunnerEncoded = Base64.encodeToString(PROOT_RUNNER_SCRIPT.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val runDirName = "ci-$runId"
        val runDir = "\$HOME/.codeinjector/runs/$runDirName"
        val scriptPath = "$runDir/$mainFile"
        val frameworkName = if (framework == "kivy") "Kivy" else "Pygame"
        val frameworkModule = if (framework == "kivy") "kivy" else "pygame"

        // O código fonte viaja no stdin como ZIP/base64, nunca como shell code/argumentos.
        val shell = """
            set -eu
            RUN_DIR="$runDir"
            mkdir -p "${'$'}RUN_DIR"
            if ! command -v base64 >/dev/null 2>&1 || ! command -v unzip >/dev/null 2>&1 || ! command -v pgrep >/dev/null 2>&1; then
              echo "[CodeInjector] Faltam utilitários do Termux. Execute: pkg install coreutils unzip procps" >&2
              exit 127
            fi
            base64 -d > "${'$'}RUN_DIR/payload.zip"
            unzip -oq "${'$'}RUN_DIR/payload.zip" -d "${'$'}RUN_DIR"
            rm -f "${'$'}RUN_DIR/payload.zip"
            cd "${'$'}RUN_DIR"
            echo "${'$'}${'$'}" > "${'$'}RUN_DIR/.pid"

            # Configuração opcional: CODEINJECTOR_PROOT_DISTRO=debian em ~/.codeinjector/termux-x11.conf.
            CODEINJECTOR_PROOT_DISTRO=""
            CONFIG_FILE="${'$'}HOME/.codeinjector/termux-x11.conf"
            if [ -f "${'$'}CONFIG_FILE" ]; then . "${'$'}CONFIG_FILE"; fi
            if [ -n "${'$'}CODEINJECTOR_PROOT_DISTRO" ]; then
              case "${'$'}CODEINJECTOR_PROOT_DISTRO" in *[!a-zA-Z0-9_-]*)
                echo "[CodeInjector] CODEINJECTOR_PROOT_DISTRO inválido em ${'$'}CONFIG_FILE." >&2; exit 2 ;;
              esac
              if ! command -v proot-distro >/dev/null 2>&1; then
                echo "[CodeInjector] A configuração pede uma distro Linux, mas proot-distro não está instalado. Execute: pkg install proot-distro" >&2
                exit 127
              fi
            fi

            if ! command -v termux-x11 >/dev/null 2>&1; then
              echo "[CodeInjector] Falta o pacote Termux:X11 no Termux. Execute: pkg install x11-repo && pkg install termux-x11-nightly" >&2
              exit 127
            fi
            # O README oficial usa :1; o processo e DISPLAY precisam concordar no mesmo display.
            export DISPLAY=:1
            export SDL_VIDEODRIVER=x11
            export PYGAME_HIDE_SUPPORT_PROMPT=1
            X11_LOG="${'$'}RUN_DIR/termux-x11.log"
            start_x11_and_wait() {
              LOG_FILE="${'$'}1"
              shift
              "${'$'}@" > "${'$'}LOG_FILE" 2>&1 &
              X11_PID=${'$'}!
              ATTEMPT=0
              while [ "${'$'}ATTEMPT" -lt 8 ]; do
                if pgrep -f '[t]ermux-x11 :1' >/dev/null 2>&1; then return 0; fi
                if ! kill -0 "${'$'}X11_PID" 2>/dev/null; then break; fi
                sleep 1
                ATTEMPT=${'$'}((ATTEMPT + 1))
              done
              return 1
            }
            if ! pgrep -f '[t]ermux-x11 :1' >/dev/null 2>&1; then
              if ! start_x11_and_wait "${'$'}X11_LOG" termux-x11 :1; then
                # Algumas GPUs/dispositivos precisam do modo de desenho legado.
                X11_LOG="${'$'}RUN_DIR/termux-x11-legacy.log"
                if ! start_x11_and_wait "${'$'}X11_LOG" termux-x11 :1 -legacy-drawing; then
                  echo "[CodeInjector] O servidor Termux:X11 não iniciou no display :1. Logs:" >&2
                  for LOG in "${'$'}RUN_DIR/termux-x11.log" "${'$'}RUN_DIR/termux-x11-legacy.log"; do
                    if [ -f "${'$'}LOG" ]; then echo "--- ${'$'}LOG ---" >&2; tail -n 30 "${'$'}LOG" >&2; fi
                  done
                  echo "[CodeInjector] Abra Termux:X11 manualmente e confirme que APK e pacote termux-x11-nightly são compatíveis." >&2
                  exit 1
                fi
              fi
            fi

            # A Activity oficial mostra o servidor no Android; pode exigir abertura manual conforme as restrições do Android.
            if command -v am >/dev/null 2>&1; then
              if ! am start --user 0 -W -n com.termux.x11/com.termux.x11.MainActivity >/dev/null 2>&1; then
                if ! am start -n com.termux.x11/com.termux.x11.MainActivity >/dev/null 2>&1; then
                  echo "[CodeInjector] Não foi possível abrir a Activity do Termux:X11; abra o app manualmente." >&2
                fi
              fi
            else
              echo "[CodeInjector] O comando Android 'am' não está disponível; abra Termux:X11 manualmente." >&2
            fi
            sleep 1
            echo "[CodeInjector] Executando $frameworkName em Termux:X11 (DISPLAY=:1)"

            export PYTHONPATH="${'$'}RUN_DIR${'$'}{PYTHONPATH:+:${'$'}PYTHONPATH}"
            if [ -n "${'$'}CODEINJECTOR_PROOT_DISTRO" ]; then
              printf '%s' '$prootRunnerEncoded' | base64 -d > "${'$'}RUN_DIR/ci-proot-runner.sh"
              chmod 700 "${'$'}RUN_DIR/ci-proot-runner.sh"
              echo "[CodeInjector] Ambiente Linux: ${'$'}CODEINJECTOR_PROOT_DISTRO (com /tmp compartilhado para X11)"
              proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" --shared-tmp -- mkdir -p /tmp/codeinjector-run
              exec proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" --shared-tmp --bind "${'$'}RUN_DIR:/tmp/codeinjector-run" -- /bin/sh /tmp/codeinjector-run/ci-proot-runner.sh "$frameworkModule" "/tmp/codeinjector-run/$mainFile"
            fi

            if [ -x "${'$'}HOME/kv/bin/python" ]; then
              PYTHON="${'$'}HOME/kv/bin/python"
            elif command -v python >/dev/null 2>&1; then
              PYTHON="${'$'}(command -v python)"
            elif command -v python3 >/dev/null 2>&1; then
              PYTHON="${'$'}(command -v python3)"
            else
              echo "[CodeInjector] Python não foi encontrado no Termux. Execute: pkg install python" >&2
              exit 127
            fi
            if ! "${'$'}PYTHON" -c 'import importlib.util,sys; sys.exit(0 if importlib.util.find_spec(sys.argv[1]) else 1)' "$frameworkModule"; then
              echo "[CodeInjector] O interpretador ${'$'}PYTHON não encontra o módulo '$frameworkModule'." >&2
              if [ "$frameworkModule" = "kivy" ]; then
                echo "[CodeInjector] Kivy geralmente exige um ambiente Linux compatível. Consulte docs/TERMUX_X11_SETUP.md e configure CODEINJECTOR_PROOT_DISTRO=debian se o pip nativo falhar." >&2
              else
                echo "[CodeInjector] Instale pygame no mesmo interpretador e confirme que suas dependências SDL são compatíveis. Para maior compatibilidade, configure a distro Debian via proot-distro conforme o guia." >&2
              fi
              exit 127
            fi
            echo "[CodeInjector] Python: ${'$'}PYTHON"
            exec "${'$'}PYTHON" "$scriptPath"
        """.trimIndent()

        val callbackIntent = Intent(app, TermuxCommandResultReceiver::class.java)
            .setAction(TermuxCommandResultReceiver.ACTION_RESULT)
            .setData(Uri.parse("codeinjector://termux-result/$runId"))
            .putExtra(RUN_ID_EXTRA, runId)
        val pendingFlags = PendingIntent.FLAG_ONE_SHOT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        val callback = PendingIntent.getBroadcast(
            app,
            (System.currentTimeMillis() and 0x7fffffffL).toInt(),
            callbackIntent,
            pendingFlags
        )

        val intent = Intent(RUN_COMMAND_ACTION).apply {
            component = ComponentName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
            putExtra(EXTRA_PATH, "\$PREFIX/bin/bash")
            putExtra(EXTRA_ARGUMENTS, arrayOf("-lc", shell))
            putExtra(EXTRA_STDIN, stdinPayload)
            putExtra(EXTRA_WORKDIR, "~/")
            putExtra(EXTRA_BACKGROUND, false)
            putExtra(EXTRA_SESSION_ACTION, "0")
            putExtra(EXTRA_LABEL, "CodeInjector · $frameworkName")
            putExtra(EXTRA_DESCRIPTION, "Executa um script gráfico Python na sessão Termux:X11.")
            putExtra(EXTRA_PENDING_INTENT, callback)
        }
        app.startService(intent)
        LaunchResult(runId, frameworkName)
    }

    /** Abre uma sessão Termux para instalar uma biblioteca Python, respeitando a distro opcional. */
    fun installPythonPackage(context: Context, packageName: String): Result<Unit> = runCatching {
        val app = context.applicationContext
        check(isInstalled(app, TERMUX_PACKAGE)) { "Instale o Termux antes de gerenciar bibliotecas externas." }
        check(packageName.matches(Regex("[A-Za-z0-9][A-Za-z0-9_.-]{0,99}"))) { "Nome de pacote inválido." }
        if (Build.VERSION.SDK_INT >= 23) {
            check(app.checkSelfPermission("com.termux.permission.RUN_COMMAND") == PackageManager.PERMISSION_GRANTED) {
                "Conceda a permissão Executar comandos no Termux nas configurações do Android."
            }
        }
        val lowerPackage = packageName.lowercase()
        val shell = """
            set -eu
            CODEINJECTOR_PROOT_DISTRO=""
            CONFIG_FILE="${'$'}HOME/.codeinjector/termux-x11.conf"
            if [ -f "${'$'}CONFIG_FILE" ]; then . "${'$'}CONFIG_FILE"; fi
            if [ -n "${'$'}CODEINJECTOR_PROOT_DISTRO" ]; then
              case "${'$'}CODEINJECTOR_PROOT_DISTRO" in *[!a-zA-Z0-9_-]*) echo "[CodeInjector] Nome de distro inválido em ${'$'}CONFIG_FILE." >&2; exit 2 ;; esac
              command -v proot-distro >/dev/null 2>&1 || { echo "Instale proot-distro: pkg install proot-distro" >&2; exit 127; }
              echo "[CodeInjector] Instalando $packageName na distro ${'$'}CODEINJECTOR_PROOT_DISTRO…"
              case "$lowerPackage" in
                kivy)
                  proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get update
                  exec proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get install -y python3-kivy
                  ;;
                pygame)
                  proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get update
                  exec proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get install -y python3-pygame
                  ;;
                *)
                  proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get update
                  proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get install -y python3-pip
                  exec proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- python3 -m pip install --break-system-packages '$packageName'
                  ;;
              esac
            fi
            if [ "$lowerPackage" = "kivy" ]; then
              echo "[CodeInjector] Aviso: pip install kivy no Python nativo do Termux pode falhar. Para Kivy, prefira configurar Debian via proot-distro no guia docs/TERMUX_X11_SETUP.md."
            fi
            if [ -x "${'$'}HOME/kv/bin/python" ]; then
              exec "${'$'}HOME/kv/bin/python" -m pip install '$packageName'
            elif command -v python >/dev/null 2>&1; then
              exec python -m pip install '$packageName'
            elif command -v python3 >/dev/null 2>&1; then
              exec python3 -m pip install '$packageName'
            else
              echo 'Python não encontrado. Execute: pkg install python' >&2
              exit 127
            fi
        """.trimIndent()
        val intent = Intent(RUN_COMMAND_ACTION).apply {
            component = ComponentName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
            putExtra(EXTRA_PATH, "\$PREFIX/bin/bash")
            putExtra(EXTRA_ARGUMENTS, arrayOf("-lc", shell))
            putExtra(EXTRA_WORKDIR, "~/")
            putExtra(EXTRA_BACKGROUND, false)
            putExtra(EXTRA_SESSION_ACTION, "0")
            putExtra(EXTRA_LABEL, "Instalar biblioteca Python")
            putExtra(EXTRA_DESCRIPTION, "Instala $packageName no Python selecionado pelo CodeInjector.")
        }
        app.startService(intent)
    }

    /** Pede para o processo externo terminar; force=true usa SIGKILL. */
    fun stop(context: Context, runId: String, force: Boolean = false) {
        if (!runId.matches(Regex("[A-Za-z0-9_-]{1,64}"))) return
        val app = context.applicationContext
        if (!isInstalled(app, TERMUX_PACKAGE)) return
        val signal = if (force) "-KILL" else "-INT"
        val pidPath = "\$HOME/.codeinjector/runs/ci-$runId/.pid"
        val shell = "if [ -f \"$pidPath\" ]; then p=\$(cat \"$pidPath\"); kill $signal \"\$p\" 2>/dev/null || true; fi"
        runCatching {
            val intent = Intent(RUN_COMMAND_ACTION).apply {
                component = ComponentName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
                putExtra(EXTRA_PATH, "\$PREFIX/bin/bash")
                putExtra(EXTRA_ARGUMENTS, arrayOf("-lc", shell))
                putExtra(EXTRA_WORKDIR, "~/")
                putExtra(EXTRA_BACKGROUND, true)
                putExtra(EXTRA_LABEL, "Encerrar script CodeInjector")
            }
            app.startService(intent)
        }
    }

    @Suppress("DEPRECATION")
    private fun isInstalled(context: Context, packageName: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= 33) {
            context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
        } else {
            context.packageManager.getPackageInfo(packageName, 0)
        }
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    private fun safePythonFileName(name: String): String {
        val leaf = name.substringAfterLast('/').substringAfterLast('\\').trim()
        val safe = leaf.replace(Regex("[^A-Za-z0-9_.-]"), "_")
        return safe.takeIf { it.endsWith(".py", ignoreCase = true) && it != ".py" } ?: "main.py"
    }

    /** Preserva diretórios relativos, rejeitando caminhos que poderiam escapar do ZIP/da pasta de execução. */
    private fun safeProjectPath(name: String): String? {
        val normalized = name.replace('\\', '/')
        if (normalized.isBlank() || normalized.startsWith('/') || normalized.contains(':')) return null
        val parts = normalized.split('/')
        if (parts.any { part ->
                part.isBlank() || part == "." || part == ".." ||
                    part.any { ch -> ch.isISOControl() || ch == '"' || ch == '$' || ch == '`' }
            }) return null
        return normalized
    }

    /** Coleta o projeto escolhido pelo seletor Android (SAF), incluindo recursos binários pequenos. */
    private fun loadSafProjectFiles(
        context: Context, treeUriValue: String, rootDocId: String, mainDocId: String
    ): Pair<String, Map<String, ByteArray>>? {
        val treeUri = Uri.parse(treeUriValue)
        val candidates = ArrayList<Pair<String, DocEntry>>()
        val pending = ArrayDeque<Pair<String, String>>()
        pending.add(rootDocId to "")
        var scanned = 0
        var mainPath: String? = null

        // Primeiro encontra o arquivo principal e reúne os caminhos candidatos. Isso evita varrer
        // e ler assets de uma pasta selecionada que não contém o arquivo que o usuário executou.
        while (pending.isNotEmpty()) {
            val (directoryId, prefix) = pending.removeFirst()
            for (entry in ProjectFs.list(context, treeUri, directoryId)) {
                scanned++
                check(scanned <= 2000) {
                    "A pasta do projeto contém mais de 2.000 itens. Escolha uma pasta menor para executar Kivy/Pygame."
                }
                val relative = if (prefix.isEmpty()) entry.name else "$prefix/${entry.name}"
                if (entry.isDir) {
                    if (entry.name !in PROJECT_SKIP_DIRS && prefix.count { it == '/' } < 20) {
                        pending.add(entry.id to relative)
                    }
                    continue
                }
                if (entry.id == mainDocId) mainPath = relative
                val extension = entry.name.substringAfterLast('.', "").lowercase()
                if (extension in PROJECT_RUNTIME_EXTENSIONS && safeProjectPath(relative) != null) {
                    candidates += relative to entry
                }
            }
        }
        val safeMain = mainPath?.let { safeProjectPath(it) } ?: return null
        check(candidates.size <= MAX_PROJECT_FILES) {
            "O projeto contém mais de $MAX_PROJECT_FILES arquivos de runtime. Reduza a quantidade de arquivos antes de executar via Termux:X11."
        }

        val files = LinkedHashMap<String, ByteArray>()
        var totalBytes = 0L
        for ((relative, entry) in candidates) {
            val safe = safeProjectPath(relative) ?: continue
            val uri = ProjectFs.docUri(treeUri, entry.id)
            val content = context.contentResolver.openInputStream(uri)?.use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (totalBytes + output.size() + count > MAX_PROJECT_RAW_BYTES) {
                        throw IllegalArgumentException("Os arquivos de runtime do projeto passam de 4 MB. Reduza os recursos antes de executar via Termux:X11.")
                    }
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            } ?: continue
            totalBytes += content.size
            files[safe] = content
        }
        return safeMain to files
    }

    /** Lê somente arquivos de runtime de um projeto público importado, nunca fora da pasta privada do app. */
    private fun loadProjectFiles(context: Context, rootPath: String): Map<String, ByteArray> {
        val permittedRoot = File(context.filesDir, "github_projects").canonicalFile
        val root = File(rootPath).canonicalFile
        check(root.toPath().startsWith(permittedRoot.toPath()) && root != permittedRoot && root.isDirectory) {
            "A pasta do projeto importado não é válida. Importe novamente o repositório pelo GitHub."
        }
        val files = LinkedHashMap<String, ByteArray>()
        var totalBytes = 0L
        val walker = root.walkTopDown().onEnter { dir -> dir == root || dir.name !in PROJECT_SKIP_DIRS }
        for (file in walker.filter { it.isFile }) {
            val extension = file.extension.lowercase()
            if (extension !in PROJECT_RUNTIME_EXTENSIONS) continue
            val relative = runCatching { file.relativeTo(root).invariantSeparatorsPath }.getOrNull() ?: continue
            val safe = safeProjectPath(relative) ?: continue
            if (files.size >= MAX_PROJECT_FILES) {
                throw IllegalArgumentException("O projeto contém mais de $MAX_PROJECT_FILES arquivos de runtime. Reduza a quantidade de arquivos antes de executar via Termux:X11.")
            }
            val length = file.length()
            if (length > MAX_PROJECT_RAW_BYTES || totalBytes + length > MAX_PROJECT_RAW_BYTES) {
                throw IllegalArgumentException("Os arquivos de runtime do projeto passam de 4 MB. Reduza os recursos antes de executar via Termux:X11.")
            }
            val content = file.readBytes()
            totalBytes += content.size
            files[safe] = content
        }
        return files
    }

    private fun createArchive(
        mainName: String,
        source: String,
        siblings: Map<String, String>,
        projectFiles: Map<String, ByteArray>
    ): ByteArray {
        val entries = LinkedHashMap<String, ByteArray>()
        projectFiles.forEach { (name, bytes) -> safeProjectPath(name)?.let { entries[it] = bytes } }
        siblings.forEach { (name, text) ->
            if (name.endsWith(".py", ignoreCase = true) && '/' !in name && '\\' !in name) {
                safeProjectPath(name)?.let { entries[it] = text.toByteArray(Charsets.UTF_8) }
            }
        }
        val safeMain = safeProjectPath(mainName) ?: safePythonFileName(mainName)
        // A versão que está no editor prevalece sobre a cópia salva no disco.
        entries[safeMain] = source.toByteArray(Charsets.UTF_8)
        val bytes = ByteArrayOutputStream()
        ZipOutputStream(bytes).use { zip ->
            entries.forEach { (name, content) ->
                zip.putNextEntry(ZipEntry(name))
                zip.write(content)
                zip.closeEntry()
            }
        }
        return bytes.toByteArray()
    }
}
