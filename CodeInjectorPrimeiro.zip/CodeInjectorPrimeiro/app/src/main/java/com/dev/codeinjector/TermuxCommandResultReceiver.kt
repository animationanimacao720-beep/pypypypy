package com.dev.codeinjector

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle

/** Recebe a conclusão do comando encaminhado ao Termux pelo PendingIntent. */
class TermuxCommandResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent == null) return
        val runId = intent.getStringExtra(TermuxX11Runner.RUN_ID_EXTRA)
            ?: intent.data?.lastPathSegment
            ?: return
        // O Termux envia os resultados dentro de EXTRA_PLUGIN_RESULT_BUNDLE. Ao achatar
        // extras e procurar por "STDOUT" parcialmente, STDOUT_ORIGINAL_LENGTH podia ser
        // confundido com a saída real. Compare o nome final exato da chave.
        val values = LinkedHashMap<String, Any?>()
        intent.extras?.let { extras ->
            for (key in extras.keySet()) {
                when (val value = extras.get(key)) {
                    is Bundle -> for (nestedKey in value.keySet()) values[nestedKey] = value.get(nestedKey)
                    else -> values[key] = value
                }
            }
        }
        fun valueFor(vararg acceptedNames: String): Any? = values.entries.firstOrNull { (key, _) ->
            key.substringAfterLast('.').uppercase() in acceptedNames
        }?.value
        val exitCode = (valueFor("EXIT_CODE") as? Number)?.toInt() ?: -1
        val stdout = valueFor("STDOUT") as? String ?: ""
        val stderr = valueFor("STDERR") as? String ?: ""
        val error = valueFor("ERRMSG") as? String ?: ""
        PyRunner.onExternalCommandFinished(runId, exitCode, stdout, stderr, error)
    }

    companion object {
        const val ACTION_RESULT = "com.dev.codeinjector.action.TERMUX_COMMAND_RESULT"
    }
}
