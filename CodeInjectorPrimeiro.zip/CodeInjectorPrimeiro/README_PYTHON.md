# CodeInjector — IDE Python (Chaquopy)

## O que mudou
- Removidos os runners antigos de Java, Termux e Judge0, que não eram usados pela IDE. A execução Python comum continua via Chaquopy.
- Novo: `PyRunner` (CPython via Chaquopy), `SyntaxAnalyzer` (CPython `compile()` + scanner rápido),
  `KeyboardSuggestionBar`, `FileExplorerSidebar`, `CodeEditorScreen` reescrito, `app/src/main/python/ci_runner.py`.
- Removidos também: `TextInjectorService`, serviço de acessibilidade, injeção de texto e sincronização/atalho do CodeAssist.
- Mantidos: `Session`, `Project` (SAF), `KeyBindingHandler`, snippets.
- Novidades: botão executar flutuante (menu ⋮), "↻ Repetir" no console, barra inferior só com tab, desfazer/refazer, setas, copiar e colar, guias de indentação (estilo Godot, ligam/desligam no menu ⋮), indentação só com tabs, seleção por arrasto e botões Tudo/Cortar/Apagar, e gerenciador de arquivos em árvore (arraste da borda esquerda ou toque em ☰).

## Atalhos (teclado físico)
Ctrl+R / F5 rodar · Shift+F5 / Ctrl+. parar · Ctrl+S salvar · Ctrl+F buscar · Ctrl+H substituir · Ctrl+B painel de arquivos
Ctrl+/ comentar · Ctrl+D duplicar linha · Alt+↑/↓ mover linha · Ctrl+G ir p/ linha · Ctrl+N/W/O aba nova/fechar/abrir

## Fontes
JetBrains Mono já vem em `app/src/main/assets/fonts/`. Para Fira Code, coloque `FiraCode-Regular.ttf` na mesma pasta
(o app detecta sozinho; menu ⋮ → Fonte).

## Build
Chaquopy é um plugin do Gradle: compile com Android Studio / Gradle (não só com o build interno do CodeAssist).
Python 3.11 no PATH do PC de build é opcional (só gera .pyc; sem ele o build segue com aviso).
Arquivos lidos/gravados pelos scripts ficam em `files/py_workspace` (as abas .py abertas são copiadas para lá para `import` funcionar).

## Como gerar o APK (Gradle)
**GitHub Actions (só pelo celular):** crie um repositório, envie esta pasta (a raiz do repo deve conter `settings.gradle.kts`),
abra a aba Actions → "Build APK" → Run workflow → baixe o artefato `CodeInjector-debug-apk` e instale.
**Android Studio:** File → Open na pasta, aguarde o sync e rode `assembleDebug` (precisa de JDK 17 e SDK 34).

## Novidades (v2.1)
- Console: Copiar, Limpar, ↻ Repetir, cores ANSI, tempo de execução e código de saída.
- Buscar no projeto e Símbolos (funções/classes) no menu ⋮.
- Dobrar blocos (seta no gutter) e breakpoints (toque no número da linha) com depurador simples: Continuar / Passo / variáveis.
- Linter com avisos amarelos: import e variável local não usados.
- Marcadores de tab (→), guias de indentação, indentação só com tabs.
- "Abrir com" para .py/texto de outros apps e Compartilhar.
- Entradas prontas para input() (menu ⋮).
- Biblioteca `requests` incluída (pip no build.gradle.kts; descomente numpy se quiser, mas o APK fica bem maior).

## Novidades (v2.2)
- Auto-completar de membros depois do ponto (`texto.`, `lista.`, `os.`, `self.`, objetos das suas classes), inferido do próprio código.
- Terminal Python (REPL) no console: botão "Terminal"; mantém variáveis entre comandos; blocos terminam com linha em branco.
  Com o terminal ligado, as variáveis do último script rodado ficam disponíveis nele (como `python -i`).


## Kivy, Pygame e Termux:X11
- Ao executar um arquivo que importa `kivy` ou `pygame`, a IDE detecta o framework e encaminha o script ao Python do Termux ou à distro PRoot configurada, iniciando/abrindo o Termux:X11. Scripts Python comuns continuam usando Chaquopy dentro do CodeInjector.
- O código do arquivo atual e as outras abas `.py` abertas são enviados como um ZIP temporário para `~/.codeinjector/runs/` dentro do Termux. O projeto não instala os pacotes Kivy/Pygame automaticamente; eles precisam estar disponíveis no Python que a sessão Termux usa.
- É necessário instalar **Termux** e **Termux:X11** compatíveis entre si. O Termux:X11 precisa tanto do APK Android quanto do pacote complementar dentro do Termux. Consulte as instruções oficiais: https://github.com/termux/termux-x11.
- No Termux, habilite a execução externa editando `~/.termux/termux.properties` e adicionando `allow-external-apps=true`; salve e reinicie o Termux. Na página de informações do CodeInjector nas configurações do Android, conceda a permissão adicional **Executar comandos no ambiente Termux** (`com.termux.permission.RUN_COMMAND`).
- A integração seleciona `~/kv/bin/python` se esse ambiente existir; caso contrário, usa `python` ou `python3` no Termux. A configuração de SDL/X11 padroniza `termux-x11 :1` e `DISPLAY=:1`, além de `SDL_VIDEODRIVER=x11`, antes de executar o programa. Se necessário, tenta novamente com `-legacy-drawing`.
- Se a permissão não estiver ativada, o Termux/X11 não estiver instalado ou o pacote gráfico não estiver disponível no Python selecionado, a mensagem será mostrada no console da IDE. Assets externos e arquivos não-Python ainda não são empacotados automaticamente; mantenha-os no ambiente Termux ou ajuste-os no script.

## Melhorias adicionais (integração Termux:X11 e ferramentas)

- **Detecção gráfica:** a IDE procura imports explícitos de Kivy/Pygame no arquivo principal que será executado. Scripts gráficos são enviados ao Termux; scripts comuns continuam no Chaquopy. Isso evita que uma aba Kivy não relacionada redirecione acidentalmente um script comum.
- **Inicialização X11:** o runner tenta iniciar `termux-x11 :1`, abrir a Activity Termux:X11 e executar o script com `DISPLAY=:1` e `SDL_VIDEODRIVER=x11`; caso o modo padrão falhe, tenta `-legacy-drawing`. O runner verifica se o processo do servidor iniciou, registra falhas em `~/.codeinjector/runs/ci-*/termux-x11.log` e limita o ZIP enviado a 160 KB compactados para reduzir o risco de exceder o tamanho permitido pelo Android. O comportamento depende da versão do Termux:X11 e do dispositivo; não foi possível validar uma janela gráfica real neste ambiente de build.
- **Parar script:** o botão Parar envia um sinal ao processo gráfico; tocar novamente permite tentar forçar o encerramento. O runner identifica o PID do shell de execução, portanto processos filhos nativos podem exigir encerramento manual no Termux.
- **Console:** o painel Console existente mostra stdout/stderr, mensagens de inicialização, erros e resultado reportado pelo Termux.
- **Bibliotecas:** menu ⋮ → “Instalar biblioteca Python (Termux)…” abre uma sessão Termux; com `CODEINJECTOR_PROOT_DISTRO=debian`, instala Kivy/Pygame com `apt` na distro configurada; sem essa configuração, tenta `pip` em `~/kv` ou no Python do Termux. Isso não altera os pacotes do Chaquopy. Confirme o nome do pacote antes de instalar.
- **Projetos/arquivos:** o explorador de arquivos existente usa o seletor de pastas Android (SAF). Os arquivos abertos e salvos por SAF continuam funcionando.
- **GitHub:** menu ⋮ → “Importar projeto do GitHub…” baixa repositórios públicos HTTPS, limita a extração a 25 MB e bloqueia caminhos ZIP fora da pasta de destino. Os arquivos importados ficam em `files/github_projects` no armazenamento privado do app; a primeira `.py` é aberta numa aba. Importação privada/autenticada, push/commit e sincronização Git não são implementados. Arquivos de recursos e módulos adicionais são preservados no diretório importado, mas ainda não são sincronizados automaticamente para o Termux ao executar.

### Ambiente Linux opcional para Kivy/Pygame

Se Kivy/Pygame não for compatível com o Python nativo do Termux, o runner suporta uma distro Debian já instalada por `proot-distro`. Instale `python3-kivy` e/ou `python3-pygame` dentro da distro e, no Termux normal, crie `~/.codeinjector/termux-x11.conf` com a linha `CODEINJECTOR_PROOT_DISTRO=debian`. Nesse modo, o runner usa `--shared-tmp` para que a distro acesse o servidor X11 em `DISPLAY=:1`. Consulte o guia detalhado para todos os comandos e limitações.

### Requisitos do Termux

Siga o guia detalhado [`docs/TERMUX_X11_SETUP.md`](docs/TERMUX_X11_SETUP.md). Em resumo: instale Termux e Termux:X11 de fontes oficiais compatíveis; instale `x11-repo`, `termux-x11-nightly`, `python`, `unzip`, `coreutils` e `procps`; configure `allow-external-apps=true` em `~/.termux/termux.properties` (não digite essa linha como comando); e conceda a permissão adicional `com.termux.permission.RUN_COMMAND` ao CodeInjector.

**Nota importante sobre bibliotecas:** Termux:X11 é o servidor gráfico, não instala Kivy/Pygame por si só. `pip install kivy` pode falhar no Python nativo do Android. Verifique a importação com o mesmo Python selecionado pelo runner. Para detalhes sobre ambiente Debian/`proot-distro`, recursos de projeto e diagnóstico, consulte o guia.

### Limitações de validação

Esta entrega foi revisada estaticamente e o ZIP/manifesto são verificados durante a preparação. Não declarar como validada a compilação Android, a instalação do APK, downloads em rede no aparelho nem a abertura real de janelas X11: esses testes exigem Android/Gradle/Termux no dispositivo. Para compilar, abra a pasta no Android Studio com JDK 17 e SDK Android 34 ou use o workflow GitHub Actions existente.
