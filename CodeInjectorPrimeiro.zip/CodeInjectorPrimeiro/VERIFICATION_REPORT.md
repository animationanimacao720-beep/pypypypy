# Relatório de verificação — botão flutuante de execução Kivy/Pygame

Data: 2026-10-18

## Alterações desta versão

- O botão de execução flutuante fica sempre visível, pode ser arrastado e abre três opções: **Executar Kivy · Termux:X11**, **Executar Pygame · Termux:X11** e **Executar dentro da IDE**.
- Kivy e Pygame usam uma API explícita em `PyRunner.runExternalFramework`; esses botões não dependem do detector de imports. O `TermuxX11Runner` continua a preparar o projeto, iniciar `termux-x11 :1`, definir `DISPLAY=:1` e `SDL_VIDEODRIVER=x11`, tentar abrir a Activity oficial e executar o script com o Python selecionado no Termux ou na distro PRoot configurada.
- A opção “Executar dentro da IDE” passa `routeGraphicFramework=false`, obrigando o script a seguir pelo Python embutido (Chaquopy), mesmo que contenha import de Kivy/Pygame.
- O botão de execução da barra e os atalhos de execução existentes continuam preservando a detecção automática.
- A documentação do setup foi atualizada com as três opções e seus requisitos.

## Verificações executadas

- `python tools/verify_project.py` — verificação estática do manifesto, integração Termux:X11, menu flutuante e caminhos de execução explícitos.
- `sh tools/run_detector_tests.sh` — testes existentes do detector de framework.
- `python -m py_compile app/src/main/python/ci_runner.py` — validação sintática do runtime Python embutido.
- `unzip -t` no ZIP final — integridade do arquivo de entrega.

## Limitações

- Não foi executado `gradle assembleDebug` neste ambiente: não há Gradle/Android SDK instalados localmente. O projeto precisa passar pelo workflow GitHub Actions para validar a compilação Android completa.
- Não foi possível testar um aparelho Android real, a permissão `RUN_COMMAND`, o início do Termux:X11 nem abrir uma janela Kivy/Pygame real neste ambiente. As opções Kivy/Pygame encaminham o script explicitamente ao Termux, mas a abertura da janela depende de Termux + Termux:X11 compatíveis, `allow-external-apps=true`, permissão Android, servidor X11 funcional e biblioteca disponível no interpretador selecionado.
- O modo “Executar dentro da IDE” só executa frameworks gráficos se as bibliotecas necessárias estiverem disponíveis e forem compatíveis com Chaquopy; o pacote Kivy/Pygame do Termux não é automaticamente disponibilizado ao Python embutido.
