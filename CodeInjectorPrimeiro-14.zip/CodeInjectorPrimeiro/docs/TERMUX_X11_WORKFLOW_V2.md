# Termux:X11 — mudanças do fluxo v2

## Fluxo novo

1. O CodeInjector detecta um framework gráfico entre Kivy, Pygame, Tkinter, Pyglet, Arcade e Qt.
2. Se o projeto já estiver em armazenamento compartilhado e sem buffer aberto não salvo, executa no caminho existente (preservando recursos e subpastas).
3. Caso contrário, copia a árvore do projeto por SAF para `.codeinjector-workspace` dentro da pasta-ponte escolhida no Android. Buffers atuais são aplicados à cópia, e não ao original.
4. O Termux executa o script com o diretório do projeto como working directory e com a raiz no `PYTHONPATH`. A distro PRoot usa `--shared-tmp` e mounts sob `/tmp`.
5. `stdout.log` e `stderr.log` são atualizados pelo processo externo; a IDE lê os novos bytes de forma incremental e tenta converter tracebacks do script principal em diagnósticos de linha.
6. O caminho de inicialização não abre um processo Python extra para testar o import antes da execução, e `CODEINJECTOR_LIBGL_MODE=auto` evita forçar renderização OpenGL por software no PRoot. O modo `software` continua disponível como fallback de compatibilidade.
6. Parar sinaliza o grupo de processos do script. O X server não é encerrado durante o stop normal.

## Arquivos centrais

- `TermuxWorkspace.kt`: escolha do caminho direto ou staging SAF, cópia de recursos e seleção de `.py` no projeto.
- `TermuxX11Runner.kt`: RUN_COMMAND, inicialização X11, pré-checagem de pacote, diagnósticos, instalação e sinais ao grupo de processos.
- `PythonFrameworkDetector.kt`: detector dos imports reconhecidos.
- `PyRunner.kt`: alternância Chaquopy/Termux, leitura incremental dos logs e tentativa de localizar tracebacks.
- `CodeEditorScreen.kt`: seleção do arquivo principal, diagnóstico, botão de instalar módulo ausente e ajustes de X11.
- `docs/TERMUX_X11_SETUP.md`: instruções de configuração e limitações.

## Guardrails

- A cópia por SAF limita-se a 4.000 arquivos e 180 MB; o caminho direto não faz essa cópia.
- Pastas de build/cache conhecidas são ignoradas. A pasta-ponte não pode ficar dentro do projeto.
- Não se promete que o modo de janela adjacente será aplicado: o Android decide se multi-janela está disponível.
- A execução gráfica ocorre fora do processo Chaquopy; breakpoints passo a passo não são transportados.
- A experiência real de dispositivos ainda precisa de teste com o APK e o Termux instalados.
