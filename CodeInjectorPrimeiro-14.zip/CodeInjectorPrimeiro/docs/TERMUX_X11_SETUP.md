# Termux + Termux:X11 no CodeInjector (fluxo v2)

Este guia explica a integração gráfica externa. Scripts gráficos rodam no Python nativo do Termux ou numa distro PRoot já configurada; scripts comuns continuam no Chaquopy dentro do APK. O servidor X11 pode permanecer ativo entre execuções, enquanto o grupo de processos do programa é encerrado separadamente.

## 1. Instalar Termux e Termux:X11

O Termux:X11 exige **o APK Android e o pacote complementar `termux-x11-nightly` dentro do Termux**. Instale versões compatíveis a partir das fontes oficiais. Abra o Termux uma vez e execute:

```sh
pkg update
pkg upgrade
pkg install x11-repo termux-x11-nightly python coreutils procps proot-distro
```

Referências oficiais: [Termux:X11](https://github.com/termux/termux-x11) e [RUN_COMMAND](https://github.com/termux/termux-app/wiki/RUN_COMMAND-Intent).

## 2. Permitir a integração

No Termux, execute o bloco inteiro:

```sh
mkdir -p ~/.termux
touch ~/.termux/termux.properties
if grep -Eq '^[[:space:]]*allow-external-apps[[:space:]]*=' ~/.termux/termux.properties; then
  sed -i -E 's/^[[:space:]]*allow-external-apps[[:space:]]*=.*/allow-external-apps=true/' ~/.termux/termux.properties
else
  printf '\nallow-external-apps=true\n' >> ~/.termux/termux.properties
fi
termux-reload-settings
termux-setup-storage
```

Depois, nas configurações Android do CodeInjector, conceda a permissão adicional **Executar comandos no ambiente Termux** (`com.termux.permission.RUN_COMMAND`). Se o serviço não conseguir abrir sessões automaticamente, confira também a permissão de sobreposição/execução em segundo plano do Termux, quando disponível no seu Android.

## 3. Configure uma pasta compartilhada para projetos importados ou alterados

No CodeInjector, abra o menu `⋮` → **Configurar pasta compartilhada Termux…** e selecione uma subpasta do armazenamento interno compartilhado, por exemplo `Documents/CodeInjectorTermux`. Não escolha a raiz inteira do armazenamento.

A integração trabalha de duas maneiras:

- **Projeto já salvo no armazenamento compartilhado:** executa a partir do caminho real, sem compactar ou copiar o projeto. Imagens, áudio, fontes e subpastas ficam acessíveis por caminhos relativos.
- **Projeto em local privado/SAF ou com alterações ainda não salvas no editor:** copia os arquivos da pasta do projeto para `.codeinjector-workspace` dentro da pasta-ponte, incluindo recursos binários e subpastas; o texto atual das abas abertas é aplicado apenas nessa cópia, sem sobrescrever o original silenciosamente.

Para a cópia por SAF, o runner impõe salvaguardas de **4.000 arquivos e 180 MB por preparação**. Pastas de cache/build conhecidas são ignoradas. A pasta-ponte deve ficar **fora** da pasta do projeto, para evitar cópia recursiva. O caminho de execução é reutilizado; em projetos copiados, o conteúdo é sincronizado por uma recópia segura a cada execução, por isso a maior economia na segunda execução vem principalmente de manter o servidor X11 vivo.

## 4. Rodar o projeto e escolher o arquivo principal

Abra a pasta do projeto pelo explorador do CodeInjector e use `⋮` → **Executar arquivo principal do projeto…**. O seletor lista arquivos `.py` em subpastas; selecione o ponto de entrada (`main.py`, por exemplo). `PYTHONPATH` inclui a raiz do projeto e o processo começa no diretório do projeto, permitindo imports locais e caminhos relativos a imagens/sons/fontes. Também é possível executar a aba atual pelo botão normal de execução.

O detector identifica imports explícitos de `kivy`, `pygame`, `tkinter`, `pyglet`, `arcade`, `PyQt5`, `PyQt6`, `PySide2` e `PySide6`. Chamadas dinâmicas e frameworks carregados sem um import reconhecível podem não ser detectados automaticamente.

## 5. Saída em tempo real, tracebacks e parar

A saída padrão e os erros do processo são redirecionados para `stdout.log` e `stderr.log` na pasta de execução. A IDE lê novos bytes periodicamente, portanto `print()` e erros aparecem sem esperar o programa terminar (desde que o script não retenha a saída em buffers próprios). Se o traceback apontar para o arquivo principal, a linha é encaminhada ao diagnóstico do editor; tracebacks em arquivos de biblioteca externa ou frames sem um caminho reconhecível podem não virar um marcador clicável.

O botão **Parar** envia `TERM` ao grupo de processos iniciado para o script; pressionar novamente ou escolher a opção forçada envia `KILL`. Isso é mais abrangente que matar apenas o processo principal. O servidor `termux-x11` é mantido separado para acelerar execuções seguintes. Processos deliberadamente desacoplados/daemonizados podem escapar de um grupo, por isso o comportamento final ainda depende de como o script cria subprocessos.

## 6. Diagnóstico e bibliotecas

O menu `⋮` → **Diagnosticar Termux / X11…** verifica o APK Termux, o APK Termux:X11, `allow-external-apps`, o comando `termux-x11`, Python, acesso ao armazenamento compartilhado, o socket X11 e módulos gráficos no Python nativo; se `CODEINJECTOR_PROOT_DISTRO` estiver configurado, também tenta verificar módulos nessa distro. O diálogo inclui um comando de correção copiável. RUN_COMMAND precisa estar permitido para que o diagnóstico execute dentro do Termux; caso contrário, o próprio diálogo mostra a falha e o comando de reparo.

Quando aparece `No module named ...`, o console mostra **Instalar [módulo]**. O instalador opera no ambiente escolhido pela configuração `~/.codeinjector/termux-x11.conf`:

```sh
mkdir -p ~/.codeinjector
printf 'CODEINJECTOR_PROOT_DISTRO=debian\nCODEINJECTOR_LIBGL_MODE=auto\n' > ~/.codeinjector/termux-x11.conf
proot-distro install debian
proot-distro login debian -- apt-get update
proot-distro login debian -- apt-get install -y python3 python3-pip python3-kivy python3-pygame python3-tk python3-pyqt5
```

A lista de pacotes muda por distribuição e framework. Os pacotes Qt, Pyglet e Arcade podem ter nomes/disponibilidade diferentes; nesses casos o instalador tenta `pip` dentro da distro. `tkinter` não é um pacote pip útil no Python nativo do Termux, por isso é recomendado Debian/PRoot com `python3-tk`.

### Desempenho de inicialização e renderização

O executor evita abrir um processo Python extra apenas para verificar se o módulo gráfico existe; se o import falhar, o traceback real do script continua sendo reconhecido pela IDE. A inicialização do X11 também não espera 1 segundo fixo: usa o socket do display para saber quando o servidor está pronto e consulta-o em intervalos de 100 ms. Se o servidor já estiver ativo, a Activity Termux:X11 é trazida de volta à frente sem reiniciá-lo.

`CODEINJECTOR_LIBGL_MODE=auto` (padrão) não força `LIBGL_ALWAYS_SOFTWARE`; deixa o Mesa selecionar o driver disponível. Isso pode melhorar frameworks que dependem de OpenGL quando há um driver adequado, mas não garante aceleração por GPU em todas as instalações Android/Termux:X11/PRoot. Se um projeto apresentar tela preta ou falhar na criação do contexto gráfico, use `CODEINJECTOR_LIBGL_MODE=software` como fallback de compatibilidade.

## 7. Ajustes de janela e toque

O menu `⋮` → **Ajustes de tela do Termux:X11…** permite escolher modo de resolução (nativa, escalada, exata ou personalizada), resolução exata, escala, adaptação à rotação, modo de toque, PiP e tela cheia. Para uma resolução personalizada, a opção retrato/paisagem ajusta a proporção informada; ela não força o Android inteiro a girar. As preferências são encaminhadas a `termux-x11-preference` e dependem das opções disponíveis na versão instalada. O utilitário oficial documenta `termux-x11-preference list` para consultar as opções existentes. A Activity do Termux:X11 precisa estar em primeiro plano ou segundo plano de forma disponível para esse comando não ficar pendurado.

O item **Abrir Termux:X11 em tela dividida** solicita ao Android colocar o app adjacente. É uma solicitação de melhor esforço do sistema; o fabricante, a versão Android e a política de multi-janela podem impedir a divisão. O PiP também depende do suporte e das preferências da versão do Termux:X11.

## 8. Limitações conhecidas

- Breakpoints e depuração passo a passo do Chaquopy não acompanham a execução gráfica num processo Python externo.
- O APK precisa ser instalado/testado em dispositivo para validar o ciclo Termux/X11, permissões e preferências reais; as verificações estáticas e testes do detector não substituem esse ensaio.
- O PRoot precisa de `--shared-tmp` para compartilhar o socket X11, conforme a documentação oficial.
- A leitura do log é incremental em blocos de até 256 KiB por ciclo; ciclos subsequentes continuam do offset anterior, inclusive para logs longos.
