package com.dev.codeinjector

import android.Manifest
import android.content.Context
import java.io.File
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import android.view.KeyEvent as NativeKeyEvent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.layout as layoutMod
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.nativeKeyCode
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.input.pointer.pointerHoverIcon
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextIndent
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

// ============================================================ temas
data class CodeTheme(
    val name: String,
    val bg: Color, val bar: Color, val gutterBg: Color, val gutterText: Color, val gutterActive: Color,
    val text: Color, val cursor: Color,
    val keyword: Color, val builtin: Color, val string: Color, val comment: Color, val number: Color,
    val function: Color, val className: Color, val decorator: Color, val self: Color,
    val error: Color, val chip: Color,
    // cores extras do realce: True/False/None e CONSTANTES, chamadas f(), membros .x, operadores, ( ) [ ] { }, nomes de import
    val constant: Color = Color(0xFFF07178), val call: Color = Color(0xFF7AA2F7), val attr: Color = Color(0xFF73DACA),
    val operator: Color = Color(0xFFABB2BF), val bracket: Color = Color(0xFFE5C07B), val module: Color = Color(0xFF56B6C2)
)

object CodeThemes {
    val Dracula = CodeTheme(
        "Dracula", Color(0xFF282A36), Color(0xFF21222C), Color(0xFF242530), Color(0xFF6272A4), Color(0xFFF8F8F2),
        Color(0xFFF8F8F2), Color(0xFFF8F8F0),
        Color(0xFFFF79C6), Color(0xFF8BE9FD), Color(0xFFF1FA8C), Color(0xFF6272A4), Color(0xFFBD93F9),
        Color(0xFF50FA7B), Color(0xFFFFCB6B), Color(0xFFE58AF0), Color(0xFFFFB86C),
        Color(0xFFFF5555), Color(0xFF44475A)
    )
    val Monokai = CodeTheme(
        "Monokai", Color(0xFF272822), Color(0xFF1E1F1C), Color(0xFF23241F), Color(0xFF75715E), Color(0xFFF8F8F2),
        Color(0xFFF8F8F2), Color(0xFFF8F8F0),
        Color(0xFFF92672), Color(0xFF66D9EF), Color(0xFFE6DB74), Color(0xFF75715E), Color(0xFFAE81FF),
        Color(0xFFA6E22E), Color(0xFFF4BF75), Color(0xFFFC9867), Color(0xFFFD971F),
        Color(0xFFFF4D4D), Color(0xFF3E3D32)
    )
    val GitHubDark = CodeTheme(
        "GitHub Dark", Color(0xFF0D1117), Color(0xFF161B22), Color(0xFF0D1117), Color(0xFF6E7681), Color(0xFFE6EDF3),
        Color(0xFFC9D1D9), Color(0xFFC9D1D9),
        Color(0xFFFF7B72), Color(0xFF79C0FF), Color(0xFFA5D6FF), Color(0xFF8B949E), Color(0xFF79C0FF),
        Color(0xFFD2A8FF), Color(0xFFFFD580), Color(0xFFF778BA), Color(0xFFFFA657),
        Color(0xFFF85149), Color(0xFF21262D)
    )
    val all = listOf(Dracula, Monokai, GitHubDark)
}

// ============================================================ abas
class EditorTab(val id: Int, name: String, uri: Uri? = null, text: String = "") {
    var name by mutableStateOf(name)
    var uri by mutableStateOf(uri)
    var value by mutableStateOf(TextFieldValue(text))
    var dirty by mutableStateOf(false)
    private val undoStack = ArrayDeque<TextFieldValue>()
    private val redoStack = ArrayDeque<TextFieldValue>()
    private var lastEdit = 0L
    var undoCount by mutableIntStateOf(0)
    var redoCount by mutableIntStateOf(0)
    /** Linhas (0-based) com breakpoint e cabeçalhos de bloco dobrados. */
    var breakpoints by mutableStateOf(setOf<Int>())
    var folded by mutableStateOf(setOf<Int>())

    /** Acompanha inserção/remoção de linhas: desloca breakpoints e dobras que ficam abaixo da edição. */
    private fun shiftMarks(old: String, new: String) {
        if (breakpoints.isEmpty() && folded.isEmpty()) return
        val oldN = old.count { it == '\n' }; val newN = new.count { it == '\n' }
        if (oldN == newN) return
        var p = 0; val m = minOf(old.length, new.length)
        while (p < m && old[p] == new[p]) p++
        var pl = 0
        for (i in 0 until p) if (old[i] == '\n') pl++
        val d = newN - oldN
        fun mv(set: Set<Int>) = set.mapNotNull { b -> when { b <= pl -> b; d >= 0 -> b + d; b + d <= pl -> null; else -> b + d } }.toSet()
        breakpoints = mv(breakpoints); folded = mv(folded)
    }

    private fun sync() { undoCount = undoStack.size; redoCount = redoStack.size }

    fun change(nv: TextFieldValue) {
        if (nv.text != value.text) {
            shiftMarks(value.text, nv.text)
            // agrupa a digitação contínua num único passo de desfazer (evita guardar uma cópia do arquivo por tecla)
            val now = System.currentTimeMillis()
            if (undoStack.isEmpty() || now - lastEdit > 600 || kotlin.math.abs(nv.text.length - value.text.length) > 1) {
                undoStack.addLast(value); if (undoStack.size > 100) undoStack.removeFirst()
            }
            lastEdit = now
            redoStack.clear(); dirty = true; sync()
        }
        value = nv
    }
    fun undo() { lastEdit = 0L; undoStack.removeLastOrNull()?.let { shiftMarks(value.text, it.text); redoStack.addLast(value); value = it; dirty = true; sync() } }
    fun redo() { lastEdit = 0L; redoStack.removeLastOrNull()?.let { shiftMarks(value.text, it.text); undoStack.addLast(value); value = it; dirty = true; sync() } }
}

private fun displayNameOrNull(ctx: Context, uri: Uri): String? = runCatching {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    }
}.getOrNull()

private fun displayName(ctx: Context, uri: Uri) = displayNameOrNull(ctx, uri) ?: "arquivo.py"

// ============================================================ fontes (JetBrains Mono / Fira Code via assets/fonts)
private fun loadAssetFamily(ctx: Context, file: String): FontFamily? {
    val ok = runCatching { ctx.assets.list("fonts")?.contains(file) == true }.getOrDefault(false)
    if (!ok) return null
    return runCatching { FontFamily(Font("fonts/$file", ctx.assets)) }.getOrNull()
}

private fun buildFonts(ctx: Context): List<Pair<String, FontFamily>> {
    val out = mutableListOf<Pair<String, FontFamily>>("Monospace" to FontFamily.Monospace)
    loadAssetFamily(ctx, "JetBrainsMono-Regular.ttf")?.let { out += "JetBrains Mono" to it }
    loadAssetFamily(ctx, "FiraCode-Regular.ttf")?.let { out += "Fira Code" to it }
    return out
}

// ============================================================ utilitários de edição
private const val TAB_W = 4
private const val TAB_SPACES = "    "
private const val FOLD_MARK = " ⋯"
private val WARN_COLOR = Color(0xFFE5C07B)

/**
 * O texto guarda '\t' de verdade e pode ter blocos dobrados, mas o Compose mostra o texto como está.
 * Na tela cada '\t' vira 4 colunas e cada bloco dobrado vira " ⋯" (VisualTransformation). Esta classe
 * lista essas "edições" e converte offsets entre o texto real e o texto exibido.
 */
private class DisplayMap(text: String, val hidden: List<IntRange> = emptyList()) {
    val os: IntArray; val ol: IntArray; val vl: IntArray; val isTab: BooleanArray
    private val delta: IntArray; private val vs: IntArray
    val tabPos: IntArray
    init {
        val a = ArrayList<IntArray>()
        var i = 0; var h = 0
        while (i < text.length) {
            while (h < hidden.size && hidden[h].first < i) h++
            if (h < hidden.size && hidden[h].first == i) {
                val len = hidden[h].last + 1 - i
                a += intArrayOf(i, len, FOLD_MARK.length, 0); i += len; h++
                continue
            }
            if (text[i] == '\t') a += intArrayOf(i, 1, TAB_W, 1)
            i++
        }
        val n = a.size
        os = IntArray(n) { a[it][0] }; ol = IntArray(n) { a[it][1] }; vl = IntArray(n) { a[it][2] }
        isTab = BooleanArray(n) { a[it][3] == 1 }
        delta = IntArray(n + 1); vs = IntArray(n)
        for (k in 0 until n) { vs[k] = os[k] + delta[k]; delta[k + 1] = delta[k] + vl[k] - ol[k] }
        tabPos = os.filterIndexed { k, _ -> isTab[k] }.toIntArray()
    }
    val any: Boolean get() = os.isNotEmpty()

    /** offset do texto real -> offset do texto exibido */
    fun vis(o: Int): Int {
        var lo = 0; var hi = os.size
        while (lo < hi) { val m = (lo + hi) ushr 1; if (os[m] + ol[m] <= o) lo = m + 1 else hi = m }
        if (lo < os.size && os[lo] < o) return vs[lo]
        return o + delta[lo]
    }
    /** offset do texto exibido -> offset do texto real */
    fun orig(t: Int): Int {
        var lo = 0; var hi = os.size
        while (lo < hi) { val m = (lo + hi) ushr 1; if (vs[m] < t) lo = m + 1 else hi = m }
        val c = lo
        if (c == 0) return t
        val i = c - 1
        val inside = t - vs[i]
        return if (inside < vl[i]) os[i] + (if (isTab[i] && inside * 2 >= vl[i]) 1 else 0) else t - delta[c]
    }
    /** true se o offset real está escondido dentro de um bloco dobrado */
    fun isHidden(o: Int): Boolean {
        var lo = 0; var hi = os.size
        while (lo < hi) { val m = (lo + hi) ushr 1; if (os[m] + ol[m] <= o) lo = m + 1 else hi = m }
        return lo < os.size && !isTab[lo] && os[lo] < o
    }
    fun inFold(o: Int): Boolean = hidden.any { o >= it.first && o <= it.last + 1 }
}

private fun applyDisplay(a: AnnotatedString, dm: DisplayMap): AnnotatedString = buildAnnotatedString {
    val src = a.text
    var p = 0
    for (i in dm.os.indices) {
        append(src.substring(p, dm.os[i]))
        append(if (dm.isTab[i]) TAB_SPACES else FOLD_MARK)
        p = dm.os[i] + dm.ol[i]
    }
    append(src.substring(p))
    for (r in a.spanStyles) {
        val st = dm.vis(r.start); val en = dm.vis(r.end)
        if (en > st) addStyle(r.item, st, en)
    }
}

/** Blocos que podem ser dobrados: linha do cabeçalho (termina em ':') -> última linha do bloco. */
private fun foldBlocks(text: String): Map<Int, Int> {
    val lines = text.split('\n')
    val ind = IntArray(lines.size) { i ->
        val l = lines[i]
        if (l.isBlank()) -1 else { var n = 0; for (ch in l) { if (ch == ' ') n++ else if (ch == '\t') n += 4 else break }; n }
    }
    val out = HashMap<Int, Int>()
    for (i in lines.indices) {
        if (ind[i] < 0) continue
        if (!lines[i].substringBefore('#').trimEnd().endsWith(":")) continue
        var last = -1; var j = i + 1
        while (j < lines.size) {
            if (ind[j] >= 0) { if (ind[j] <= ind[i]) break; last = j }
            j++
        }
        if (last > i) out[i] = last
    }
    return out
}

private fun lineStarts(text: String): IntArray {
    var n = 1
    for (ch in text) if (ch == '\n') n++
    val out = IntArray(n); var k = 1
    for (i in text.indices) if (text[i] == '\n') out[k++] = i + 1
    return out
}

/** Índice (0-based) da linha que contém o offset. */
private fun lineOf(ls: IntArray, off: Int): Int {
    var lo = 0; var hi = ls.size - 1
    while (lo < hi) { val m = (lo + hi + 1) ushr 1; if (ls[m] <= off) lo = m else hi = m - 1 }
    return lo
}

/** Trechos escondidos: do fim do cabeçalho até o fim da última linha do bloco. */
private fun hiddenRanges(text: String, blocks: Map<Int, Int>, folded: Set<Int>): List<IntRange> {
    if (folded.isEmpty()) return emptyList()
    val ls = lineStarts(text)
    val out = ArrayList<IntRange>()
    var lastEnd = -1
    for (h in folded.sorted()) {
        val last = blocks[h] ?: continue
        val a = if (h + 1 < ls.size) ls[h + 1] - 1 else continue
        val b = if (last + 1 < ls.size) ls[last + 1] - 1 else text.length
        if (a <= lastEnd || b <= a) continue
        out += a until b
        lastEnd = b - 1
    }
    return out
}

private data class Sym(val line: Int, val name: String, val kind: String, val level: Int)
private data class ProjHit(val docId: String, val file: String, val line: Int, val text: String)
private val SEARCH_SKIP = setOf("__pycache__", ".git", ".idea", ".venv", "venv", "node_modules", ".gradle", "build")
private val SEARCH_EXT = listOf(".py", ".txt", ".md", ".json", ".toml", ".cfg", ".ini", ".yml", ".yaml", ".csv")

private fun symbolsOf(text: String): List<Sym> {
    val re = Regex("^([ \\t]*)(async\\s+def|def|class)\\s+([A-Za-z_][A-Za-z0-9_]*)")
    return text.split('\n').mapIndexedNotNull { i, l ->
        re.find(l)?.let { m ->
            Sym(i + 1, m.groupValues[3], if (m.groupValues[2] == "class") "C" else "ƒ",
                m.groupValues[1].fold(0) { acc, ch -> acc + (if (ch == '\t') TAB_W else 1) } / TAB_W)
        }
    }
}

// ---- ANSI no console
private val ANSI_SGR = Regex("\u001B\\[([0-9;]*)m")
private val ANSI_OTHER = Regex("\u001B\\[[0-9;?]*[A-Za-ln-z]")
private val ANSI_ANY = Regex("\u001B\\[[0-9;?]*[A-Za-z]")
private val ANSI_COLORS = listOf(0xFF3B3B3B, 0xFFE06C75, 0xFF98C379, 0xFFE5C07B, 0xFF61AFEF, 0xFFC678DD, 0xFF56B6C2, 0xFFDCDFE4).map { Color(it) }
private val ANSI_BRIGHT = listOf(0xFF7F848E, 0xFFFF7B86, 0xFFB5E890, 0xFFF0D58A, 0xFF82C4FF, 0xFFE09BFF, 0xFF7FD6E0, 0xFFFFFFFF).map { Color(it) }

/** "\r\n" vira "\n"; "\r" solto volta ao começo da linha (barra de progresso); quebras estranhas (\f, \u000B, \u2028/9, \u0085) viram "\n". */
private fun cleanConsole(s: String): String {
    var t = s
    if (t.any { it == '\u000C' || it == '\u000B' || it == '\u2028' || it == '\u2029' || it == '\u0085' })
        t = t.replace('\u000C', '\n').replace('\u000B', '\n').replace('\u2028', '\n').replace('\u2029', '\n').replace('\u0085', '\n')
    if (t.indexOf('\r') < 0) return t
    t = t.replace("\r\n", "\n")
    if (t.indexOf('\r') < 0) return t
    return t.split('\n').joinToString("\n") { it.substringAfterLast('\r') }
}

private fun AnnotatedString.Builder.appendAnsi(raw: String, base: Color) {
    val text = cleanConsole(ANSI_OTHER.replace(raw, ""))
    var color = base; var bold = false; var last = 0
    fun flush(end: Int) {
        if (end > last) withStyle(SpanStyle(color = color, fontWeight = if (bold) FontWeight.Bold else null)) { append(text.substring(last, end)) }
    }
    for (m in ANSI_SGR.findAll(text)) {
        flush(m.range.first)
        for (part in m.groupValues[1].split(';')) {
            when (val c = part.toIntOrNull() ?: 0) {
                0 -> { color = base; bold = false }
                1 -> bold = true
                22 -> bold = false
                39 -> color = base
                in 30..37 -> color = ANSI_COLORS[c - 30]
                in 90..97 -> color = ANSI_BRIGHT[c - 90]
            }
        }
        last = m.range.last + 1
    }
    flush(text.length)
}

/** Troca a indentação feita com espaços por tabs (4 espaços = 1 tab). */
private fun toTabs(text: String): String = text.split("\n").joinToString("\n") { l ->
    val lead = l.takeWhile { it == ' ' || it == '\t' }
    if (lead.isEmpty()) l else {
        val w = lead.fold(0) { acc, ch -> acc + (if (ch == '\t') TAB_W else 1) }
        "\t".repeat(w / TAB_W) + " ".repeat(w % TAB_W) + l.substring(lead.length)
    }
}

private fun mapLines(v: TextFieldValue, f: (List<String>) -> List<String>): TextFieldValue {
    val t = v.text; val sel = v.selection
    val s = t.lastIndexOf('\n', sel.min - 1) + 1
    var e = t.indexOf('\n', sel.max).let { if (it < 0) t.length else it }
    if (!sel.collapsed && sel.max > 0 && t[sel.max - 1] == '\n') e = sel.max - 1
    e = maxOf(e, s)
    val block = t.substring(s, e)
    val nb = f(block.split("\n")).joinToString("\n")
    val nt = t.substring(0, s) + nb + t.substring(e)
    val range = if (sel.collapsed) TextRange((sel.min + nb.length - block.length).coerceIn(s, s + nb.length))
                else TextRange(s, s + nb.length)
    return TextFieldValue(nt, range)
}

private fun lineBlock(v: TextFieldValue): Pair<Int, Int> {
    val t = v.text; val sel = v.selection
    val s = t.lastIndexOf('\n', sel.min - 1) + 1
    var e = t.indexOf('\n', sel.max).let { if (it < 0) t.length else it }
    if (!sel.collapsed && sel.max > 0 && t[sel.max - 1] == '\n') e = sel.max - 1
    return s to maxOf(e, s)
}

/** Fecha pares: ( ) [ ] { } " ' — cursor no meio; digitar o fechamento "pula" por cima; Backspace apaga o par. */
private fun autoPair(old: TextFieldValue, nv: TextFieldValue): TextFieldValue {
    if (!old.selection.collapsed || !nv.selection.collapsed) return nv
    val t = nv.text; val o = old.text; val p = nv.selection.start
    if (t.length == o.length + 1 && p > 0 && t.substring(0, p - 1) == o.substring(0, p - 1)) {
        val ch = t[p - 1]; val nextOld = o.getOrNull(p - 1); val prevOld = o.getOrNull(p - 2)
        val atEdge = nextOld == null || nextOld.isWhitespace() || nextOld in ")]};,:"
        when (ch) {
            '(', '[', '{' -> if (atEdge) {
                val close = when (ch) { '(' -> ')'; '[' -> ']'; else -> '}' }
                return TextFieldValue(t.substring(0, p) + close + t.substring(p), TextRange(p))
            }
            ')', ']', '}' -> if (nextOld == ch) return TextFieldValue(o, TextRange(p))
            '"', '\'' -> {
                if (nextOld == ch) return TextFieldValue(o, TextRange(p))
                if (atEdge && (prevOld == null || !(prevOld.isLetterOrDigit() || prevOld == '\\')))
                    return TextFieldValue(t.substring(0, p) + ch + t.substring(p), TextRange(p))
            }
        }
    }
    if (t.length == o.length - 1) {
        val c = old.selection.start
        if (c in 1 until o.length) {
            val a = o[c - 1]; val b = o[c]
            if ((a == '(' && b == ')') || (a == '[' && b == ']') || (a == '{' && b == '}') || (a == b && (a == '"' || a == '\'')))
                return TextFieldValue(o.removeRange(c - 1, c + 1), TextRange(c - 1))
        }
    }
    return nv
}

/** Enter mantém a indentação (+1 tab após ':' ou abertura de colchete; -1 nível após return/pass/break/continue/raise). */
private fun autoIndent(old: TextFieldValue, nv: TextFieldValue): TextFieldValue {
    val p = nv.selection.start
    if (!old.selection.collapsed || !nv.selection.collapsed || nv.text.length != old.text.length + 1) return nv
    if (p <= 0 || nv.text[p - 1] != '\n') return nv
    val t = nv.text
    val ls = t.lastIndexOf('\n', p - 2) + 1
    val prev = t.substring(ls, p - 1)
    var ind = prev.takeWhile { it == ' ' || it == '\t' }
    val trimmed = prev.trimEnd()
    val body = trimmed.trimStart()
    val opens = trimmed.isNotEmpty() && (trimmed.last() in "{([:" )
    var extra = if (opens) "\t" else ""
    if (!opens && ind.isNotEmpty() && Regex("^(return|pass|break|continue|raise)\\b").containsMatchIn(body))
        ind = if (ind.endsWith("\t")) ind.dropLast(1) else if (ind.length >= 4) ind.dropLast(4) else ind
    if (trimmed.lastOrNull() == '{' && t.getOrNull(p) == '}') {
        val ins = ind + extra + "\n" + ind
        return TextFieldValue(t.substring(0, p) + ins + t.substring(p), TextRange(p + ind.length + extra.length))
    }
    if (ind.isEmpty() && extra.isEmpty()) return nv
    return TextFieldValue(t.substring(0, p) + ind + extra + t.substring(p), TextRange(p + ind.length + extra.length))
}

/** Faixa na linha do problema + sublinhado ondulado no trecho exato (vermelho = erro, amarelo = aviso). */
private fun DrawScope.drawDiagnostics(l: TextLayoutResult, text: String, tm: DisplayMap, diags: List<Diagnostic>, errColor: Color, warnColor: Color, yMin: Float, yMax: Float) {
    val len = text.length
    if (len == 0) return
    val vlen = tm.vis(len)
    for (d in diags) {
        val color = if (d.severity == Severity.WARNING) warnColor else errColor
        var s = d.start.coerceIn(0, len); var e = d.end.coerceIn(0, len)
        if (s >= len) s = len - 1
        if (e <= s) e = (s + 1).coerceAtMost(len)
        val vs = tm.vis(s)
        val ln = l.getLineForOffset(vs)
        if (l.getLineBottom(ln) < yMin || l.getLineTop(ln) > yMax) continue
        val lineEnd = tm.vis(text.indexOf('\n', s).let { if (it < 0) len else it })
        val lastLn = l.getLineForOffset(lineEnd.coerceAtMost(vlen))
        drawRect(color.copy(alpha = 0.12f), Offset(0f, l.getLineTop(ln)), Size(size.width, l.getLineBottom(lastLn) - l.getLineTop(ln)))
        val ce = minOf(tm.vis(e), l.getLineEnd(ln, visibleEnd = true)).coerceAtLeast(vs + 1).coerceAtMost(vlen)
        val b = l.getPathForRange(vs, ce).getBounds()
        val left = b.left; val right = maxOf(b.right, b.left + 8.dp.toPx()); val y = b.bottom - 2.dp.toPx()
        val step = 3.dp.toPx(); val amp = 1.6.dp.toPx()
        val path = Path(); var x = left; var up = true
        path.moveTo(x, y)
        while (x < right) { x = minOf(x + step, right); path.lineTo(x, if (up) y - amp else y); up = !up }
        drawPath(path, color, style = Stroke(width = 1.3.dp.toPx()))
    }
}

/** Nível de indentação (em blocos de 4 espaços) de cada linha; linhas em branco herdam o menor vizinho, como no Godot. */
private fun indentLevels(text: String): IntArray {
    val lines = text.split('\n')
    val raw = IntArray(lines.size) { i ->
        val ln = lines[i]
        if (ln.isBlank()) -1 else {
            var n = 0
            for (ch in ln) { if (ch == ' ') n++ else if (ch == '\t') n += 4 else break }
            n
        }
    }
    val next = IntArray(lines.size)
    var nx = 0
    for (i in lines.indices.reversed()) { if (raw[i] >= 0) nx = raw[i]; next[i] = nx }
    val out = IntArray(lines.size)
    var prev = 0
    for (i in lines.indices) {
        if (raw[i] >= 0) { prev = raw[i]; out[i] = raw[i] / 4 } else out[i] = minOf(prev, next[i]) / 4
    }
    return out
}

/** Guias verticais de indentação (uma por nível: 1 tab ou 4 espaços), atrás do texto. Só desenha a faixa [yMin, yMax]. */
private fun DrawScope.drawIndentGuides(l: TextLayoutResult, text: String, tm: DisplayMap, levels: IntArray, ls: IntArray, color: Color, yMin: Float, yMax: Float) {
    if (text.isEmpty() || levels.isEmpty()) return
    val ref = text.indexOfFirst { !it.isWhitespace() }
    if (ref < 0) return
    val cw = l.getBoundingBox(tm.vis(ref)).width
    if (cw <= 0f) return
    val w = 1.dp.toPx()
    val vl0 = l.getLineForVerticalPosition(yMin.coerceAtLeast(0f))
    val vl1 = l.getLineForVerticalPosition(yMax.coerceAtLeast(0f))
    val first = lineOf(ls, tm.orig(l.getLineStart(vl0)).coerceIn(0, text.length))
    val last = minOf(lineOf(ls, tm.orig(l.getLineEnd(vl1)).coerceIn(0, text.length)), levels.lastIndex, ls.lastIndex)
    for (i in first..last) {
        val start = ls[i]
        val end = if (i + 1 < ls.size) ls[i + 1] - 1 else text.length
        if (tm.isHidden(start)) continue
        val lv = levels[i]
        if (lv > 0) {
            val top = l.getLineTop(l.getLineForOffset(tm.vis(start.coerceAtMost(text.length))))
            val bottom = l.getLineBottom(l.getLineForOffset(tm.vis(end.coerceAtMost(text.length))))
            for (k in 0 until lv) {
                val x = k * TAB_W * cw + w
                drawLine(color, Offset(x, top), Offset(x, bottom), strokeWidth = w)
            }
        }
    }
}

/** Seta "→" fraca em cada tab visível (só nas linhas perto da área visível). */
private fun DrawScope.drawTabMarks(l: TextLayoutResult, tm: DisplayMap, color: Color, yMin: Float, yMax: Float) {
    if (tm.tabPos.isEmpty()) return
    val w = 1.dp.toPx(); val hd = 3.dp.toPx()
    val from = tm.orig(l.getLineStart(l.getLineForVerticalPosition(yMin.coerceAtLeast(0f))))
    var lo = 0; var hi = tm.tabPos.size
    while (lo < hi) { val m = (lo + hi) ushr 1; if (tm.tabPos[m] < from) lo = m + 1 else hi = m }
    for (ti in lo until tm.tabPos.size) {
        val p = tm.tabPos[ti]
        val v = tm.vis(p)
        val ln = l.getLineForOffset(v)
        val top = l.getLineTop(ln)
        if (top < yMin) continue
        if (top > yMax) break
        val r = l.getBoundingBox(v)
        val x0 = r.left + 3.dp.toPx(); val x1 = r.left + r.width * TAB_W - 3.dp.toPx()
        val y = (top + l.getLineBottom(ln)) / 2f
        drawLine(color, Offset(x0, y), Offset(x1, y), strokeWidth = w)
        drawLine(color, Offset(x1 - hd, y - hd), Offset(x1, y), strokeWidth = w)
        drawLine(color, Offset(x1 - hd, y + hd), Offset(x1, y), strokeWidth = w)
    }
}

private const val SAMPLE = "nome = input(\"Qual é o seu nome? \")\nprint(f\"Olá, {nome}!\")\n"

// ============================================================ tela principal
@Composable
fun CodeEditorScreen() {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    val session = remember { SessionStore(ctx) }
    val restored = remember { session.load() }
    val tabs = remember {
        mutableStateListOf<EditorTab>().also { it.addAll(restored?.tabs ?: listOf(EditorTab(0, "main.py", null, SAMPLE))) }
    }
    var cur by remember { mutableIntStateOf(restored?.cur ?: 0) }
    var nextId by remember { mutableIntStateOf(restored?.nextId ?: 1) }
    var confirmClose by remember { mutableStateOf<Int?>(null) }

    // ---- preferências do editor
    val prefs = remember { ctx.getSharedPreferences("editor", Context.MODE_PRIVATE) }
    var themeIdx by remember { mutableIntStateOf(prefs.getInt("theme", 0).coerceIn(0, CodeThemes.all.lastIndex)) }
    val theme = CodeThemes.all[themeIdx]
    val fonts = remember { buildFonts(ctx) }
    var fontIdx by remember { mutableIntStateOf(prefs.getInt("font", 1).coerceIn(0, fonts.lastIndex)) }
    val family = fonts[fontIdx].second
    var fontSize by remember { mutableFloatStateOf(prefs.getFloat("size", 14f).coerceIn(8f, 40f)) }
    var autoSave by remember { mutableStateOf(prefs.getBoolean("autosave", true)) }
    var floatRun by remember { mutableStateOf(prefs.getBoolean("floatRun", false)) }
    var tabMarks by remember { mutableStateOf(prefs.getBoolean("tabMarks", true)) }
    var presetText by remember { mutableStateOf(prefs.getString("presets", "") ?: "") }
    var usePresets by remember { mutableStateOf(prefs.getBoolean("usePresets", false)) }
    var showPresets by remember { mutableStateOf(false) }
    var showSymbols by remember { mutableStateOf(false) }
    var showProjSearch by remember { mutableStateOf(false) }
    var projQuery by remember { mutableStateOf("") }
    var projHits by remember { mutableStateOf<List<ProjHit>>(emptyList()) }
    var projBusy by remember { mutableStateOf(false) }
    var projDone by remember { mutableStateOf(false) }
    var pendingGoto by remember { mutableStateOf<Pair<Uri, Int>?>(null) }
    var guides by remember { mutableStateOf(prefs.getBoolean("guides", true)) }
    var wrap by remember { mutableStateOf(prefs.getBoolean("wrap", true)) }
    var selectMode by remember { mutableStateOf(false) }
    var lastRunId by remember { mutableIntStateOf(-1) }
    LaunchedEffect(fontSize) { delay(400); prefs.edit().putFloat("size", fontSize).apply() }

    val explorer = remember { ProjectExplorerState(ctx) }
    var showSidebar by remember { mutableStateOf(false) }

    var showFind by remember { mutableStateOf(false) }
    var showReplace by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var repl by remember { mutableStateOf("") }
    var useRegex by remember { mutableStateOf(false) }
    var showSnippets by remember { mutableStateOf(false) }
    var snippetName by remember { mutableStateOf("") }
    var snippetTrigger by remember { mutableStateOf("") }
    var snippetBody by remember { mutableStateOf("") }
    var editingSnippetTrigger by remember { mutableStateOf<String?>(null) }
    var showGoto by remember { mutableStateOf(false) }
    var gotoText by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }
    var showShortcutSettings by remember { mutableStateOf(false) }
    var captureShortcutFor by remember { mutableStateOf<String?>(null) }
    var captureShortcutHint by remember { mutableStateOf("Clique no campo e pressione a combinação de teclas desejada.") }
    var customShortcuts by remember { mutableStateOf(CustomShortcutStore.load(ctx)) }
    val shortcutCaptureFocus = remember { FocusRequester() }
    LaunchedEffect(captureShortcutFor) {
        if (captureShortcutFor != null) {
            delay(100)
            runCatching { shortcutCaptureFocus.requestFocus() }
        }
    }
    // Menu de contexto para mouse: coordenadas locais do editor, atualizado no clique direito.
    var showEditorContextMenu by remember { mutableStateOf(false) }
    var editorContextOffset by remember { mutableStateOf(Offset.Zero) }
    var showConsole by remember { mutableStateOf(false) }
    var showGithubImport by remember { mutableStateOf(false) }
    var githubUrl by remember { mutableStateOf("https://github.com/") }
    var githubBusy by remember { mutableStateOf(false) }
    var showPackages by remember { mutableStateOf(false) }
    var packageName by remember { mutableStateOf("") }
    var showProjectRunDialog by remember { mutableStateOf(false) }
    var projectScriptChoices by remember { mutableStateOf<List<TermuxProjectScript>>(emptyList()) }
    var projectScriptsLoading by remember { mutableStateOf(false) }
    var importedProjectRoot by remember { mutableStateOf<File?>(null) }
    val importedProjectTabPaths = remember { mutableStateMapOf<Int, String>() }
    var showTermuxDiagnostics by remember { mutableStateOf(false) }
    var showX11Settings by remember { mutableStateOf(false) }
    var x11ResolutionMode by remember { mutableStateOf(prefs.getString("x11_resolution_mode", "native") ?: "native") }
    var x11ResolutionExact by remember { mutableStateOf(prefs.getString("x11_resolution_exact", "1280x720") ?: "1280x720") }
    var x11Scale by remember { mutableIntStateOf(prefs.getInt("x11_scale", 100).coerceIn(30, 300)) }
    var x11AdjustResolution by remember { mutableStateOf(prefs.getBoolean("x11_adjust_resolution", true)) }
    var x11ResolutionOrientation by remember { mutableStateOf(prefs.getString("x11_resolution_orientation", "auto") ?: "auto") }
    var x11TouchMode by remember { mutableStateOf(prefs.getString("x11_touch_mode", "Trackpad") ?: "Trackpad") }
    var x11Pip by remember { mutableStateOf(prefs.getBoolean("x11_pip", false)) }
    var x11Fullscreen by remember { mutableStateOf(prefs.getBoolean("x11_fullscreen", true)) }
    var consoleBig by remember { mutableStateOf(false) }
    var editorFocused by remember { mutableStateOf(false) }
    var showAllDiags by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    val snippetStore = remember(ctx) { SnippetStore(ctx) }
    val snippets = remember { mutableStateListOf<UserCodeSnippet>().also { it.addAll(snippetStore.load()) } }
    fun persistSnippets() = snippetStore.save(snippets.toList())
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    fun current() = tabs[cur.coerceIn(0, tabs.lastIndex)]
    val tab = current()
    val text = tab.value.text

    val runState by PyRunner.state.collectAsState()
    val dbgPause by PyRunner.pause.collectAsState()
    val termuxDiagnosticReport by PyRunner.termuxDiagnostics.collectAsState()
    val running = runState != RunState.IDLE

    // ---------- Fechar abas
    fun removeTab(i: Int) {
        if (tabs.size <= 1 || i !in tabs.indices) return
        val active = cur.coerceIn(0, tabs.lastIndex)
        tabs.removeAt(i)
        cur = when { i < active -> active - 1; i == active -> minOf(active, tabs.lastIndex); else -> active }
    }
    fun requestClose(i: Int) {
        val t = tabs.getOrNull(i) ?: return
        if (t.dirty) confirmClose = t.id else removeTab(i)
    }
    fun addNewTab() { tabs.add(EditorTab(nextId, "novo$nextId.py")); nextId++; cur = tabs.lastIndex }

    // ---------- Arquivos (SAF)
    fun writeTo(t: EditorTab, uri: Uri, quiet: Boolean = false): Boolean =
        if (ProjectFs.writeText(ctx, uri, t.value.text)) { t.dirty = false; if (!quiet) toast("Salvo: ${t.name}"); true }
        else { toast("Erro ao salvar ${t.name}"); false }

    fun saveAll() {
        val dirty = tabs.filter { it.dirty }
        val withUri = dirty.filter { it.uri != null }
        val ok = withUri.count { writeTo(it, it.uri!!, true) }
        val skipped = dirty.size - withUri.size
        toast(if (dirty.isEmpty()) "Nada para salvar" else "Salvos: $ok" + if (skipped > 0) " · $skipped sem arquivo (use Salvar como)" else "")
    }

    fun openProjectFileAt(e: DocEntry, line: Int) {
        val t = explorer.treeUri ?: return
        val uri = ProjectFs.docUri(t, e.id)
        if (line > 0) pendingGoto = uri to line
        val existing = tabs.indexOfFirst { it.uri == uri }
        if (existing >= 0) { cur = existing; if (!wide) showSidebar = false; return }
        scope.launch {
            val txt = withContext(Dispatchers.IO) { ProjectFs.readText(ctx, uri) }
            if (txt == null) toast("Não abri (binário ou maior que 2 MB): ${e.name}")
            else { tabs.add(EditorTab(nextId++, e.name, uri, txt)); cur = tabs.lastIndex; if (!wide) showSidebar = false }
        }
    }

    fun openProjectFile(e: DocEntry) = openProjectFileAt(e, 0)

    fun onDocChanged(oldId: String, newId: String?) {
        val t = explorer.treeUri ?: return
        tabs.forEach { tb ->
            val u = tb.uri ?: return@forEach
            val nu = ProjectFs.remap(u, t, oldId, newId)
            if (nu == null) { tb.uri = null; tb.dirty = true }
            else if (nu != u) { tb.uri = nu; tb.name = displayName(ctx, nu) }
        }
    }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            val txt = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            tabs.add(EditorTab(nextId++, displayName(ctx, uri), uri, txt)); cur = tabs.lastIndex
        }.onFailure { toast("Erro ao abrir: ${it.message}") }
    }
    val saveAsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-python")) { uri ->
        if (uri != null) { val t = current(); t.uri = uri; t.name = displayName(ctx, uri); writeTo(t, uri) }
    }
    val treeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            val rootId = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrNull()
            if (rootId == null) toast("Pasta inválida")
            else {
                val nm = displayNameOrNull(ctx, DocumentsContract.buildDocumentUriUsingTree(uri, rootId)) ?: rootId.substringAfterLast('/').ifEmpty { "Projeto" }
                importedProjectRoot = null
                importedProjectTabPaths.clear()
                explorer.setRoot(uri, nm); showSidebar = true
            }
        }
    }

    val bridgeTreeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            TermuxWorkspace.saveBridge(ctx, uri).onSuccess { loc ->
                toast("Pasta-ponte configurada: ${loc.path}. No Termux, execute termux-setup-storage.")
            }.onFailure { toast("Pasta incompatível: ${it.message}") }
        }
    }

    val exportSnippetsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) runCatching {
            val json = SnippetStore.encode(snippets.toList())
            ctx.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(json) }
                ?: error("Não foi possível gravar o arquivo escolhido.")
        }.onSuccess { toast("Snippets exportados (${snippets.size}).") }
            .onFailure { toast("Falha ao exportar snippets: ${it.message}") }
    }
    val importSnippetsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val raw = ctx.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: error("Não foi possível ler o arquivo escolhido.")
            SnippetStore.decode(raw)
        }.onSuccess { imported ->
            val merged = LinkedHashMap(snippets.associateBy { it.trigger })
            imported.forEach { merged[it.trigger] = it }
            snippets.clear(); snippets.addAll(merged.values)
            persistSnippets()
            toast("Importados ${imported.size} snippets. Atalhos iguais foram atualizados.")
        }.onFailure { toast("Falha ao importar snippets: ${it.message}") }
    }

    // ---------- Edição
    fun edit(f: (TextFieldValue) -> TextFieldValue) { val t = current(); t.change(f(t.value)) }
    fun insert(s: String) = edit { v ->
        TextFieldValue(v.text.substring(0, v.selection.min) + s + v.text.substring(v.selection.max), TextRange(v.selection.min + s.length))
    }
    fun insertWithBack(
        s: String, back: Int, selectionStartBack: Int? = null, selectionEndBack: Int? = null
    ) = edit { v ->
        val a = v.selection.min; val b = v.selection.max
        if (s.length == 2 && back == 1 && a != b) {
            val sel = v.text.substring(a, b)
            TextFieldValue(v.text.substring(0, a) + s[0] + sel + s[1] + v.text.substring(b), TextRange(a + sel.length + 2))
        } else {
            val combined = v.text.substring(0, a) + s + v.text.substring(b)
            val start = selectionStartBack?.let { a + s.length - it }
            val end = selectionEndBack?.let { a + s.length - it }
            val target = if (start != null && end != null) TextRange(start, end) else TextRange(a + s.length - back)
            TextFieldValue(combined, target)
        }
    }
    fun applySuggestion(prefixLen: Int, suggestion: Suggestion) = edit { v ->
        val c = v.selection.start; val st = (c - prefixLen).coerceAtLeast(0)
        var s = suggestion.insert; var bk = suggestion.cursorBack
        if (s.endsWith("()") && v.text.getOrNull(c) == '(') { s = s.dropLast(2); bk = 0 }
        val combined = v.text.substring(0, st) + s + v.text.substring(c)
        val selectionStart = suggestion.selectionStartBack?.let { st + s.length - it }
        val selectionEnd = suggestion.selectionEndBack?.let { st + s.length - it }
        val target = if (selectionStart != null && selectionEnd != null) TextRange(selectionStart, selectionEnd)
            else TextRange(st + s.length - bk)
        TextFieldValue(combined, target)
    }
    fun selectedOrAll(): String { val v = current().value; return if (v.selection.collapsed) v.text else v.text.substring(v.selection.min, v.selection.max) }

    fun doToggleComment() = edit { v -> mapLines(v) { ls ->
        val nonBlank = ls.filter { it.isNotBlank() }
        val all = nonBlank.isNotEmpty() && nonBlank.all { it.trimStart().startsWith("#") }
        ls.map { l ->
            val ind = l.takeWhile { it == ' ' || it == '\t' }; val body = l.trimStart()
            when { l.isBlank() -> l; all -> ind + body.removePrefix("#").removePrefix(" "); else -> "$ind# $body" }
        }
    } }

    fun runTab(t: EditorTab) {
        if (PyRunner.state.value != RunState.IDLE) { toast("Já existe um script em execução"); return }
        showConsole = true
        lastRunId = t.id
        val localRoot = importedProjectRoot?.takeIf { importedProjectTabPaths.containsKey(t.id) }
        val tree = if (localRoot == null) explorer.treeUri else null
        val rootId = if (localRoot == null) explorer.rootId else null
        val mainId = if (localRoot == null) t.uri?.let { runCatching { DocumentsContract.getDocumentId(it) }.getOrNull() } else null
        val openDocuments = LinkedHashMap<String, String>()
        val localOpenDocuments = LinkedHashMap<String, String>()
        val looseFiles = LinkedHashMap<String, String>()
        val dirtyDocuments = linkedSetOf<String>()
        tabs.forEach { opened ->
            val localRelative = if (localRoot != null) importedProjectTabPaths[opened.id] else null
            if (localRelative != null) {
                localOpenDocuments[localRelative] = opened.value.text
            } else if (localRoot == null) {
                val id = opened.uri?.let { runCatching { DocumentsContract.getDocumentId(it) }.getOrNull() }
                if (id != null) {
                    openDocuments[id] = opened.value.text
                    if (opened.dirty) dirtyDocuments += id
                    val relative = if (rootId != null) TermuxWorkspace.relativePath(rootId, id) else null
                    if (relative == null && opened !== t) looseFiles[opened.name] = opened.value.text
                } else if (opened !== t) {
                    looseFiles[opened.name] = opened.value.text
                }
            }
        }
        val projectInput = TermuxProjectInput(
            treeUri = tree,
            rootId = rootId,
            mainDocumentId = mainId,
            openDocuments = openDocuments,
            looseFiles = looseFiles,
            dirtyDocuments = dirtyDocuments,
            localProjectRoot = localRoot?.absolutePath,
            mainRelativePath = localRoot?.let { importedProjectTabPaths[t.id] },
            localOpenDocuments = localOpenDocuments,
        )
        val siblings = tabs.filter { it !== t && it.name.endsWith(".py", true) }.associate { it.name to it.value.text }
        PyRunner.run(
            ctx, t.value.text, t.name, siblings,
            breakpoints = t.breakpoints.map { it + 1 }.sorted(),
            presets = if (usePresets) presetText.trimEnd('\n', '\r') else "",
            externalProject = projectInput
        )
    }
    fun chooseProjectMain() {
        val localRoot = importedProjectRoot
        val tree = explorer.treeUri
        val root = explorer.rootId
        if (localRoot == null && (tree == null || root == null)) {
            toast("Abra uma pasta do projeto pelo explorador ou importe um repositório GitHub antes de escolher o arquivo principal.")
            return
        }
        showProjectRunDialog = true
        projectScriptsLoading = true
        projectScriptChoices = emptyList()
        scope.launch {
            val choices = withContext(Dispatchers.IO) {
                if (localRoot != null) TermuxWorkspace.listPythonScripts(localRoot)
                else TermuxWorkspace.listPythonScripts(ctx, tree!!, root!!)
            }
            projectScriptChoices = choices
            projectScriptsLoading = false
        }
    }

    fun runProjectScript(choice: TermuxProjectScript) {
        showProjectRunDialog = false
        val localFile = choice.localFile
        if (localFile != null) {
            val existingId = importedProjectTabPaths.entries.firstOrNull { it.value == choice.relativePath }?.key
            val existing = if (existingId != null) tabs.indexOfFirst { it.id == existingId } else -1
            if (existing >= 0) {
                cur = existing
                runTab(tabs[existing])
                return
            }
            scope.launch {
                val source = withContext(Dispatchers.IO) { runCatching { localFile.readText(Charsets.UTF_8) }.getOrNull() }
                if (source == null) {
                    toast("Não consegui abrir ${choice.relativePath}.")
                } else {
                    val selected = EditorTab(nextId++, localFile.name, null, source)
                    tabs.add(selected)
                    importedProjectTabPaths[selected.id] = choice.relativePath
                    cur = tabs.lastIndex
                    if (!wide) showSidebar = false
                    runTab(selected)
                }
            }
            return
        }
        val tree = explorer.treeUri ?: return
        val entry = choice.entry ?: return
        val uri = ProjectFs.docUri(tree, entry.id)
        val existing = tabs.indexOfFirst { it.uri == uri }
        if (existing >= 0) {
            cur = existing
            runTab(tabs[existing])
            return
        }
        scope.launch {
            val source = withContext(Dispatchers.IO) { ProjectFs.readText(ctx, uri) }
            if (source == null) {
                toast("Não consegui abrir ${choice.relativePath}; pode ser binário ou maior que 2 MB.")
            } else {
                val selected = EditorTab(nextId++, entry.name, uri, source)
                tabs.add(selected)
                cur = tabs.lastIndex
                if (!wide) showSidebar = false
                runTab(selected)
            }
        }
    }

    fun doRun() = runTab(current())
    /** Roda de novo o último arquivo executado (com o texto atual dele). */
    fun doRerun() = runTab(tabs.firstOrNull { it.id == lastRunId } ?: current())
    fun doStop() = PyRunner.stop()

    fun doDuplicate() {
        val t = current(); val v = t.value; val txt = v.text
        if (!v.selection.collapsed) {
            val sel = txt.substring(v.selection.min, v.selection.max)
            t.change(TextFieldValue(txt.substring(0, v.selection.max) + sel + txt.substring(v.selection.max), TextRange(v.selection.max, v.selection.max + sel.length)))
            return
        }
        val (s, e) = lineBlock(v); val line = txt.substring(s, e)
        t.change(TextFieldValue(txt.substring(0, e) + "\n" + line + txt.substring(e), TextRange(v.selection.min + line.length + 1)))
    }

    fun doMoveLine(up: Boolean) {
        val t = current(); val v = t.value; val txt = v.text
        val (s, e) = lineBlock(v); val block = txt.substring(s, e)
        if (up) {
            if (s == 0) return
            val ps = txt.lastIndexOf('\n', s - 2) + 1; val prev = txt.substring(ps, s - 1); val d = prev.length + 1
            t.change(TextFieldValue(txt.substring(0, ps) + block + "\n" + prev + txt.substring(e), TextRange(v.selection.start - d, v.selection.end - d)))
        } else {
            if (e >= txt.length) return
            val ne = txt.indexOf('\n', e + 1).let { if (it < 0) txt.length else it }
            val next = txt.substring(e + 1, ne); val d = next.length + 1
            t.change(TextFieldValue(txt.substring(0, s) + next + "\n" + block + txt.substring(ne), TextRange(v.selection.start + d, v.selection.end + d)))
        }
    }

    fun doDeleteLine() {
        val t = current(); val v = t.value; val txt = v.text
        val (s, e) = lineBlock(v)
        val (a, b) = when { e < txt.length -> s to e + 1; s > 0 -> (s - 1) to e; else -> s to e }
        t.change(TextFieldValue(txt.removeRange(a, b), TextRange(a)))
    }

    fun doSelectAll() { val t = current(); t.value = t.value.copy(selection = TextRange(0, t.value.text.length)) }
    /** Apagar: remove a seleção; sem seleção, remove a linha do cursor. */
    fun doDelete() { if (current().value.selection.collapsed) doDeleteLine() else insert("") }
    fun doToTabs() = edit { v ->
        val nt = toTabs(v.text)
        TextFieldValue(nt, TextRange(v.selection.start.coerceAtMost(nt.length), v.selection.end.coerceAtMost(nt.length)))
    }

    fun doSelectLine() {
        val t = current(); val v = t.value; val (s, e) = lineBlock(v)
        t.value = v.copy(selection = TextRange(s, minOf(e + 1, v.text.length)))
    }

    fun gotoOffset(off: Int) { val t = current(); t.folded = emptySet(); t.value = t.value.copy(selection = TextRange(off.coerceIn(0, t.value.text.length))); runCatching { focus.requestFocus() } }

    fun gotoLine(n: Int) {
        val txt = current().value.text
        var off = 0; var line = 1
        while (line < n) { val i = txt.indexOf('\n', off); if (i < 0) break; off = i + 1; line++ }
        gotoOffset(off)
    }

    fun regexOf() = if (useRegex) Regex(query) else Regex(Regex.escape(query))
    fun doFindNext() {
        if (query.isEmpty()) return
        val t = current(); val txt = t.value.text
        runCatching {
            val p = regexOf()
            val m = p.find(txt, t.value.selection.max.coerceAtMost(txt.length)) ?: p.find(txt, 0)
            if (m != null) { t.value = t.value.copy(selection = TextRange(m.range.first, m.range.last + 1)); runCatching { focus.requestFocus() } }
            else toast("Não encontrado")
        }.onFailure { toast("Regex inválida") }
    }
    fun replaceOne() {
        val v = current().value
        if (v.selection.collapsed) { doFindNext(); return }
        runCatching {
            val p = regexOf()
            val sel = v.text.substring(v.selection.min, v.selection.max)
            if (p.matches(sel)) insert(p.replaceFirst(sel, if (useRegex) repl else Regex.escapeReplacement(repl)))
            doFindNext()
        }.onFailure { toast("Regex inválida") }
    }
    fun replaceAll() {
        if (query.isEmpty()) return
        runCatching {
            val p = regexOf()
            edit { v -> TextFieldValue(p.replace(v.text, if (useRegex) repl else Regex.escapeReplacement(repl)), TextRange(0)) }
        }.onFailure { toast("Regex inválida") }
    }

    fun formatCode() {
        val t = current()
        val o = t.value.text.lines().joinToString("\n") { it.trimEnd() }.let { if (it.endsWith("\n")) it else it + "\n" }
        t.change(TextFieldValue(o, TextRange(minOf(t.value.selection.start, o.length))))
    }

    fun applyFix(f: QuickFix) {
        val t = current(); val s = t.value.text
        val a = f.start.coerceIn(0, s.length); val b = f.end.coerceIn(a, s.length)
        t.change(TextFieldValue(s.replaceRange(a, b, f.replacement), TextRange(a + f.replacement.length)))
        runCatching { focus.requestFocus() }
    }

    LaunchedEffect(pendingGoto, cur, tabs.size) {
        val pg = pendingGoto
        if (pg != null && tabs.getOrNull(cur)?.uri == pg.first) { gotoLine(pg.second); pendingGoto = null }
    }
    LaunchedEffect(Incoming.uris.size) {
        while (Incoming.uris.isNotEmpty()) {
            val u = Incoming.uris.removeAt(0)
            val existing = tabs.indexOfFirst { it.uri == u }
            if (existing >= 0) { cur = existing; continue }
            val txt = withContext(Dispatchers.IO) { ProjectFs.readText(ctx, u) }
            if (txt == null) toast("Não consegui abrir o arquivo")
            else { tabs.add(EditorTab(nextId++, displayName(ctx, u), u, txt)); cur = tabs.lastIndex }
        }
    }
    LaunchedEffect(dbgPause?.line) {
        val ps = dbgPause ?: return@LaunchedEffect
        val t = tabs.firstOrNull { it.name == ps.fileName } ?: return@LaunchedEffect
        val off = lineStarts(t.value.text).getOrNull(ps.line - 1) ?: return@LaunchedEffect
        t.folded = emptySet(); cur = tabs.indexOf(t)
        t.value = t.value.copy(selection = TextRange(off))
    }
    fun doShare() {
        val t = current()
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, selectedOrAll()); putExtra(Intent.EXTRA_SUBJECT, t.name)
        }
        runCatching { ctx.startActivity(Intent.createChooser(send, "Compartilhar ${t.name}").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    fun runProjSearch() {
        val tree = explorer.treeUri; val root = explorer.rootId
        if (tree == null || root == null) { toast("Abra uma pasta de projeto primeiro"); return }
        val q = projQuery.trim()
        if (q.isEmpty()) return
        projBusy = true; projDone = false; projHits = emptyList()
        scope.launch {
            val hits = withContext(Dispatchers.IO) {
                val out = ArrayList<ProjHit>()
                val stack = ArrayDeque<Pair<String, String>>()
                stack.add(root to "")
                var files = 0
                while (stack.isNotEmpty() && out.size < 300 && files < 400) {
                    val (dir, prefix) = stack.removeFirst()
                    for (e in ProjectFs.list(ctx, tree, dir)) {
                        if (e.isDir) { if (e.name !in SEARCH_SKIP) stack.add(e.id to "$prefix${e.name}/") }
                        else if (SEARCH_EXT.any { e.name.endsWith(it) }) {
                            files++
                            val txt = ProjectFs.readText(ctx, ProjectFs.docUri(tree, e.id)) ?: continue
                            txt.split('\n').forEachIndexed { i, l ->
                                if (out.size < 300 && l.contains(q, ignoreCase = true)) out += ProjHit(e.id, prefix + e.name, i + 1, l.trim().take(120))
                            }
                        }
                    }
                }
                out
            }
            projHits = hits; projBusy = false; projDone = true
        }
    }

    // sugestões de sintaxe visíveis (Alt+1..9) e ponte para o movimento de cursor definido mais abaixo
    var sugList by remember { mutableStateOf(emptyList<Suggestion>()) }
    var sugPrefixLen by remember { mutableStateOf(0) }
    val keyMover = remember { arrayOfNulls<(Int, Int, Boolean, Boolean) -> Unit>(1) }
    val actions = remember {
        object : EditorActions {
            override fun moveCursorKey(dx: Int, dy: Int, extend: Boolean, word: Boolean) { keyMover[0]?.invoke(dx, dy, extend, word) }
            override fun pickSuggestion(n: Int): Boolean {
                val sg = sugList.getOrNull(n - 1) ?: return false
                applySuggestion(sugPrefixLen, sg)
                sugList = emptyList()
                return true
            }
            override fun save() { val t = current(); val u = t.uri; if (u != null) writeTo(t, u) else saveAsLauncher.launch(t.name) }
            override fun saveAs() { saveAsLauncher.launch(current().name) }
            override fun openFile() { openLauncher.launch(arrayOf("*/*")) }
            override fun newTab() = addNewTab()
            override fun closeTab() = requestClose(cur.coerceIn(0, tabs.lastIndex))
            override fun switchTab(delta: Int) { cur = (cur.coerceIn(0, tabs.lastIndex) + delta + tabs.size) % tabs.size }
            override fun runCode() = doRun()
            override fun stopCode() = doStop()
            override fun undo() = current().undo()
            override fun redo() = current().redo()
            override fun copy() {
                val v = current().value
                if (v.selection.collapsed) {
                    val s = v.text.lastIndexOf('\n', v.selection.min - 1) + 1
                    val e = v.text.indexOf('\n', v.selection.min).let { if (it < 0) v.text.length else it }
                    clipboard.setText(AnnotatedString(v.text.substring(s, e)))
                } else clipboard.setText(AnnotatedString(selectedOrAll()))
            }
            override fun paste() { clipboard.getText()?.text?.let { insert(it) } }
            override fun cut() {
                if (current().value.selection.collapsed) { copy(); doDeleteLine() }
                else { clipboard.setText(AnnotatedString(selectedOrAll())); insert("") }
            }
            override fun find() { showFind = true; showReplace = false }
            override fun replace() { showFind = true; showReplace = true }
            override fun findNext() = doFindNext()
            override fun toggleComment() = doToggleComment()
            override fun indent() { if (current().value.selection.collapsed) insert("\t") else edit { v -> mapLines(v) { l -> l.map { "\t$it" } } } }
            override fun outdent() = edit { v -> mapLines(v) { l -> l.map { it.replaceFirst(Regex("^( {1,4}|\t)"), "") } } }
            override fun duplicateLine() = doDuplicate()
            override fun moveLine(up: Boolean) = doMoveLine(up)
            override fun deleteLine() = doDeleteLine()
            override fun selectLine() = doSelectLine()
            override fun goToLine() { showGoto = true }
            override fun format() = formatCode()
            override fun toggleSidebar() { showSidebar = !showSidebar }
            override fun escape(): Boolean = when {
                showFind -> { showFind = false; true }
                showSidebar -> { showSidebar = false; true }
                showConsole && PyRunner.state.value == RunState.IDLE -> { showConsole = false; true }
                else -> false
            }
        }
    }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val blocks = remember(text) { foldBlocks(text) }
    val hidden = remember(text, tab.folded) { hiddenRanges(text, blocks, tab.folded) }
    val tm = remember(text, hidden) { DisplayMap(text, hidden) }
    val lineStartsArr = remember(text) { lineStarts(text) }

    fun performShortcutAction(id: String) {
        when (id) {
            "run" -> actions.runCode()
            "stop" -> actions.stopCode()
            "runProjectMain" -> chooseProjectMain()
            "save" -> actions.save()
            "saveAs" -> actions.saveAs()
            "saveAll" -> saveAll()
            "openFile" -> actions.openFile()
            "newTab" -> actions.newTab()
            "closeTab" -> actions.closeTab()
            "nextTab" -> actions.switchTab(1)
            "previousTab" -> actions.switchTab(-1)
            "undo" -> actions.undo()
            "redo" -> actions.redo()
            "copy" -> actions.copy()
            "cut" -> actions.cut()
            "paste" -> actions.paste()
            "selectLine" -> actions.selectLine()
            "selectAll" -> doSelectAll()
            "deleteLine" -> actions.deleteLine()
            "duplicateLine" -> actions.duplicateLine()
            "moveLineUp" -> actions.moveLine(true)
            "moveLineDown" -> actions.moveLine(false)
            "indent" -> actions.indent()
            "outdent" -> actions.outdent()
            "toggleComment" -> actions.toggleComment()
            "format" -> actions.format()
            "convertTabs" -> doToTabs()
            "find" -> actions.find()
            "replace" -> actions.replace()
            "findNext" -> actions.findNext()
            "goToLine" -> actions.goToLine()
            "toggleSidebar" -> actions.toggleSidebar()
            "toggleConsole" -> showConsole = !showConsole
            "toggleSnippets" -> showSnippets = true
            "togglePresets" -> showPresets = true
            "showSymbols" -> showSymbols = true
            "searchProject" -> showProjSearch = true
            "importGitHub" -> showGithubImport = true
            "installPackage" -> showPackages = true
            "termuxDiagnostics" -> { showTermuxDiagnostics = true; PyRunner.diagnoseTermux(ctx) }
            "showX11Settings" -> showX11Settings = true
            "setupSharedFolder" -> bridgeTreeLauncher.launch(null)
            "openTermuxX11" -> TermuxX11Runner.openX11(ctx).onFailure { toast(it.message ?: "Não consegui abrir Termux:X11") }
            "openTermuxX11Split" -> TermuxX11Runner.openX11(ctx, launchAdjacent = true).onFailure { toast(it.message ?: "Não consegui abrir Termux:X11") }
            "toggleTabMarks" -> { tabMarks = !tabMarks; prefs.edit().putBoolean("tabMarks", tabMarks).apply() }
            "toggleGuides" -> { guides = !guides; prefs.edit().putBoolean("guides", guides).apply() }
            "toggleWrap" -> { wrap = !wrap; prefs.edit().putBoolean("wrap", wrap).apply() }
            "toggleFloatRun" -> { floatRun = !floatRun; prefs.edit().putBoolean("floatRun", floatRun).apply() }
            "increaseFont" -> { fontSize = (fontSize + 1f).coerceAtMost(40f); prefs.edit().putFloat("size", fontSize).apply() }
            "decreaseFont" -> { fontSize = (fontSize - 1f).coerceAtLeast(8f); prefs.edit().putFloat("size", fontSize).apply() }
            "toggleAutoSave" -> { autoSave = !autoSave; prefs.edit().putBoolean("autosave", autoSave).apply() }
            "foldAll" -> current().folded = foldBlocks(current().value.text).keys.toSet()
            "unfoldAll" -> current().folded = emptySet()
            "toggleBreakpoint" -> {
                val t = current()
                val line = (lineStarts(t.value.text).indexOfLast { it <= t.value.selection.start }).coerceAtLeast(0)
                t.breakpoints = if (line in t.breakpoints) t.breakpoints - line else t.breakpoints + line
            }
            "clearBreakpoints" -> current().breakpoints = emptySet()
            "debugContinue" -> PyRunner.debugContinue()
            "debugStep" -> PyRunner.debugStep()
            "clearConsole" -> PyRunner.clearConsole()
            "toggleTerminalMode" -> PyRunner.setRepl(!PyRunner.replMode.value)
            "restartTerminal" -> PyRunner.resetRepl()
            "sendEOF" -> PyRunner.sendEof()
            "share" -> doShare()
            "nextTheme" -> { themeIdx = (themeIdx + 1) % CodeThemes.all.size; prefs.edit().putInt("theme", themeIdx).apply() }
            "nextFont" -> { fontIdx = (fontIdx + 1) % fonts.size; prefs.edit().putInt("font", fontIdx).apply() }
        }
    }

    fun commitCustomShortcut(actionId: String, keyCode: Int, ctrl: Boolean, alt: Boolean, shift: Boolean, meta: Boolean) {
        val binding = CustomShortcutBinding(actionId, keyCode, ctrl, alt, shift, meta)
        val next = customShortcuts.filterNot { it.actionId == actionId || it.matches(keyCode, ctrl, alt, shift, meta) } + binding
        customShortcuts = next
        CustomShortcutStore.save(ctx, next)
        captureShortcutFor = null
        toast("Atalho salvo: ${binding.display()}")
    }

    val keys = remember(actions) {
        KeyBindingHandler(actions, customBindings = { customShortcuts }, runCustomAction = { performShortcutAction(it) })
    }
    // auto-completar de membros (depois do ponto): pergunta ao Python, com um pequeno atraso para não pesar a digitação
    var members by remember { mutableStateOf<Triple<Int, Int, List<MemberSug>>?>(null) }
    val mq = remember(text, tab.value.selection.start) { PySymbols.memberQuery(text, tab.value.selection.start) }
    LaunchedEffect(text, tab.value.selection.start) {
        val q = PySymbols.memberQuery(text, tab.value.selection.start)
        if (q == null) { members = null; return@LaunchedEffect }
        delay(150)
        val res = withContext(Dispatchers.Default) { PyRunner.complete(text, q.line, q.col) }
        members = Triple(q.line, q.col, res ?: emptyList())
    }
    val memberList = members?.takeIf { mq != null && it.first == mq.line && it.second == mq.col }?.third ?: emptyList()
    fun moveCursor(dx: Int, dy: Int) {
        val t = current(); val v = t.value
        val pos = if (selectMode) v.selection.end else v.selection.max
        val l = layout
        val np = if (dy == 0) (pos + dx).coerceIn(0, v.text.length) else l?.let {
            val vp = tm.vis(pos)
            val ln = (it.getLineForOffset(vp) + dy).coerceIn(0, it.lineCount - 1)
            tm.orig(it.getOffsetForPosition(Offset(it.getHorizontalPosition(vp, true), (it.getLineTop(ln) + it.getLineBottom(ln)) / 2)))
        } ?: pos
        t.value = v.copy(selection = if (selectMode) TextRange(v.selection.start, np) else TextRange(np))
    }

    // Setas do teclado físico. O BasicTextField anda no texto EXIBIDO (tab = 4 colunas, bloco dobrado = " ⋯"), então a seta
    // "emperrava" em tabs e dobras. Aqui o movimento é feito nos offsets reais e a coluna é mantida ao subir/descer.
    var goalX by remember { mutableStateOf<Float?>(null) }
    var goalPos by remember { mutableStateOf(-1) }
    fun moveCursorKey(dx: Int, dy: Int, extend: Boolean, word: Boolean) {
        val t = current(); val v = t.value; val txt = v.text; val n = txt.length
        val sel = v.selection
        val anchor = sel.start; val pos = sel.end.coerceIn(0, n)
        if (!extend && !sel.collapsed && dy == 0 && !word) {
            goalX = null
            t.value = v.copy(selection = TextRange(if (dx < 0) sel.min else sel.max)); return
        }
        val np: Int
        if (dy == 0) {
            goalX = null
            fun isW(c: Char) = c.isLetterOrDigit() || c == '_'
            var p = pos
            if (word) {
                if (dx > 0) { while (p < n && !isW(txt[p])) p++; while (p < n && isW(txt[p])) p++ }
                else { while (p > 0 && !isW(txt[p - 1])) p--; while (p > 0 && isW(txt[p - 1])) p-- }
            } else {
                p = (p + dx).coerceIn(0, n)
                if (dx > 0 && p in 1 until n && txt[p].isLowSurrogate() && txt[p - 1].isHighSurrogate()) p++
                if (dx < 0 && p in 1 until n && txt[p].isLowSurrogate() && txt[p - 1].isHighSurrogate()) p--
            }
            while (p in 1 until n && tm.isHidden(p)) p = (p + if (dx >= 0) 1 else -1).coerceIn(0, n)
            np = p
        } else {
            val l = layout
            if (l == null || n == 0) np = pos
            else {
                val vp = tm.vis(pos)
                val line = l.getLineForOffset(vp)
                val x = goalX?.takeIf { goalPos == pos } ?: l.getHorizontalPosition(vp, true)
                val target = line + dy
                np = when {
                    target < 0 -> 0
                    target >= l.lineCount -> n
                    else -> tm.orig(l.getOffsetForPosition(Offset(x, (l.getLineTop(target) + l.getLineBottom(target)) / 2)))
                }.coerceIn(0, n)
                goalX = x; goalPos = np
            }
        }
        t.value = v.copy(selection = if (extend) TextRange(anchor, np) else TextRange(np))
    }
    keyMover[0] = ::moveCursorKey

    // ---------- Diagnósticos (scanner rápido -> CPython real) + erro de execução
    var staticDiags by remember(tab.id) { mutableStateOf<List<Diagnostic>>(emptyList()) }
    LaunchedEffect(tab.id, text) {
        delay(120)
        staticDiags = withContext(Dispatchers.Default) { SyntaxAnalyzer.analyzeFast(text) }
        delay(300)
        staticDiags = withContext(Dispatchers.Default) { SyntaxAnalyzer.analyze(text, tab.name) }
    }
    val rtErr by PyRunner.error.collectAsState()
    val rtDiag = remember(rtErr, text, tab.name) {
        rtErr?.takeIf { it.fileName == tab.name && it.sourceHash == text.hashCode() }?.let { SyntaxAnalyzer.fromRuntime(it, text) }
    }
    val diags = remember(staticDiags, rtDiag) { (staticDiags + listOfNotNull(rtDiag)).distinctBy { it.line to it.message } }
    val cursorLine = lineOf(lineStartsArr, tab.value.selection.min.coerceIn(0, text.length)) + 1
    val activeDiag = diags.firstOrNull { it.line == cursorLine } ?: diags.firstOrNull()

    LaunchedEffect(tab.id) { runCatching { focus.requestFocus() } }
    LaunchedEffect(tab.id, text, autoSave) {
        val u = tab.uri
        if (autoSave && u != null && tab.dirty) {
            delay(1000)
            if (tab.dirty) {
                val snap = text
                val ok = withContext(Dispatchers.IO) { ProjectFs.writeText(ctx, u, snap) }
                if (!ok) toast("Erro ao salvar ${tab.name}")
                else if (tab.value.text == snap) tab.dirty = false
            }
        }
    }
    LaunchedEffect(Unit) {
        snapshotFlow { Triple(tabs.map { it.toSession() }, cur, nextId) }.collectLatest { (list, c, n) ->
            delay(500)
            withContext(Dispatchers.IO) { session.save(list, c, n) }
        }
    }

    // ============================================================ UI
    Box(
        Modifier.fillMaxSize().background(theme.bg).pointerInput(Unit) {
            // arrastar a partir da borda esquerda abre o gerenciador de arquivos
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                if (down.position.x <= 48.dp.toPx()) {
                    var dx = 0f
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        val ch = ev.changes.firstOrNull() ?: break
                        if (!ch.pressed) break
                        dx += ch.positionChange().x
                        if (dx > 56.dp.toPx()) { showSidebar = true; ch.consume(); break }
                    }
                }
            }
        }
    ) {
        Row(Modifier.fillMaxSize()) {
            if (showSidebar && wide) FileExplorerSidebar(
                explorer, theme, tab.uri, { treeLauncher.launch(null) }, ::openProjectFile, ::onDocChanged, { showSidebar = false },
                Modifier.width(280.dp).fillMaxHeight()
            )
            Column(Modifier.weight(1f).fillMaxHeight()) {
                // ---- barra de ferramentas
                Row(Modifier.fillMaxWidth().background(theme.bar).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                    Btn("☰", theme) { showSidebar = !showSidebar }
                    if (running) Btn("■ Parar", theme, theme.error) { doStop() } else Btn("▶ Executar", theme, theme.function) { doRun() }
                    Btn("Salvar", theme) { actions.save() }
                    Btn("Buscar", theme) { actions.find() }
                    Btn("Console", theme) { showConsole = !showConsole }
                    Btn("A−", theme) { fontSize = (fontSize - 1f).coerceAtLeast(8f) }
                    Btn("A+", theme) { fontSize = (fontSize + 1f).coerceAtMost(40f) }
                    Box {
                        Btn("⋮", theme) { showMenu = true }
                        DropdownMenu(showMenu, { showMenu = false }) {
                            @Composable
                            fun item(label: String, run: () -> Unit) = DropdownMenuItem(
                                text = { Text(label) },
                                modifier = Modifier.rightMouseAsPress { showMenu = false; run() },
                                onClick = { showMenu = false; run() }
                            )
                            item("Abrir arquivo…") { actions.openFile() }
                            item("Novo arquivo") { addNewTab() }
                            item("Próxima aba") { cur = (cur.coerceIn(0, tabs.lastIndex) + 1) % tabs.size; toast(tabs[cur].name) }
                            item("Fechar aba atual") { requestClose(cur.coerceIn(0, tabs.lastIndex)) }
                            item("Importar projeto do GitHub…") { showGithubImport = true }
                            item("Executar arquivo principal do projeto…") { chooseProjectMain() }
                            item("Instalar biblioteca Python (Termux)…") { showPackages = true }
                            item("Diagnosticar Termux / X11…") { showTermuxDiagnostics = true; PyRunner.diagnoseTermux(ctx) }
                            item("Configurar pasta compartilhada Termux…") { bridgeTreeLauncher.launch(null) }
                            item("Ajustes de tela do Termux:X11…") { showX11Settings = true }
                            item("Abrir Termux:X11 em tela dividida") {
                                TermuxX11Runner.openX11(ctx, launchAdjacent = true).onFailure { toast(it.message ?: "Não consegui abrir Termux:X11") }
                            }
                            item("Abrir Termux:X11") {
                                TermuxX11Runner.openX11(ctx).onFailure { toast(it.message ?: "Não consegui abrir Termux:X11") }
                            }
                            item("Salvar como…") { actions.saveAs() }
                            item("Salvar tudo") { saveAll() }
                            item("Ir para linha…") { showGoto = true }
                            item("Símbolos (funções/classes)") { showSymbols = true }
                            item("Buscar no projeto…") { showProjSearch = true }
                            item(if (tab.folded.isEmpty()) "Dobrar todos os blocos" else "Desdobrar todos os blocos") {
                                tab.folded = if (tab.folded.isEmpty()) blocks.keys.toSet() else emptySet()
                            }
                            item("Limpar breakpoints") { tab.breakpoints = emptySet() }
                            item("Entradas prontas para input()…") { showPresets = true }
                            item("Compartilhar") { doShare() }
                            item(if (tabMarks) "Marcadores de tab: ON" else "Marcadores de tab: OFF") { tabMarks = !tabMarks; prefs.edit().putBoolean("tabMarks", tabMarks).apply() }
                            item("Substituir…") { actions.replace() }
                            item("Formatar (espaços finais)") { formatCode() }
                            item("Indentar") { actions.indent() }
                            item("Desindentar") { actions.outdent() }
                            item("Converter espaços em tabs") { doToTabs() }
                            item("Snippets…") { showSnippets = true }
                            item("Configurar atalhos…") { showShortcutSettings = true }
                            item("Tema: ${theme.name}") { themeIdx = (themeIdx + 1) % CodeThemes.all.size; prefs.edit().putInt("theme", themeIdx).apply() }
                            item("Fonte: ${fonts[fontIdx].first}") { fontIdx = (fontIdx + 1) % fonts.size; prefs.edit().putInt("font", fontIdx).apply() }
                            item(if (autoSave) "Auto-save: ON" else "Auto-save: OFF") { autoSave = !autoSave; prefs.edit().putBoolean("autosave", autoSave).apply() }
                            item(if (guides) "Guias de indentação: ON" else "Guias de indentação: OFF") { guides = !guides; prefs.edit().putBoolean("guides", guides).apply() }
                            item(if (wrap) "Quebra de linha: ON" else "Quebra de linha: OFF (rolar de lado)") { wrap = !wrap; prefs.edit().putBoolean("wrap", wrap).apply() }
                            item(if (floatRun) "Botão executar flutuante: ON" else "Botão executar flutuante: OFF") { floatRun = !floatRun; prefs.edit().putBoolean("floatRun", floatRun).apply() }
                        }
                    }
                }
                // ---- busca / substituição
                if (showFind) Column(Modifier.fillMaxWidth().background(theme.bar).padding(horizontal = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, label = { Text("Buscar") })
                        Checkbox(useRegex, { useRegex = it }); Text("Regex", fontSize = 12.sp, color = theme.text)
                        Btn("Próx.", theme) { doFindNext() }
                        Btn("✕", theme) { showFind = false }
                    }
                    if (showReplace) Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(repl, { repl = it }, Modifier.weight(1f), singleLine = true, label = { Text("Substituir por") })
                        Btn("Substituir", theme) { replaceOne() }
                        Btn("Todos", theme) { replaceAll() }
                    }
                }
                // ---- editor
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    val minH = maxHeight
                    val maxW = maxWidth
                    val density = LocalDensity.current
                    val viewportPx = with(density) { minH.roundToPx() }
                    key(tab.id) {
                        val scroll = rememberScrollState()
                        // só muda a cada 600 px de rolagem: evita redesenhar guias/diagnósticos a cada frame
                        val scrollPage by remember { derivedStateOf { scroll.value / 600 } }
                        val lineH = fontSize * 1.45f
                        val textStyle = TextStyle(fontFamily = family, fontSize = fontSize.sp, lineHeight = lineH.sp, color = theme.text,
                            // linhas continuadas (quebra automática) entram ~2 colunas para dentro, para se distinguirem de linhas novas
                            textIndent = if (wrap) TextIndent(0.sp, (fontSize * 1.2f).sp) else null)
                        val measurer = rememberTextMeasurer(cacheSize = 128)
                        val hScroll = rememberScrollState()
                        val gutterDp = (lineStartsArr.size.toString().length.coerceAtLeast(2) * fontSize * 0.62f + 30f).dp
                        val charW = remember(family, fontSize) { measurer.measure("MMMMMMMMMM", TextStyle(fontFamily = family, fontSize = fontSize.sp)).size.width / 10f }
                        // sem quebra automática: o campo ganha a largura da linha mais comprida (rolagem lateral)
                        val maxCols = remember(text) {
                            var mx = 0; var cur = 0
                            for (ch in text) { if (ch == '\n') { if (cur > mx) mx = cur; cur = 0 } else cur += if (ch == '\t') TAB_W else 1 }
                            maxOf(mx, cur)
                        }
                        val noWrapPx = maxOf(with(density) { (maxW - gutterDp - 22.dp).roundToPx() }, ((maxCols + 4) * charW).toInt()).coerceAtMost(200_000)
                        // mantém o cursor visível
                        LaunchedEffect(tab.value.selection, layout, wrap) {
                            val l = layout ?: return@LaunchedEffect
                            val c = l.getCursorRect(tm.vis(tab.value.selection.end.coerceIn(0, text.length)))
                            val pad = with(density) { 8.dp.roundToPx() }
                            val top = c.top.toInt() + pad; val bottom = c.bottom.toInt() + pad
                            if (top < scroll.value) scroll.scrollTo((top - 8).coerceAtLeast(0))
                            else if (bottom > scroll.value + viewportPx) scroll.scrollTo(bottom - viewportPx + 8)
                            if (wrap) { if (hScroll.value != 0) hScroll.scrollTo(0) }
                            else {
                                val vw = with(density) { (maxW - gutterDp - 22.dp).roundToPx() }
                                val cx = c.left.toInt()
                                if (cx < hScroll.value + 16) hScroll.scrollTo((cx - 16).coerceAtLeast(0))
                                else if (cx > hScroll.value + vw - 32) hScroll.scrollTo(cx - vw + 32)
                            }
                        }
                        Box(
                            Modifier.fillMaxSize().pointerInput(Unit) {
                                // pinch-to-zoom: só consome com 2+ dedos (1 dedo continua rolando/selecionando)
                                awaitEachGesture {
                                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                    do {
                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                        if (ev.changes.size >= 2 && ev.changes.all { it.pressed }) {
                                            val z = ev.calculateZoom()
                                            if (z != 1f) { fontSize = (fontSize * z).coerceIn(8f, 40f); ev.changes.forEach { it.consume() } }
                                        }
                                    } while (ev.changes.any { it.pressed })
                                }
                            }
                        ) {
                            Box(Modifier.fillMaxSize().verticalScroll(scroll).padding(8.dp)) {
                                Row(Modifier.fillMaxWidth()) {
                                    val digits = lineStartsArr.size.toString().length.coerceAtLeast(2)
                                    val gutterW = (digits * fontSize * 0.62f + 30f).dp
                                    val curLine0 = cursorLine - 1
                                    val errLines = remember(diags) { diags.filter { it.severity == Severity.ERROR }.map { it.line }.toSet() }
                                    val foldZone = with(density) { 18.dp.toPx() }
                                    Canvas(
                                        Modifier.width(gutterW)
                                            .layoutMod { m, c ->
                                                // altura lida na fase de layout: não recompõe a tela inteira a cada tecla
                                                val h = maxOf(layout?.size?.height ?: 0, viewportPx)
                                                val pl = m.measure(Constraints.fixed(c.maxWidth, h))
                                                this.layout(pl.width, pl.height) { pl.place(0, 0) }
                                            }
                                            .background(theme.gutterBg)
                                            .pointerInput(tm, blocks) {
                                                // toque na seta (esquerda) dobra o bloco; toque no número liga/desliga breakpoint
                                                detectTapGestures { p ->
                                                    val l = layout ?: return@detectTapGestures
                                                    val vi = l.getLineForVerticalPosition(p.y)
                                                    val st = l.getLineStart(vi)
                                                    if (vi != 0 && l.layoutInput.text.text.getOrNull(st - 1) != '\n') return@detectTapGestures
                                                    val ln = lineOf(lineStartsArr, tm.orig(st))
                                                    if (p.x < foldZone && blocks.containsKey(ln)) tab.folded = if (ln in tab.folded) tab.folded - ln else tab.folded + ln
                                                    else tab.breakpoints = if (ln in tab.breakpoints) tab.breakpoints - ln else tab.breakpoints + ln
                                                }
                                            }
                                    ) {
                                        val l = layout ?: return@Canvas
                                        val shown = l.layoutInput.text.text
                                        val gy0 = (scrollPage * 600 - 1200).toFloat()
                                        val gy1 = gy0 + viewportPx + 3000f
                                        val gFirst = l.getLineForVerticalPosition(gy0.coerceAtLeast(0f))
                                        val gLast = l.getLineForVerticalPosition(gy1.coerceAtLeast(0f))
                                        for (i in gFirst..gLast) {
                                            val st = l.getLineStart(i)
                                            if (i == 0 || shown.getOrNull(st - 1) == '\n') {
                                                val logical = lineOf(lineStartsArr, tm.orig(st))
                                                val isErr = (logical + 1) in errLines
                                                val isBp = logical in tab.breakpoints
                                                val r = measurer.measure(
                                                    (logical + 1).toString(),
                                                    TextStyle(fontFamily = family, fontSize = (fontSize * 0.9f).sp, lineHeight = lineH.sp,
                                                        color = if (isBp) Color.White else if (isErr) theme.error else if (logical == curLine0) theme.gutterActive else theme.gutterText)
                                                )
                                                val top = l.getLineTop(i); val bot = l.getLineBottom(i)
                                                val nx = size.width - r.size.width - 10.dp.toPx()
                                                if (isBp) drawRoundRect(
                                                    Color(0xFFE5484D), Offset(nx - 5.dp.toPx(), top + 1.dp.toPx()),
                                                    Size(r.size.width + 10.dp.toPx(), bot - top - 2.dp.toPx()), CornerRadius(5.dp.toPx())
                                                )
                                                drawText(r, topLeft = Offset(nx, top))
                                                if (isErr && !isBp) drawCircle(theme.error, 3.dp.toPx(), Offset(size.width - 4.dp.toPx(), (top + bot) / 2))
                                                if (blocks.containsKey(logical)) {
                                                    val ch = measurer.measure(
                                                        if (logical in tab.folded) "▸" else "▾",
                                                        TextStyle(fontFamily = family, fontSize = (fontSize * 0.85f).sp, lineHeight = lineH.sp, color = theme.gutterText)
                                                    )
                                                    drawText(ch, topLeft = Offset(3.dp.toPx(), top))
                                                }
                                            } else {
                                                // linha continuada pela quebra automática
                                                val wr = measurer.measure("↪", TextStyle(fontFamily = family, fontSize = (fontSize * 0.8f).sp, lineHeight = lineH.sp, color = theme.gutterText.copy(alpha = 0.6f)))
                                                drawText(wr, topLeft = Offset(size.width - wr.size.width - 10.dp.toPx(), l.getLineTop(i)))
                                            }
                                        }
                                    }
                                    Box(Modifier.weight(1f).then(if (wrap) Modifier else Modifier.horizontalScroll(hScroll)).padding(start = 6.dp)) {
                                        val indentLv = remember(text) { indentLevels(text) }
                                        val vt = remember(theme, tm) {
                                            VisualTransformation { t ->
                                                val hl = SyntaxAnalyzer.highlight(t.text, theme)
                                                if (!tm.any) TransformedText(hl, OffsetMapping.Identity)
                                                else TransformedText(applyDisplay(hl, tm), object : OffsetMapping {
                                                    override fun originalToTransformed(offset: Int) = tm.vis(offset)
                                                    override fun transformedToOriginal(offset: Int) = tm.orig(offset)
                                                })
                                            }
                                        }
                                        BasicTextField(
                                            value = tab.value,
                                            onValueChange = {
                                                val nv = autoIndent(tab.value, autoPair(tab.value, it))
                                                if (tab.folded.isNotEmpty() && nv.text != tab.value.text && tm.inFold(tab.value.selection.min)) tab.folded = emptySet()
                                                tab.change(nv)
                                            },
                                            textStyle = textStyle,
                                            cursorBrush = SolidColor(theme.cursor),
                                            visualTransformation = vt,
                                            onTextLayout = { layout = it },
                                            keyboardOptions = KeyboardOptions(autoCorrectEnabled = false),
                                            modifier = (if (wrap) Modifier.fillMaxWidth() else Modifier.width(with(density) { noWrapPx.toDp() })).heightIn(min = minH)
                                                .then(
                                                    if (selectMode) Modifier.pointerInput(tm) {
                                                        // modo seleção: arrastar com o dedo seleciona uma área (em vez de rolar)
                                                        var anchor = 0
                                                        detectDragGestures(
                                                            onDragStart = { p ->
                                                                layout?.let { l ->
                                                                    anchor = tm.orig(l.getOffsetForPosition(p))
                                                                    tab.value = tab.value.copy(selection = TextRange(anchor))
                                                                }
                                                            },
                                                            onDrag = { change, _ ->
                                                                change.consume()
                                                                layout?.let { l ->
                                                                    val o = tm.orig(l.getOffsetForPosition(change.position))
                                                                    tab.value = tab.value.copy(selection = TextRange(anchor, o))
                                                                }
                                                            }
                                                        )
                                                    } else Modifier
                                                )
                                                .drawBehind {
                                                    layout?.let {
                                                        val ps = dbgPause
                                                        if (ps != null && ps.fileName == tab.name && text.isNotEmpty()) {
                                                            lineStartsArr.getOrNull(ps.line - 1)?.let { off ->
                                                                val ln = it.getLineForOffset(tm.vis(off.coerceAtMost(text.length)))
                                                                drawRect(Color(0x44FFD43B), Offset(0f, it.getLineTop(ln)), Size(size.width, it.getLineBottom(ln) - it.getLineTop(ln)))
                                                            }
                                                        }
                                                        val y0 = (scrollPage * 600 - 1200).toFloat()
                                                        val y1 = y0 + viewportPx + 3000f
                                                        if (guides) drawIndentGuides(it, text, tm, indentLv, lineStartsArr, theme.gutterText.copy(alpha = 0.35f), y0, y1)
                                                        if (tabMarks) drawTabMarks(it, tm, theme.gutterText.copy(alpha = 0.4f), y0, y1)
                                                        drawDiagnostics(it, text, tm, diags, theme.error, WARN_COLOR, y0, y1)
                                                    }
                                                }
                                                .focusRequester(focus)
                                                .onFocusChanged { editorFocused = it.isFocused }
                                                .onPreviewKeyEvent { keys.handle(it) }
                                                .pointerHoverIcon(PointerIcon.Text)
                                                // Controles de mouse: clique direito abre menu de edição e Ctrl+roda
                                                // ajusta o tamanho da fonte. A roda normal continua com a rolagem do editor.
                                                .pointerInput(layout, tm, fontSize) {
                                                    awaitPointerEventScope {
                                                        while (true) {
                                                            val event = awaitPointerEvent(PointerEventPass.Initial)
                                                            val change = event.changes.firstOrNull() ?: continue
                                                            if (event.type == PointerEventType.Press &&
                                                                change.type == PointerType.Mouse && event.buttons.isSecondaryPressed) {
                                                                val l = layout
                                                                if (l != null) {
                                                                    val offset = tm.orig(l.getOffsetForPosition(change.position))
                                                                        .coerceIn(0, tab.value.text.length)
                                                                    val sel = tab.value.selection
                                                                    // Clique direito dentro da seleção preserva o trecho selecionado.
                                                                    if (sel.collapsed || offset < sel.min || offset >= sel.max) {
                                                                        tab.value = tab.value.copy(selection = TextRange(offset))
                                                                    }
                                                                    editorContextOffset = change.position
                                                                    showEditorContextMenu = true
                                                                    focus.requestFocus()
                                                                }
                                                            } else if (event.type == PointerEventType.Scroll && event.keyboardModifiers.isCtrlPressed) {
                                                                val dy = change.scrollDelta.y
                                                                if (dy != 0f) {
                                                                    fontSize = (fontSize + if (dy < 0f) 1f else -1f).coerceIn(8f, 40f)
                                                                    event.changes.forEach { it.consume() }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                        )
                                        // O Popup é ancorado na posição do ponteiro, como em um editor de desktop.
                                        Box(
                                            Modifier.offset { IntOffset(editorContextOffset.x.roundToInt(), editorContextOffset.y.roundToInt()) }
                                                .size(1.dp)
                                        ) {
                                            DropdownMenu(
                                                expanded = showEditorContextMenu,
                                                onDismissRequest = { showEditorContextMenu = false }
                                            ) {
                                                @Composable
                                                fun mouseItem(label: String, run: () -> Unit) {
                                                    DropdownMenuItem(
                                                        text = { Text(label, fontSize = 14.sp) },
                                                        modifier = Modifier.rightMouseAsPress { showEditorContextMenu = false; run(); focus.requestFocus() },
                                                        onClick = { showEditorContextMenu = false; run(); focus.requestFocus() }
                                                    )
                                                }
                                                if (tab.undoCount > 0) mouseItem("Desfazer") { tab.undo() }
                                                if (tab.redoCount > 0) mouseItem("Refazer") { tab.redo() }
                                                mouseItem("Recortar") { actions.cut() }
                                                mouseItem("Copiar") { actions.copy() }
                                                mouseItem("Colar") { actions.paste() }
                                                mouseItem("Selecionar linha") { actions.selectLine() }
                                                mouseItem("Selecionar tudo") { doSelectAll() }
                                                mouseItem("Duplicar linha") { actions.duplicateLine() }
                                                mouseItem("Comentar / descomentar") { actions.toggleComment() }
                                                mouseItem("Indentar") { actions.indent() }
                                                mouseItem("Desindentar") { actions.outdent() }
                                                mouseItem("Buscar…") { actions.find() }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                // ---- depurador (script parado num breakpoint)
                dbgPause?.let { DebugPanel(theme, family, fontSize, it, Modifier.fillMaxWidth()) }
                // ---- console interativo
                if (showConsole) ConsolePanel(
                    theme, family, fontSize, consoleBig, { consoleBig = !consoleBig }, { showConsole = false }, { doRerun() },
                    Modifier.fillMaxWidth().weight(if (consoleBig) 2f else 1f)
                )
                // ---- diagnósticos
                DiagnosticsBanner(
                    diags, activeDiag, theme, showAllDiags, { showAllDiags = !showAllDiags },
                    onJump = { d -> gotoOffset(d.start) }, onFix = { applyFix(it) }
                )
                // ---- atalhos de sintaxe (Alt+1..9): só aparecem enquanto você digita
                if (editorFocused) KeyboardSuggestionBar(
                    text = text, cursor = tab.value.selection.start, theme = theme, members = memberList,
                    onSuggestion = ::applySuggestion,
                    onShown = { list, plen -> sugList = list; sugPrefixLen = plen },
                    userSnippets = snippets.toList()
                )
            }
        }
        // botão executar flutuante (opção do menu ⋮), arrastável
        if (floatRun) {
            var fab by remember { mutableStateOf(Offset.Zero) }
            Box(
                Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 130.dp)
                    .offset { IntOffset(fab.x.roundToInt(), fab.y.roundToInt()) }
                    .size(54.dp).clip(CircleShape)
                    .background(if (running) theme.error else theme.function)
                    .pointerInput(Unit) { detectDragGestures { change, drag -> change.consume(); fab += drag } }
                    .clickable { if (running) doStop() else doRun() },
                contentAlignment = Alignment.Center
            ) { Text(if (running) "■" else "▶", color = theme.bg, fontSize = 22.sp) }
        }
        // gerenciador de arquivos sobreposto em telas estreitas (arraste para a esquerda ou toque fora para fechar)
        if (!wide) {
            AnimatedVisibility(showSidebar, enter = slideInHorizontally { -it }, exit = slideOutHorizontally { -it }) {
                Row(Modifier.fillMaxSize()) {
                    FileExplorerSidebar(
                        explorer, theme, tab.uri, { treeLauncher.launch(null) }, ::openProjectFile, ::onDocChanged, { showSidebar = false },
                        Modifier.width(310.dp).fillMaxHeight().pointerInput(Unit) {
                            var total = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { total = 0f },
                                onDragEnd = { if (total < -60f) showSidebar = false },
                                onHorizontalDrag = { _, d -> total += d }
                            )
                        }
                    )
                    Box(Modifier.weight(1f).fillMaxHeight().background(Color(0x66000000)).clickable { showSidebar = false })
                }
            }
        }
    }

    // ============================================================ diálogos
    val closing = confirmClose?.let { id -> tabs.firstOrNull { it.id == id } }
    if (closing != null) AlertDialog(
        onDismissRequest = { confirmClose = null },
        title = { Text("Fechar \"${closing.name}\"?") },
        text = { Text("Há alterações não salvas nesta aba.") },
        confirmButton = {
            Row {
                val u = closing.uri
                if (u != null) RightClickableTextButton({ writeTo(closing, u); confirmClose = null; removeTab(tabs.indexOfFirst { it.id == closing.id }) }) { Text("Salvar e fechar") }
                RightClickableTextButton({ confirmClose = null; removeTab(tabs.indexOfFirst { it.id == closing.id }) }) { Text("Fechar sem salvar") }
            }
        },
        dismissButton = { RightClickableTextButton({ confirmClose = null }) { Text("Cancelar") } }
    )

    if (showGithubImport) AlertDialog(
        onDismissRequest = { if (!githubBusy) showGithubImport = false },
        title = { Text("Importar projeto do GitHub") },
        text = {
            Column {
                Text("Importa um repositório público para o armazenamento privado do CodeInjector.", fontSize = 13.sp)
                OutlinedTextField(
                    value = githubUrl, onValueChange = { githubUrl = it },
                    label = { Text("URL do repositório") }, singleLine = true,
                    placeholder = { Text("https://github.com/usuario/projeto") },
                    enabled = !githubBusy, modifier = Modifier.fillMaxWidth()
                )
                if (githubBusy) Text("Baixando e extraindo…", Modifier.padding(top = 8.dp), fontSize = 12.sp)
            }
        },
        confirmButton = {
            RightClickableTextButton(enabled = !githubBusy, onClick = {
                githubBusy = true
                scope.launch {
                    val result = withContext(Dispatchers.IO) { runCatching { GitHubRepoImporter.importPublicRepo(ctx, githubUrl) } }
                    githubBusy = false
                    result.onSuccess { imported ->
                        showGithubImport = false
                        val first = imported.pythonFiles.firstOrNull()
                        if (first != null) {
                            val source = withContext(Dispatchers.IO) { first.readText() }
                            importedProjectRoot = imported.folder
                            importedProjectTabPaths.clear()
                            val selected = EditorTab(nextId++, first.name, null, source)
                            tabs.add(selected)
                            importedProjectTabPaths[selected.id] = first.relativeTo(imported.folder).invariantSeparatorsPath
                            cur = tabs.lastIndex
                            toast("Projeto importado: ${imported.folder.name} · ${imported.pythonFiles.size} arquivo(s) Python")
                        } else toast("Projeto importado, mas não contém arquivos .py: ${imported.folder.absolutePath}")
                    }.onFailure { toast("Falha ao importar: ${it.message ?: "erro de rede"}") }
                }
            }) { Text("Importar") }
        },
        dismissButton = { RightClickableTextButton(enabled = !githubBusy, onClick = { showGithubImport = false }) { Text("Cancelar") } }
    )

    if (showProjectRunDialog) AlertDialog(
        onDismissRequest = { showProjectRunDialog = false },
        title = { Text("Escolher arquivo principal") },
        text = {
            Column(Modifier.heightIn(max = 460.dp)) {
                Text("Selecione o script de entrada. A execução usa a pasta do projeto e mantém subpastas/recursos quando o projeto é copiado para o Termux.", fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                when {
                    projectScriptsLoading -> Text("Procurando arquivos .py…", fontSize = 13.sp)
                    projectScriptChoices.isEmpty() -> Text("Nenhum arquivo .py encontrado. Abra a pasta correta no explorador.", fontSize = 13.sp)
                    else -> LazyColumn(Modifier.heightIn(max = 340.dp)) {
                        items(projectScriptChoices, key = { it.relativePath }) { choice ->
                            Text(
                                choice.relativePath,
                                Modifier.fillMaxWidth().clickable { runProjectScript(choice) }.padding(vertical = 10.dp, horizontal = 6.dp),
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Divider()
                        }
                    }
                }
            }
        },
        confirmButton = { RightClickableTextButton(onClick = { chooseProjectMain() }) { Text("Atualizar lista") } },
        dismissButton = { RightClickableTextButton(onClick = { showProjectRunDialog = false }) { Text("Fechar") } }
    )

    if (showPackages) AlertDialog(
        onDismissRequest = { showPackages = false },
        title = { Text("Bibliotecas Python no Termux") },
        text = {
            Column {
                Text("Digite apenas o nome do pacote. Se ~/.codeinjector/termux-x11.conf configurar uma distro Debian, Kivy/Pygame serão instalados por apt nessa distro; caso contrário, a IDE tentará pip no Python do Termux. Isso não instala pacotes no Python integrado Chaquopy.", fontSize = 13.sp)
                OutlinedTextField(
                    value = packageName, onValueChange = { packageName = it },
                    label = { Text("Pacote (ex.: pygame ou kivy)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            RightClickableTextButton(onClick = {
                val pkg = packageName.trim()
                TermuxX11Runner.installPythonPackage(ctx, pkg).onSuccess {
                    showPackages = false
                    toast("Comando de instalação enviado ao Termux. Acompanhe o terminal aberto.")
                }.onFailure { toast("Não foi possível instalar: ${it.message}") }
            }) { Text("Instalar no Termux") }
        },
        dismissButton = { RightClickableTextButton({ showPackages = false }) { Text("Cancelar") } }
    )

    if (showTermuxDiagnostics) AlertDialog(
        onDismissRequest = { showTermuxDiagnostics = false },
        title = { Text("Diagnosticar Termux / Termux:X11") },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                Text(
                    termuxDiagnosticReport ?: "O diagnóstico verifica os APKs, a permissão RUN_COMMAND, allow-external-apps, termux-x11, Python, módulos gráficos e a pasta compartilhada.",
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                Text("Se o diagnóstico não iniciar, abra o Termux e cole o comando abaixo. Depois execute termux-setup-storage.", fontSize = 12.sp)
            }
        },
        confirmButton = {
            RightClickableTextButton(onClick = {
                val fix = "mkdir -p ~/.termux\ntouch ~/.termux/termux.properties\nif grep -Eq '^[[:space:]]*allow-external-apps[[:space:]]*=' ~/.termux/termux.properties; then sed -i -E 's/^[[:space:]]*allow-external-apps[[:space:]]*=.*/allow-external-apps=true/' ~/.termux/termux.properties; else printf '\\nallow-external-apps=true\\n' >> ~/.termux/termux.properties; fi\ntermux-reload-settings\ntermux-setup-storage\npkg update\npkg install x11-repo termux-x11-nightly python coreutils procps"
                clipboard.setText(AnnotatedString(fix))
                toast("Comando de configuração copiado")
            }) { Text("Copiar correções") }
        },
        dismissButton = {
            Row {
                RightClickableTextButton(onClick = { PyRunner.diagnoseTermux(ctx) }) { Text("Executar novamente") }
                RightClickableTextButton(onClick = { showTermuxDiagnostics = false }) { Text("Fechar") }
            }
        }
    )

    if (showX11Settings) AlertDialog(
        onDismissRequest = { showX11Settings = false },
        title = { Text("Ajustes do Termux:X11") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                Text("Modo de resolução", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                listOf("native" to "Nativa", "scaled" to "Escalada", "exact" to "Exata", "custom" to "Personalizada").forEach { (value, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { x11ResolutionMode = value }) {
                        RadioButton(selected = x11ResolutionMode == value, onClick = { x11ResolutionMode = value })
                        Text(label, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(6.dp))
                if (x11ResolutionMode == "exact" || x11ResolutionMode == "custom") {
                    OutlinedTextField(
                        value = x11ResolutionExact,
                        onValueChange = { x11ResolutionExact = it.filter { c -> c.isDigit() || c == 'x' || c == 'X' }.take(11) },
                        label = { Text("Resolução exata (ex.: 1280x720)") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Text("Escala da interface: $x11Scale%", fontSize = 13.sp)
                Slider(value = x11Scale.toFloat(), onValueChange = { x11Scale = it.toInt().coerceIn(30, 300) }, valueRange = 30f..300f)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = x11AdjustResolution, onCheckedChange = { x11AdjustResolution = it })
                    Text("Adaptar resolução quando o celular gira", fontSize = 12.sp)
                }
                Spacer(Modifier.height(6.dp))
                Text("Orientação da resolução personalizada", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                listOf("auto" to "Manter a resolução informada", "portrait" to "Retrato", "landscape" to "Paisagem").forEach { (value, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { x11ResolutionOrientation = value }) {
                        RadioButton(selected = x11ResolutionOrientation == value, onClick = { x11ResolutionOrientation = value })
                        Text(label, fontSize = 12.sp)
                    }
                }
                Text("Disponível nos modos Exata/Personalizada. Para a orientação nativa do celular, use a rotação do Android e a opção de adaptar a resolução.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                Text("Modo de toque", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                listOf("Trackpad" to "Touchpad (cursor relativo)", "Simulated touchscreen" to "Toque simulado", "Direct touch" to "Toque direto").forEach { (value, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { x11TouchMode = value }) {
                        RadioButton(selected = x11TouchMode == value, onClick = { x11TouchMode = value })
                        Text(label, fontSize = 12.sp)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = x11Pip, onCheckedChange = { x11Pip = it })
                    Text("Permitir janela flutuante (PiP)", fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = x11Fullscreen, onCheckedChange = { x11Fullscreen = it })
                    Text("Tela cheia", fontSize = 12.sp)
                }
                Text("As preferências são enviadas ao utilitário oficial termux-x11-preference. A disponibilidade dos modos depende da versão do pacote instalado.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            RightClickableTextButton(onClick = {
                val validResolution = Regex("([0-9]{2,5})[xX]([0-9]{2,5})").matchEntire(x11ResolutionExact)
                val selectedResolution = if (validResolution != null && x11ResolutionOrientation in setOf("portrait", "landscape")) {
                    val w = validResolution.groupValues[1].toInt()
                    val h = validResolution.groupValues[2].toInt()
                    val needsSwap = (x11ResolutionOrientation == "portrait" && w > h) || (x11ResolutionOrientation == "landscape" && h > w)
                    if (needsSwap) "${h}x${w}" else "${w}x${h}"
                } else x11ResolutionExact
                val selected = buildMap {
                    put("displayResolutionMode", x11ResolutionMode)
                    if (x11ResolutionMode == "exact" || x11ResolutionMode == "custom") {
                        put("displayResolutionExact", selectedResolution)
                    }
                    put("displayScale", x11Scale.toString())
                    put("adjustResolution", x11AdjustResolution.toString())
                    put("touchMode", x11TouchMode)
                    put("PIP", x11Pip.toString())
                    put("fullscreen", x11Fullscreen.toString())
                }
                if (validResolution == null && x11ResolutionMode in setOf("exact", "custom")) {
                    toast("Resolução inválida. Use o formato 1280x720.")
                } else {
                    TermuxX11Runner.openX11(ctx).onSuccess {
                        scope.launch {
                            delay(900)
                            TermuxX11Runner.applyX11Preferences(ctx, selected).onSuccess {
                                prefs.edit()
                                    .putString("x11_resolution_mode", x11ResolutionMode)
                                    .putString("x11_resolution_exact", x11ResolutionExact)
                                    .putInt("x11_scale", x11Scale)
                                    .putBoolean("x11_adjust_resolution", x11AdjustResolution)
                                    .putString("x11_resolution_orientation", x11ResolutionOrientation)
                                    .putString("x11_touch_mode", x11TouchMode)
                                    .putBoolean("x11_pip", x11Pip)
                                    .putBoolean("x11_fullscreen", x11Fullscreen)
                                    .apply()
                                showX11Settings = false
                                toast("Preferências enviadas ao Termux:X11")
                            }.onFailure { toast("Não consegui aplicar: ${it.message}") }
                        }
                    }.onFailure { toast("Não consegui abrir o Termux:X11: ${it.message}") }
                }
            }) { Text("Aplicar") }
        },
        dismissButton = { RightClickableTextButton(onClick = { showX11Settings = false }) { Text("Cancelar") } }
    )

    if (showSymbols) {
        val syms = remember(text) { symbolsOf(text) }
        AlertDialog(
            onDismissRequest = { showSymbols = false },
            title = { Text("Símbolos de ${tab.name}") },
            text = {
                if (syms.isEmpty()) Text("Nenhuma função ou classe neste arquivo.")
                else LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(syms) { sy ->
                        Text(
                            "${sy.kind}  ${sy.name}",
                            Modifier.fillMaxWidth().clickable { showSymbols = false; gotoLine(sy.line) }
                                .padding(start = (sy.level * 16).dp, top = 9.dp, bottom = 9.dp),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            },
            confirmButton = { RightClickableTextButton({ showSymbols = false }) { Text("Fechar") } }
        )
    }
    if (showProjSearch) AlertDialog(
        onDismissRequest = { showProjSearch = false },
        title = { Text("Buscar no projeto") },
        text = {
            Column {
                OutlinedTextField(
                    projQuery, { projQuery = it }, singleLine = true, label = { Text("Texto") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { runProjSearch() })
                )
                if (projBusy) Text("Buscando…", Modifier.padding(top = 8.dp), fontSize = 12.sp)
                else if (projDone) Text("${projHits.size} resultado(s)" + (if (projHits.size >= 300) " (limite)" else ""), Modifier.padding(top = 8.dp), fontSize = 12.sp)
                LazyColumn(Modifier.heightIn(max = 300.dp)) {
                    items(projHits) { h ->
                        Column(
                            Modifier.fillMaxWidth().clickable {
                                showProjSearch = false
                                openProjectFileAt(DocEntry(h.docId, h.file.substringAfterLast('/'), false), h.line)
                            }.padding(vertical = 6.dp)
                        ) {
                            Text("${h.file}:${h.line}", fontSize = 12.sp, color = theme.function)
                            Text(h.text, fontSize = 13.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
                        }
                    }
                }
            }
        },
        confirmButton = { RightClickableTextButton({ runProjSearch() }) { Text("Buscar") } },
        dismissButton = { RightClickableTextButton({ showProjSearch = false }) { Text("Fechar") } }
    )
    if (showPresets) {
        var draft by remember { mutableStateOf(presetText) }
        var useDraft by remember { mutableStateOf(usePresets) }
        AlertDialog(
            onDismissRequest = { showPresets = false },
            title = { Text("Entradas prontas") },
            text = {
                Column {
                    Text("Uma resposta por linha, usadas nos input() na ordem. Quando as linhas acabam, o console pergunta normalmente.", fontSize = 12.sp)
                    OutlinedTextField(draft, { draft = it }, minLines = 3, maxLines = 8, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(useDraft, { useDraft = it }); Text("Usar nas execuções")
                    }
                }
            },
            confirmButton = {
                RightClickableTextButton({
                    presetText = draft; usePresets = useDraft
                    prefs.edit().putString("presets", draft).putBoolean("usePresets", useDraft).apply()
                    showPresets = false
                }) { Text("Salvar") }
            },
            dismissButton = { RightClickableTextButton({ showPresets = false }) { Text("Cancelar") } }
        )
    }
    if (showGoto) AlertDialog(
        onDismissRequest = { showGoto = false },
        confirmButton = { RightClickableTextButton({ gotoLine(gotoText.toIntOrNull() ?: 1); showGoto = false }) { Text("Ir") } },
        title = { Text("Ir para a linha") },
        text = { OutlinedTextField(gotoText, { gotoText = it.filter(Char::isDigit) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
    )

    if (showSnippets) {
        AlertDialog(
            onDismissRequest = { showSnippets = false },
            confirmButton = { RightClickableTextButton({ showSnippets = false }) { Text("Fechar") } },
            title = { Text("Snippets e atalhos") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Modelos integrados — toque para inserir", fontWeight = FontWeight.SemiBold, color = theme.text)
                    PythonCodeTemplates.all.forEach { template ->
                        val expanded = template.insertion()
                        Column(
                            Modifier.fillMaxWidth().clickable {
                                insertWithBack(expanded.text, expanded.cursorBack, expanded.selectionStartBack, expanded.selectionEndBack)
                                showSnippets = false
                            }.padding(vertical = 7.dp, horizontal = 4.dp)
                        ) {
                            Text(template.label, color = theme.function, fontSize = 14.sp)
                            Text(template.group + " · atalho: ${template.trigger}", color = theme.gutterText, fontSize = 11.sp)
                        }
                        Divider(color = theme.gutterBg)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Meus snippets", fontWeight = FontWeight.SemiBold, color = theme.text)
                    Text("Digite o atalho na barra de sugestões para inserir seu código. A indentação é convertida para tabs.", color = theme.gutterText, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                        RightClickableTextButton({ importSnippetsLauncher.launch(arrayOf("application/json", "text/*", "*/*")) }) { Text("Importar") }
                        RightClickableTextButton({ exportSnippetsLauncher.launch("CodeInjector-snippets.json") }) { Text("Exportar") }
                    }
                    if (snippets.isEmpty()) Text("Nenhum snippet personalizado salvo ainda.", color = theme.gutterText, fontSize = 12.sp)
                    snippets.forEach { snippet ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).clickable {
                                insert(PythonCodeTemplates.normalizeIndentationToTabs(snippet.body)); showSnippets = false
                            }.padding(vertical = 6.dp, horizontal = 4.dp)) {
                                Text(snippet.name, color = theme.function, fontSize = 14.sp)
                                Text("Atalho: ${snippet.trigger}", color = theme.gutterText, fontSize = 11.sp)
                            }
                            Text("✎", Modifier.clickable {
                                snippetName = snippet.name
                                snippetTrigger = snippet.trigger
                                snippetBody = snippet.body
                                editingSnippetTrigger = snippet.trigger
                            }.padding(8.dp), color = theme.function)
                            Text("🗑", Modifier.clickable {
                                snippets.remove(snippet); persistSnippets()
                                if (editingSnippetTrigger == snippet.trigger) {
                                    editingSnippetTrigger = null; snippetName = ""; snippetTrigger = ""; snippetBody = ""
                                }
                            }.padding(8.dp))
                        }
                        Divider(color = theme.gutterBg)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(if (editingSnippetTrigger == null) "Criar atalho personalizado" else "Editar atalho personalizado", fontWeight = FontWeight.SemiBold, color = theme.text)
                    OutlinedTextField(
                        value = snippetName, onValueChange = { snippetName = it }, singleLine = true,
                        label = { Text("Nome do snippet") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = snippetTrigger, onValueChange = { snippetTrigger = it.filter { c -> c.isLetterOrDigit() || c == '_' }.take(40) }, singleLine = true,
                        label = { Text("Atalho (letras, números e _)") }, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = snippetBody, onValueChange = { snippetBody = it }, minLines = 4, maxLines = 10,
                        label = { Text("Código a inserir") }, modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        RightClickableTextButton({ snippetBody = PythonCodeTemplates.normalizeIndentationToTabs(selectedOrAll()) }) {
                            Text("Usar seleção/arquivo")
                        }
                        RightClickableTextButton({
                            val trigger = SnippetStore.normalizeTrigger(snippetTrigger)
                            val body = PythonCodeTemplates.normalizeIndentationToTabs(snippetBody)
                            when {
                                snippetName.isBlank() -> toast("Informe um nome para o snippet.")
                                !SnippetStore.isValidTrigger(trigger) -> toast("Atalho inválido. Use letras, números e _, começando por letra ou _.")
                                body.isBlank() -> toast("Informe o código do snippet ou use a seleção/arquivo atual.")
                                snippets.any { it.trigger == trigger && it.trigger != editingSnippetTrigger } -> toast("Esse atalho já existe. Escolha outro ou edite o snippet existente.")
                                else -> {
                                    val item = UserCodeSnippet(trigger, snippetName.trim(), body)
                                    val oldIndex = editingSnippetTrigger?.let { old -> snippets.indexOfFirst { it.trigger == old } } ?: -1
                                    if (oldIndex >= 0) snippets[oldIndex] = item else snippets.add(item)
                                    persistSnippets()
                                    toast(if (oldIndex >= 0) "Atalho atualizado." else "Atalho criado.")
                                    snippetName = ""; snippetTrigger = ""; snippetBody = ""; editingSnippetTrigger = null
                                }
                            }
                        }) { Text(if (editingSnippetTrigger == null) "Criar" else "Salvar edição") }
                        if (editingSnippetTrigger != null) RightClickableTextButton({
                            snippetName = ""; snippetTrigger = ""; snippetBody = ""; editingSnippetTrigger = null
                        }) { Text("Cancelar edição") }
                    }
                }
            }
        )
    }

    if (showShortcutSettings && captureShortcutFor == null) AlertDialog(
        onDismissRequest = { showShortcutSettings = false },
        title = { Text("Configurar atalhos") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                Text("Defina uma combinação para qualquer ação listada. As configurações ficam salvas no aparelho. Para ações com atalho padrão, definir um personalizado substitui o padrão; limpar o personalizado restaura o padrão. Em conflitos, a combinação fica com a ação configurada por último.", fontSize = 12.sp, color = theme.gutterText)
                Spacer(Modifier.height(8.dp))
                ShortcutCatalog.actions.groupBy { it.category }.forEach { (category, categoryActions) ->
                    Text(category, color = theme.function, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                    categoryActions.forEach { action ->
                        val binding = customShortcuts.firstOrNull { it.actionId == action.id }
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(action.label, fontSize = 13.sp, color = theme.text)
                                Text(binding?.display() ?: "Sem atalho personalizado", fontSize = 11.sp, color = theme.gutterText)
                            }
                            RightClickableTextButton(onClick = { captureShortcutHint = "Pressione a combinação para: ${action.label}"; captureShortcutFor = action.id }) { Text("Definir", fontSize = 12.sp) }
                            if (binding != null) RightClickableTextButton(onClick = {
                                customShortcuts = customShortcuts.filterNot { it.actionId == action.id }
                                CustomShortcutStore.save(ctx, customShortcuts)
                            }) { Text("Limpar", fontSize = 12.sp) }
                        }
                    }
                }
            }
        },
        confirmButton = { RightClickableTextButton(onClick = { showShortcutSettings = false }) { Text("Fechar") } },
        dismissButton = { RightClickableTextButton(onClick = {
            customShortcuts = emptyList()
            CustomShortcutStore.save(ctx, customShortcuts)
            toast("Atalhos personalizados removidos")
        }) { Text("Limpar todos") } }
    )

    if (captureShortcutFor != null) {
        val action = ShortcutCatalog.actions.firstOrNull { it.id == captureShortcutFor }
        AlertDialog(
            onDismissRequest = { captureShortcutFor = null },
            title = { Text("Definir atalho") },
            text = {
                Column {
                    Text(captureShortcutHint, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = "Pressione as teclas…",
                        onValueChange = {},
                        readOnly = true,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().focusRequester(shortcutCaptureFocus).onPreviewKeyEvent { event ->
                            if (captureShortcutFor == null) return@onPreviewKeyEvent false
                            if (event.type != androidx.compose.ui.input.key.KeyEventType.KeyDown) return@onPreviewKeyEvent true
                            val nativeCode = event.key.nativeKeyCode
                            if (nativeCode == NativeKeyEvent.KEYCODE_ESCAPE) {
                                captureShortcutFor = null
                                return@onPreviewKeyEvent true
                            }
                            if (nativeCode in setOf(NativeKeyEvent.KEYCODE_SHIFT_LEFT, NativeKeyEvent.KEYCODE_SHIFT_RIGHT, NativeKeyEvent.KEYCODE_CTRL_LEFT, NativeKeyEvent.KEYCODE_CTRL_RIGHT, NativeKeyEvent.KEYCODE_ALT_LEFT, NativeKeyEvent.KEYCODE_ALT_RIGHT, NativeKeyEvent.KEYCODE_META_LEFT, NativeKeyEvent.KEYCODE_META_RIGHT)) {
                                captureShortcutHint = "Modificadores detectados. Agora pressione a tecla principal."
                                return@onPreviewKeyEvent true
                            }
                            if (nativeCode != NativeKeyEvent.KEYCODE_UNKNOWN) {
                                commitCustomShortcut(captureShortcutFor!!, nativeCode, event.isCtrlPressed, event.isAltPressed, event.isShiftPressed, event.isMetaPressed)
                            }
                            true
                        }
                    )
                    Text("Exemplo: Ctrl+Shift+R, Alt+M ou F6. Escape cancela.", fontSize = 11.sp, color = theme.gutterText, modifier = Modifier.padding(top = 6.dp))
                }
            },
            confirmButton = { RightClickableTextButton(onClick = { captureShortcutFor = null }) { Text("Cancelar") } },
            dismissButton = { RightClickableTextButton(onClick = {
                captureShortcutFor?.let { id ->
                    customShortcuts = customShortcuts.filterNot { it.actionId == id }
                    CustomShortcutStore.save(ctx, customShortcuts)
                }
                captureShortcutFor = null
            }) { Text("Remover atalho") } },
        )
    }


}

// ============================================================ painel de diagnósticos
@Composable
private fun DiagnosticsBanner(
    diags: List<Diagnostic>, active: Diagnostic?, theme: CodeTheme,
    expanded: Boolean, onToggle: () -> Unit,
    onJump: (Diagnostic) -> Unit, onFix: (QuickFix) -> Unit
) {
    if (active == null) {
        Text("✓ Sem erros de sintaxe", Modifier.fillMaxWidth().background(theme.bar).padding(horizontal = 10.dp, vertical = 4.dp),
            color = theme.function, fontSize = 12.sp)
        return
    }
    Column(Modifier.fillMaxWidth().background(theme.bar)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable { onJump(active) }) {
                Text("${active.kind} · linha ${active.line}, coluna ${active.column}", color = theme.error, fontSize = 11.sp)
                Text(active.message, color = theme.text, fontSize = 13.sp)
                active.suggestion?.let { Text("💡 $it", color = theme.string, fontSize = 12.sp) }
            }
            active.fix?.let { f -> Btn("Aplicar", theme, theme.function) { onFix(f) } }
            if (diags.size > 1) Btn("${diags.size}", theme, theme.error) { onToggle() }
        }
        if (expanded && diags.size > 1) Column(Modifier.heightIn(max = 140.dp).verticalScroll(rememberScrollState())) {
            diags.forEach { d ->
                Text("L${d.line}:${d.column}  ${d.message}", Modifier.fillMaxWidth().clickable { onJump(d) }.padding(horizontal = 12.dp, vertical = 5.dp),
                    color = theme.text, fontSize = 12.sp)
            }
        }
    }
}

// ============================================================ console de terminal
@Composable
private fun DebugPanel(theme: CodeTheme, family: FontFamily, fontSize: Float, p: PyPause, modifier: Modifier = Modifier) {
    Column(modifier.background(Color(0xFF1B1B26))) {
        Row(Modifier.fillMaxWidth().background(theme.bar), verticalAlignment = Alignment.CenterVertically) {
            Text("⏸ Pausado na linha ${p.line}", Modifier.weight(1f).padding(start = 10.dp), color = Color(0xFFFFD43B), fontSize = 12.sp)
            Btn("▶ Continuar", theme, theme.function) { PyRunner.debugContinue() }
            Btn("↧ Passo", theme) { PyRunner.debugStep() }
            Btn("■ Parar", theme, theme.error) { PyRunner.stop() }
        }
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 170.dp).padding(horizontal = 10.dp, vertical = 4.dp)) {
            if (p.vars.isEmpty()) item { Text("(sem variáveis)", color = theme.comment, fontSize = 12.sp) }
            items(p.vars) { v ->
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = theme.function)) { append(v.first) }
                        withStyle(SpanStyle(color = theme.comment)) { append("  ${v.second} = ") }
                        withStyle(SpanStyle(color = theme.text)) { append(v.third) }
                    },
                    fontFamily = family, fontSize = (fontSize - 2f).coerceAtLeast(9f).sp
                )
            }
        }
    }
}

@Composable
private fun ConsolePanel(
    theme: CodeTheme, family: FontFamily, fontSize: Float,
    big: Boolean, onToggleBig: () -> Unit, onClose: () -> Unit, onRerun: () -> Unit, modifier: Modifier
) {
    val chunks by PyRunner.chunks.collectAsState()
    val state by PyRunner.state.collectAsState()
    val prompt by PyRunner.prompt.collectAsState()
    val stuck by PyRunner.stuck.collectAsState()
    val missingExternalPackage by PyRunner.missingExternalPackage.collectAsState()
    val replMode by PyRunner.replMode.collectAsState()
    val replMore by PyRunner.replMore.collectAsState()
    val running = state != RunState.IDLE
    var input by remember { mutableStateOf("") }
    val inputFocus = remember { FocusRequester() }
    var confirmKill by remember { mutableStateOf(false) }
    val clip = LocalClipboardManager.current
    val cctx = LocalContext.current

    val annotated = remember(chunks, theme) {
        var budget = 20_000
        val parts = ArrayList<ConsoleChunk>()
        for (c in chunks.asReversed()) {
            if (budget <= 0) break
            if (c.text.length <= budget) { parts += c; budget -= c.text.length } else { parts += c.copy(text = c.text.takeLast(budget)); budget = 0 }
        }
        parts.reverse()
        buildAnnotatedString {
            if (chunks.sumOf { it.text.length } > 20_000) append("…\n")
            parts.forEach {
                val col = when (it.kind) {
                    StreamKind.OUT -> theme.text; StreamKind.ERR -> theme.error; StreamKind.IN -> theme.string; StreamKind.SYS -> theme.comment
                }
                if (it.kind == StreamKind.OUT || it.kind == StreamKind.ERR) appendAnsi(it.text, col)
                else withStyle(SpanStyle(color = col)) { append(cleanConsole(it.text)) }
            }
        }
    }
    LaunchedEffect(prompt != null) { if (prompt != null) runCatching { inputFocus.requestFocus() } }

    fun send() {
        if (prompt != null) { PyRunner.sendInput(input); input = "" }
        else if (replMode && !running) { PyRunner.replSubmit(cctx, input); input = "" }
    }

    Column(modifier.background(Color(0xFF111111))) {
        Row(Modifier.fillMaxWidth().background(theme.bar), verticalAlignment = Alignment.CenterVertically) {
            Text(
                when (state) {
                    RunState.IDLE -> if (replMode) "Terminal Python" else "Console"; RunState.STARTING -> "Console · iniciando Python…"
                    RunState.RUNNING -> "Console · executando"; RunState.WAITING_INPUT -> "Console · aguardando input()"
                    RunState.STOPPING -> "Console · parando…"
                },
                Modifier.padding(start = 10.dp, end = 4.dp), color = theme.text, fontSize = 12.sp, maxLines = 1, softWrap = false
            )
            // botões rolam na horizontal: o título não é mais espremido (antes quebrava letra por letra e alargava o cabeçalho)
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            if (running) Btn("■ Parar", theme, theme.error) { PyRunner.stop() } else Btn("↻ Repetir", theme, theme.function) { onRerun() }
            if (stuck) Btn("Forçar encerramento", theme, theme.error) { confirmKill = true }
            Btn(if (replMode) "Terminal ✓" else "Terminal", theme, if (replMode) theme.function else theme.text) { PyRunner.setRepl(!replMode) }
            if (replMode) Btn("Reiniciar", theme) { PyRunner.resetRepl() }
            Btn("Copiar", theme) {
                clip.setText(AnnotatedString(ANSI_ANY.replace(chunks.joinToString("") { it.text }, "")))
                Toast.makeText(cctx, "Console copiado", Toast.LENGTH_SHORT).show()
            }
            Btn("Limpar", theme) { PyRunner.clearConsole() }
            Btn(if (big) "⤡" else "⤢", theme) { onToggleBig() }
            Btn("✕", theme) { onClose() }
            }
        }
        if (missingExternalPackage != null) {
            Row(
                Modifier.fillMaxWidth().background(theme.bar).padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Falta o módulo ${missingExternalPackage}", Modifier.weight(1f), color = theme.error, fontSize = 12.sp)
                Btn("Instalar ${missingExternalPackage}", theme, theme.function) {
                    val pkg = missingExternalPackage
                    if (pkg != null) {
                        TermuxX11Runner.installPythonPackage(cctx, pkg).onSuccess {
                            PyRunner.dismissMissingExternalPackage()
                            Toast.makeText(cctx, "Instalação enviada ao Termux; acompanhe a sessão aberta.", Toast.LENGTH_LONG).show()
                        }.onFailure { Toast.makeText(cctx, "Não consegui iniciar a instalação: ${it.message}", Toast.LENGTH_LONG).show() }
                    }
                }
                Btn("×", theme) { PyRunner.dismissMissingExternalPackage() }
            }
        }
        val sc = rememberScrollState()
        LaunchedEffect(annotated, sc.maxValue) { sc.scrollTo(sc.maxValue) }
        Text(
            annotated,
            Modifier.weight(1f).fillMaxWidth().verticalScroll(sc).padding(8.dp),
            fontFamily = family, fontSize = (fontSize - 1f).coerceAtLeast(9f).sp, lineHeight = ((fontSize - 1f) * 1.35f).sp
        )
        if (running || replMode) Row(Modifier.fillMaxWidth().background(theme.bar).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (prompt != null) "▸" else if (replMode && !running) (if (replMore) "..." else ">>>") else "…", color = theme.string, fontFamily = family, modifier = Modifier.padding(horizontal = 6.dp))
            BasicTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f).padding(vertical = 8.dp).focusRequester(inputFocus),
                singleLine = true,
                textStyle = TextStyle(color = theme.text, fontFamily = family, fontSize = fontSize.sp),
                cursorBrush = SolidColor(theme.cursor),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send, autoCorrectEnabled = false),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            Btn("Enviar", theme, theme.function) { send() }
            if (running) Btn("EOF", theme) { PyRunner.sendEof() }
        }
    }
    if (confirmKill) AlertDialog(
        onDismissRequest = { confirmKill = false },
        title = { Text("Forçar encerramento?") },
        text = { Text("O Python roda dentro do app, então isso fecha o app inteiro. Arquivos com auto-save já estão gravados; reabra o app depois.") },
        confirmButton = { RightClickableTextButton({ PyRunner.forceKill() }) { Text("Encerrar") } },
        dismissButton = { RightClickableTextButton({ confirmKill = false }) { Text("Cancelar") } }
    )
}

@Composable
private fun Btn(label: String, theme: CodeTheme, color: Color = theme.text, onClick: () -> Unit) =
    RightClickableTextButton(onClick, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) { Text(label, fontSize = 12.sp, color = color) }
