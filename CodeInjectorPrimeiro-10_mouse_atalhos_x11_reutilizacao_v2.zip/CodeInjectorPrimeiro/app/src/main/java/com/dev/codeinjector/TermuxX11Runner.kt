package com.dev.codeinjector

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.util.Base64
import java.util.UUID

/** Execução gráfica fora do Chaquopy. O código não é mais transportado dentro do Intent. */
object TermuxX11Runner {
    const val TERMUX_PACKAGE = "com.termux"
    const val X11_PACKAGE = "com.termux.x11"
    const val RUN_ID_EXTRA = "com.dev.codeinjector.extra.TERMUX_RUN_ID"
    const val X11_DISPLAY = ":1"
    private const val RUN_COMMAND_ACTION = "com.termux.RUN_COMMAND"
    private const val RUN_COMMAND_SERVICE = "com.termux.app.RunCommandService"
    private const val EXTRA_PATH = "com.termux.RUN_COMMAND_PATH"
    private const val EXTRA_ARGUMENTS = "com.termux.RUN_COMMAND_ARGUMENTS"
    private const val EXTRA_WORKDIR = "com.termux.RUN_COMMAND_WORKDIR"
    private const val EXTRA_BACKGROUND = "com.termux.RUN_COMMAND_BACKGROUND"
    private const val EXTRA_SESSION_ACTION = "com.termux.RUN_COMMAND_SESSION_ACTION"
    private const val EXTRA_LABEL = "com.termux.RUN_COMMAND_COMMAND_LABEL"
    private const val EXTRA_DESCRIPTION = "com.termux.RUN_COMMAND_COMMAND_DESCRIPTION"
    private const val EXTRA_PENDING_INTENT = "com.termux.RUN_COMMAND_PENDING_INTENT"

    data class LaunchResult(
        val runId: String,
        val framework: String,
        val scriptPath: String,
        val mainRelativePath: String,
        val stdoutUri: Uri,
        val stderrUri: Uri,
        val isDirectProject: Boolean,
    )

    private data class FrameworkSpec(
        val id: String, val label: String, val module: String,
        val prootAptPackage: String? = null,
    )

    private val frameworks = mapOf(
        "kivy" to FrameworkSpec("kivy", "Kivy", "kivy", "python3-kivy"),
        "pygame" to FrameworkSpec("pygame", "Pygame", "pygame", "python3-pygame"),
        "tkinter" to FrameworkSpec("tkinter", "Tkinter", "tkinter", "python3-tk"),
        "pyglet" to FrameworkSpec("pyglet", "Pyglet", "pyglet", "python3-pyglet"),
        "arcade" to FrameworkSpec("arcade", "Arcade", "arcade", null),
        "pyqt5" to FrameworkSpec("pyqt5", "PyQt5", "PyQt5", "python3-pyqt5"),
        "pyqt6" to FrameworkSpec("pyqt6", "PyQt6", "PyQt6", "python3-pyqt6"),
        "pyside2" to FrameworkSpec("pyside2", "PySide2", "PySide2", null),
        "pyside6" to FrameworkSpec("pyside6", "PySide6", "PySide6", "python3-pyside6.qtwidgets"),
    )

    private val PROOT_RUNNER_SCRIPT = """#!/bin/sh
set -u
FRAMEWORK_ID="${'$'}{1:?identificador do framework ausente}"
FRAMEWORK_MODULE="${'$'}{2:?módulo gráfico ausente}"
MAIN_REL="${'$'}{3:?arquivo Python ausente}"
LIBGL_MODE="${'$'}{4:-auto}"
export DISPLAY=:1
# Deixe o Mesa escolher o driver disponível. Renderização por software é fallback opcional.
if [ "${'$'}LIBGL_MODE" = "software" ]; then
  export LIBGL_ALWAYS_SOFTWARE=true
else
  unset LIBGL_ALWAYS_SOFTWARE
fi
export SDL_VIDEODRIVER=x11
export PYGAME_HIDE_SUPPORT_PROMPT=1
export PYTHONUNBUFFERED=1
export PYTHONDONTWRITEBYTECODE=1
export KIVY_NO_FILELOG=1
export PYTHONPATH=/tmp/codeinjector-project${'$'}{PYTHONPATH:+:${'$'}PYTHONPATH}
cd /tmp/codeinjector-project || exit 2
# Evita iniciar um segundo interpretador só para verificar o import. Se faltar um
# módulo, o traceback da execução é lido pela IDE e oferece a instalação correspondente.
exec python3 -u "/tmp/codeinjector-project/${'$'}MAIN_REL"
"""

    fun detectFramework(source: String): String? = PythonFrameworkDetector.detect(source)

    /**
     * Decide o executor somente pelos imports do arquivo que o usuário mandou executar.
     * Não varre abas vizinhas nem todos os arquivos da pasta: um exemplo Kivy/Pygame salvo
     * no mesmo projeto não pode redirecionar um script comum (por exemplo, input/print).
     * Scripts gráficos normalmente declaram o framework por um import no arquivo principal.
     */
    @Suppress("UNUSED_PARAMETER")
    fun detectProjectFramework(
        context: Context,
        source: String,
        fileName: String,
        siblings: Map<String, String>,
        input: TermuxProjectInput?,
    ): String? = detectFramework(source)

    fun frameworkLabel(id: String): String = frameworks[id]?.label ?: id

    fun packageForMissingModule(module: String): String? {
        val norm = module.trim().trim('"', '\'').substringBefore('.').lowercase()
        return when (norm) {
            "pyqt5" -> "pyqt5"
            "pyqt6" -> "pyqt6"
            "pyside2" -> "pyside2"
            "pyside6" -> "pyside6"
            "tkinter" -> "tkinter"
            else -> norm.takeIf { it in frameworks }
        }
    }

    fun launch(
        context: Context,
        source: String,
        fileName: String,
        siblings: Map<String, String>,
        framework: String,
        runId: String,
        projectInput: TermuxProjectInput? = null,
    ): Result<LaunchResult> = runCatching {
        val app = context.applicationContext
        val spec = frameworks[framework] ?: error("Framework gráfico não suportado: $framework")
        check(runId.matches(Regex("[A-Za-z0-9_-]{1,64}"))) { "Identificador de execução inválido." }
        check(isInstalled(app, TERMUX_PACKAGE)) {
            "Termux não está instalado. Instale o Termux e abra-o uma vez antes de executar scripts gráficos."
        }
        check(isInstalled(app, X11_PACKAGE)) {
            "O aplicativo Termux:X11 não foi encontrado. Instale o APK do Termux:X11 e o pacote termux-x11-nightly no Termux."
        }
        checkRunCommandPermission(app)

        val workspace = TermuxWorkspace.prepare(app, projectInput, runId, fileName, source, siblings)
        val prootRunnerEncoded = Base64.encodeToString(PROOT_RUNNER_SCRIPT.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val scriptPathQ = shellQuote(workspace.mainScriptPath)
        val workDirQ = shellQuote(workspace.workDirPath)
        val runDirQ = shellQuote(workspace.runDirPath)
        val relativeQ = shellQuote(workspace.mainRelativePath)
        val moduleQ = shellQuote(spec.module)
        val frameworkIdQ = shellQuote(spec.id)
        val label = spec.label
        val appRunIdQ = shellQuote(runId)
        val stdoutQ = shellQuote("${workspace.runDirPath}/stdout.log")
        val stderrQ = shellQuote("${workspace.runDirPath}/stderr.log")
        val prootQ = shellQuote("${workspace.runDirPath}/ci-proot-runner.sh")
        val shell = """
            set +e
            mkdir -p "${'$'}HOME/.codeinjector/pids" "${'$'}HOME/.codeinjector"
            RUN_DIR=$runDirQ
            PROJECT_PATH=$workDirQ
            SCRIPT_PATH=$scriptPathQ
            MAIN_REL=$relativeQ
            FRAMEWORK_ID=$frameworkIdQ
            FRAMEWORK_MODULE=$moduleQ
            PID_FILE="${'$'}HOME/.codeinjector/pids/$runId.pid"
            OUT_LOG=$stdoutQ
            ERR_LOG=$stderrQ
            PROOT_SCRIPT=$prootQ
            APP_RUN_ID=$appRunIdQ
            mkdir -p "${'$'}RUN_DIR"
            : > "${'$'}OUT_LOG"; : > "${'$'}ERR_LOG"

            # Termine o script gráfico anterior, sem encerrar o servidor X11 persistente.
            OLD_PID_FILE="${'$'}HOME/.codeinjector/active.pid"
            if [ -f "${'$'}OLD_PID_FILE" ]; then
              OLD_PID="${'$'}(cat "${'$'}OLD_PID_FILE" 2>/dev/null || true)"
              if [ -n "${'$'}OLD_PID" ] && kill -0 "${'$'}OLD_PID" 2>/dev/null; then
                if grep -zaq "CODEINJECTOR_RUN_ID=" /proc/"${'$'}OLD_PID"/environ 2>/dev/null; then
                  kill -TERM -- "-${'$'}OLD_PID" 2>/dev/null || kill -TERM "${'$'}OLD_PID" 2>/dev/null || true
                  sleep 0.25
                  kill -KILL -- "-${'$'}OLD_PID" 2>/dev/null || kill -KILL "${'$'}OLD_PID" 2>/dev/null || true
                fi
              fi
            fi

            # Verifica configuração opcional de PRoot.
            CODEINJECTOR_PROOT_DISTRO=""
            CODEINJECTOR_LIBGL_MODE="auto"
            CONFIG_FILE="${'$'}HOME/.codeinjector/termux-x11.conf"
            if [ -f "${'$'}CONFIG_FILE" ]; then . "${'$'}CONFIG_FILE"; fi
            case "${'$'}CODEINJECTOR_LIBGL_MODE" in
              auto|software) export CODEINJECTOR_LIBGL_MODE ;;
              *) echo "[CodeInjector] CODEINJECTOR_LIBGL_MODE inválido em ${'$'}CONFIG_FILE (use auto ou software)." >&2; exit 2 ;;
            esac
            if [ -n "${'$'}CODEINJECTOR_PROOT_DISTRO" ]; then
              case "${'$'}CODEINJECTOR_PROOT_DISTRO" in *[!a-zA-Z0-9_-]*) echo "[CodeInjector] CODEINJECTOR_PROOT_DISTRO inválido em ${'$'}CONFIG_FILE." >&2; exit 2 ;; esac
              if ! command -v proot-distro >/dev/null 2>&1; then
                echo "[CodeInjector] Falta proot-distro. Execute: pkg install proot-distro" >&2; exit 127
              fi
            fi

            # O servidor X11 fica vivo entre execuções para acelerar o próximo início.
            if ! command -v termux-x11 >/dev/null 2>&1; then
              echo "[CodeInjector] Falta o pacote Termux:X11. Execute: pkg install x11-repo && pkg install termux-x11-nightly" >&2; exit 127
            fi
            export DISPLAY=:1
            export SDL_VIDEODRIVER=x11
            export PYGAME_HIDE_SUPPORT_PROMPT=1
            export PYTHONUNBUFFERED=1
            # Procure sockets/locks nos diretórios usados pelo Termux, sem presumir que
            # o PID salvo pelo launcher anterior seja o PID real do servidor X11.
            # O PID de nohup pode morrer enquanto o X server continua ativo; apagar o
            # socket com base nesse PID causa exatamente o conflito ao executar de novo.
            X11_BASE_TMP="${'$'}{TMPDIR:-${'$'}PREFIX/tmp}"
            X11_SOCKET=""
            X11_LOCK=""
            X11_LOCK_PID=""
            X11_LOCK_ACTIVE=0
            X11_SERVER_PID=""
            X11_ACTIVITY_OPENED=0
            find_x11_server_process() {
              # O servidor real pode sobreviver ao processo auxiliar retornado por nohup.
              # Procure pelo nome real do processo e confirme que ele usa o display :1.
              X11_SERVER_PID=""
              if command -v pgrep >/dev/null 2>&1; then
                for X11_PID_CANDIDATE in ${'$'}(pgrep -x termux-x11 2>/dev/null || true); do
                  X11_ARGS="${'$'}(tr '\000' ' ' < /proc/"${'$'}X11_PID_CANDIDATE"/cmdline 2>/dev/null || true)"
                  case " ${'$'}X11_ARGS " in
                    *" :1 "*) X11_SERVER_PID="${'$'}X11_PID_CANDIDATE"; return 0 ;;
                  esac
                done
              fi
              # Fallback para instalações sem pgrep (ex.: procps não instalado).
              for X11_PROC_DIR in /proc/[0-9]*; do
                [ -r "${'$'}X11_PROC_DIR/comm" ] || continue
                IFS= read -r X11_PROC_NAME < "${'$'}X11_PROC_DIR/comm" || true
                [ "${'$'}X11_PROC_NAME" = "termux-x11" ] || continue
                X11_PID_CANDIDATE="${'$'}{X11_PROC_DIR##*/}"
                X11_ARGS="${'$'}(tr '\000' ' ' < "${'$'}X11_PROC_DIR/cmdline" 2>/dev/null || true)"
                case " ${'$'}X11_ARGS " in
                  *" :1 "*) X11_SERVER_PID="${'$'}X11_PID_CANDIDATE"; return 0 ;;
                esac
              done
              return 1
            }
            find_x11_socket() {
              X11_SOCKET=""
              for X11_CANDIDATE in "${'$'}X11_BASE_TMP/.X11-unix/X1" "${'$'}PREFIX/tmp/.X11-unix/X1" "${'$'}HOME/.X11-unix/X1" "/tmp/.X11-unix/X1"; do
                if [ -S "${'$'}X11_CANDIDATE" ]; then X11_SOCKET="${'$'}X11_CANDIDATE"; return 0; fi
              done
              return 1
            }
            find_x11_lock() {
              X11_LOCK=""
              for X11_CANDIDATE in "${'$'}X11_BASE_TMP/.X1-lock" "${'$'}PREFIX/tmp/.X1-lock" "${'$'}HOME/.X1-lock" "/tmp/.X1-lock"; do
                if [ -f "${'$'}X11_CANDIDATE" ]; then X11_LOCK="${'$'}X11_CANDIDATE"; return 0; fi
              done
              return 1
            }
            refresh_x11_state() {
              find_x11_socket || true
              find_x11_lock || true
              find_x11_server_process || true
              X11_LOCK_PID=""
              X11_LOCK_ACTIVE=0
              if [ -n "${'$'}X11_LOCK" ]; then
                X11_LOCK_PID="${'$'}(tr -cd '0-9' < "${'$'}X11_LOCK" 2>/dev/null || true)"
                case "${'$'}X11_LOCK_PID" in ''|*[!0-9]*) X11_LOCK_PID="" ;; esac
                if [ -n "${'$'}X11_LOCK_PID" ] && kill -0 "${'$'}X11_LOCK_PID" 2>/dev/null; then
                  X11_LOCK_ACTIVE=1
                elif [ -z "${'$'}X11_SOCKET" ]; then
                  # Só remova lock comprovadamente obsoleto; nunca apague um socket ativo
                  # por causa do PID auxiliar guardado pelo launcher.
                  rm -f "${'$'}X11_LOCK"
                  X11_LOCK=""
                fi
              fi
            }
            wait_for_existing_x11() {
              if [ "${'$'}X11_ACTIVITY_OPENED" -eq 0 ] && command -v am >/dev/null 2>&1; then
                am start --user 0 -n com.termux.x11/com.termux.x11.MainActivity >/dev/null 2>&1 || am start -n com.termux.x11/com.termux.x11.MainActivity >/dev/null 2>&1 || true
                X11_ACTIVITY_OPENED=1
              fi
              X11_WAIT=0
              while [ "${'$'}X11_WAIT" -lt 200 ]; do
                if find_x11_socket; then return 0; fi
                # Se o processo do display já existe, não lance outro servidor.
                if find_x11_server_process; then return 0; fi
                sleep 0.1
                X11_WAIT=${'$'}((X11_WAIT + 1))
              done
              return 1
            }
            start_x11_and_wait() {
              LOG_FILE="${'$'}1"; shift
              # O PID retornado por setsid pode ser um processo intermediário que sai logo;
              # nohup mantém a execução em segundo plano e o log habilita diagnóstico oficial.
              nohup env TERMUX_X11_DEBUG=1 "${'$'}@" > "${'$'}LOG_FILE" 2>&1 < /dev/null &
              X11_PID=${'$'}!
              # Inicie o servidor primeiro e abra a Activity imediatamente depois, antes do
              # polling: o Termux:X11 precisa da interface Android para apresentar a janela.
              if [ "${'$'}X11_ACTIVITY_OPENED" -eq 0 ]; then
                if command -v am >/dev/null 2>&1; then
                  am start --user 0 -n com.termux.x11/com.termux.x11.MainActivity >/dev/null 2>&1 || am start -n com.termux.x11/com.termux.x11.MainActivity >/dev/null 2>&1 || echo "[CodeInjector] Não consegui abrir Termux:X11 automaticamente; abra-o manualmente." >&2
                  X11_ACTIVITY_OPENED=1
                  # A verificação do socket sincroniza a inicialização, sem espera fixa de 1 s.
                else echo "[CodeInjector] Não encontrei o comando am. Abra Termux:X11 manualmente." >&2; fi
              fi
              ATTEMPT=0
              while [ "${'$'}ATTEMPT" -lt 200 ]; do
                if find_x11_socket; then return 0; fi
                if ! kill -0 "${'$'}X11_PID" 2>/dev/null; then break; fi
                sleep 0.1; ATTEMPT=${'$'}((ATTEMPT + 1))
              done
              # Não deixe uma tentativa fracassada concorrendo com o fallback legado.
              if kill -0 "${'$'}X11_PID" 2>/dev/null; then
                kill -TERM "${'$'}X11_PID" 2>/dev/null || true
                sleep 0.3
                kill -KILL "${'$'}X11_PID" 2>/dev/null || true
              fi
              return 1
            }
            ensure_x11() {
              refresh_x11_state
              if [ -n "${'$'}X11_SOCKET" ]; then return 0; fi
              # O processo real é uma segunda fonte de verdade: o PID do nohup pode
              # desaparecer e o socket pode estar fora dos caminhos mais comuns.
              # Reutilize o display :1 em vez de criar uma segunda instância concorrente.
              if [ -n "${'$'}X11_SERVER_PID" ]; then
                wait_for_existing_x11 || true
                echo "[CodeInjector] Reutilizando o servidor Termux:X11 existente no display :1 (PID ${'$'}X11_SERVER_PID)." >&2
                return 0
              fi
              # Um lock com PID vivo indica que o display pertence a um servidor já
              # iniciado. Aguarde/reutilize-o; não tente abrir outro nem mesmo no fallback.
              if [ "${'$'}X11_LOCK_ACTIVE" -eq 1 ]; then
                if wait_for_existing_x11; then return 0; fi
                echo "[CodeInjector] O display :1 já está ocupado pelo PID ${'$'}X11_LOCK_PID, mas o socket X11 não ficou acessível. Não iniciei outro servidor para evitar conflito." >&2
                return 1
              fi
              if start_x11_and_wait "${'$'}RUN_DIR/termux-x11.log" termux-x11 :1; then return 0; fi
              refresh_x11_state
              if [ -n "${'$'}X11_SOCKET" ]; then return 0; fi
              if [ -n "${'$'}X11_SERVER_PID" ]; then
                wait_for_existing_x11 || true
                echo "[CodeInjector] O servidor Termux:X11 iniciado continuou ativo (PID ${'$'}X11_SERVER_PID); reutilizando :1 em vez de abrir outro." >&2
                return 0
              fi
              if [ "${'$'}X11_LOCK_ACTIVE" -eq 1 ]; then
                if wait_for_existing_x11; then return 0; fi
                echo "[CodeInjector] O display :1 ficou ocupado durante a inicialização, mas o socket não está acessível. Não iniciei outro servidor." >&2
                return 1
              fi
              if start_x11_and_wait "${'$'}RUN_DIR/termux-x11-legacy.log" termux-x11 :1 -legacy-drawing; then return 0; fi
              refresh_x11_state
              if [ -n "${'$'}X11_SOCKET" ]; then return 0; fi
              if [ -n "${'$'}X11_SERVER_PID" ]; then
                wait_for_existing_x11 || true
                echo "[CodeInjector] O servidor Termux:X11 está ativo (PID ${'$'}X11_SERVER_PID); não vou iniciar outra instância." >&2
                return 0
              fi
              if [ "${'$'}X11_LOCK_ACTIVE" -eq 1 ]; then
                if wait_for_existing_x11; then return 0; fi
                echo "[CodeInjector] O display :1 já está ocupado, mas não foi possível alcançar o socket X11." >&2
              fi
              return 1
            }
            if ! ensure_x11; then
              echo "[CodeInjector] O servidor X11 não ficou acessível no display :1. Logs do servidor:" >&2
              for DIAG_LOG in "${'$'}RUN_DIR/termux-x11.log" "${'$'}RUN_DIR/termux-x11-legacy.log"; do
                if [ -s "${'$'}DIAG_LOG" ]; then
                  echo "--- ${'$'}DIAG_LOG ---" >&2
                  tail -n 60 "${'$'}DIAG_LOG" >&2
                fi
              done
              if [ "${'$'}X11_LOCK_ACTIVE" -eq 1 ]; then
                echo "[CodeInjector] Feche e abra o Termux:X11 ou reinicie o servidor antigo; depois tente executar o script novamente." >&2
              else
                echo "[CodeInjector] Confirme que o APK Termux:X11 e o pacote termux-x11-nightly são da mesma instalação/origem." >&2
              fi
              exit 1
            fi
            # Se o servidor ficou ativo, mas a Activity foi fechada/posta em segundo plano,
            # traga o Termux:X11 à frente sem reiniciar o servidor persistente.
            if [ "${'$'}X11_ACTIVITY_OPENED" -eq 0 ] && command -v am >/dev/null 2>&1; then
              am start --user 0 -n com.termux.x11/com.termux.x11.MainActivity >/dev/null 2>&1 || am start -n com.termux.x11/com.termux.x11.MainActivity >/dev/null 2>&1 || true
            fi

            echo "[CodeInjector] Executando $label em Termux:X11 (DISPLAY=:1)."
            echo "[CodeInjector] Projeto: ${'$'}PROJECT_PATH"
            echo "[CodeInjector] Script: ${'$'}SCRIPT_PATH"

            PYTHON=""
            if [ -x "${'$'}HOME/kv/bin/python" ]; then PYTHON="${'$'}HOME/kv/bin/python"
            elif command -v python >/dev/null 2>&1; then PYTHON="${'$'}(command -v python)"
            elif command -v python3 >/dev/null 2>&1; then PYTHON="${'$'}(command -v python3)"
            fi

            if [ -z "${'$'}CODEINJECTOR_PROOT_DISTRO" ]; then
              if [ -z "${'$'}PYTHON" ]; then echo "[CodeInjector] Python ausente. Execute: pkg install python" >&2; exit 127; fi
              # Evita uma inicialização extra do Python só para verificar o módulo.
              # Um ModuleNotFoundError real é detectado pelo parser de logs da IDE.
              cd "${'$'}PROJECT_PATH" || { echo "[CodeInjector] Não consegui entrar na pasta do projeto: ${'$'}PROJECT_PATH" >&2; exit 2; }
              export PROJECT_PATH
              export PYTHONPATH="${'$'}PROJECT_PATH${'$'}{PYTHONPATH:+:${'$'}PYTHONPATH}"
              mkdir -p "${'$'}(dirname "${'$'}PID_FILE")"
              CODEINJECTOR_RUN_ID="${'$'}APP_RUN_ID" setsid bash -c 'echo "${'$'}${'$'}" > "${'$'}1"; echo "${'$'}${'$'}" > "${'$'}2"; shift 2; export DISPLAY=:1 SDL_VIDEODRIVER=x11 PYGAME_HIDE_SUPPORT_PROMPT=1 PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 KIVY_NO_FILELOG=1 PYTHONPATH="${'$'}PROJECT_PATH${'$'}{PYTHONPATH:+:${'$'}PYTHONPATH}"; if [ "${'$'}CODEINJECTOR_LIBGL_MODE" = "software" ]; then export LIBGL_ALWAYS_SOFTWARE=true; else unset LIBGL_ALWAYS_SOFTWARE; fi; exec "${'$'}@"' _ "${'$'}PID_FILE" "${'$'}HOME/.codeinjector/active.pid" "${'$'}PYTHON" -u "${'$'}SCRIPT_PATH" > "${'$'}OUT_LOG" 2> "${'$'}ERR_LOG" &
              APP_PID=${'$'}!
              # Aguarda a criação do PID do grupo independente antes de liberar Parar.
              N=0; while [ ! -s "${'$'}PID_FILE" ] && [ "${'$'}N" -lt 30 ]; do sleep 0.1; N=${'$'}((N+1)); done
              wait "${'$'}APP_PID"; CODE=${'$'}?
            else
              printf '%s' '$prootRunnerEncoded' | base64 -d > "${'$'}PROOT_SCRIPT"
              chmod 700 "${'$'}PROOT_SCRIPT"
              mkdir -p "${'$'}(dirname "${'$'}PID_FILE")"
              CODEINJECTOR_RUN_ID="${'$'}APP_RUN_ID" setsid bash -c 'echo "${'$'}${'$'}" > "${'$'}1"; echo "${'$'}${'$'}" > "${'$'}2"; shift 2; export PYTHONUNBUFFERED=1; exec proot-distro login "${'$'}1" --shared-tmp --bind "${'$'}2:/tmp/codeinjector-project" --bind "${'$'}3:/tmp/codeinjector-run" -- /bin/sh /tmp/codeinjector-run/ci-proot-runner.sh "${'$'}4" "${'$'}5" "${'$'}6" "${'$'}7"' _ "${'$'}PID_FILE" "${'$'}HOME/.codeinjector/active.pid" "${'$'}CODEINJECTOR_PROOT_DISTRO" "${'$'}PROJECT_PATH" "${'$'}RUN_DIR" "${'$'}FRAMEWORK_ID" "${'$'}FRAMEWORK_MODULE" "${'$'}MAIN_REL" "${'$'}CODEINJECTOR_LIBGL_MODE" > "${'$'}OUT_LOG" 2> "${'$'}ERR_LOG" &
              APP_PID=${'$'}!
              N=0; while [ ! -s "${'$'}PID_FILE" ] && [ "${'$'}N" -lt 30 ]; do sleep 0.1; N=${'$'}((N+1)); done
              wait "${'$'}APP_PID"; CODE=${'$'}?
            fi
            rm -f "${'$'}PID_FILE" "${'$'}HOME/.codeinjector/active.pid"
            echo "[CodeInjector] Programa finalizado com código ${'$'}CODE."
            exit "${'$'}CODE"
        """.trimIndent()

        val callback = resultPendingIntent(app, runId)
        val intent = Intent(RUN_COMMAND_ACTION).apply {
            component = ComponentName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
            putExtra(EXTRA_PATH, "\$PREFIX/bin/bash")
            putExtra(EXTRA_ARGUMENTS, arrayOf("-c", shell))
            putExtra(EXTRA_WORKDIR, "~/")
            putExtra(EXTRA_BACKGROUND, false)
            putExtra(EXTRA_SESSION_ACTION, "0")
            putExtra(EXTRA_LABEL, "CodeInjector · $label")
            putExtra(EXTRA_DESCRIPTION, "Executa $label no Termux:X11 com logs em tempo real na IDE.")
            putExtra(EXTRA_PENDING_INTENT, callback)
        }
        startTermuxService(app, intent)
        LaunchResult(runId, label, workspace.mainScriptPath, workspace.mainRelativePath, workspace.stdoutUri, workspace.stderrUri, workspace.isDirectProject)
    }

    /** Diagnóstico único de instalação, permissões, armazenamento, X11 e módulos Python. */
    fun diagnose(context: Context, diagnosticId: String): Result<Unit> = runCatching {
        val app = context.applicationContext
        check(isInstalled(app, TERMUX_PACKAGE)) { "Termux APK: NÃO INSTALADO. Instale e abra o Termux antes do diagnóstico completo." }
        checkRunCommandPermission(app)
        val x11Installed = isInstalled(app, X11_PACKAGE)
        val shell = """
            echo '=== CodeInjector / Termux ==='
            echo "Termux APK: instalado"
            echo "Termux:X11 APK: ${if (x11Installed) "instalado" else "NAO_INSTALADO"}"
            if [ -f "${'$'}HOME/.termux/termux.properties" ] && grep -Eq '^[[:space:]]*allow-external-apps[[:space:]]*=[[:space:]]*true[[:space:]]*$' "${'$'}HOME/.termux/termux.properties"; then echo 'allow-external-apps: OK'; else echo 'allow-external-apps: FALTA (corrigir com o comando abaixo)'; fi
            if command -v termux-x11 >/dev/null 2>&1; then echo "termux-x11: ${'$'}(command -v termux-x11)"; else echo 'termux-x11: NAO_INSTALADO'; fi
            if command -v python >/dev/null 2>&1; then PY=${'$'}(command -v python); elif command -v python3 >/dev/null 2>&1; then PY=${'$'}(command -v python3); else PY=''; fi
            if [ -n "${'$'}PY" ]; then echo "Python: ${'$'}PY"; ${'$'}PY --version 2>&1; else echo 'Python: NAO_INSTALADO'; fi
            if [ -d "${'$'}HOME/storage/shared" ]; then echo 'Armazenamento compartilhado: OK'; else echo 'Armazenamento compartilhado: falta termux-setup-storage ou permissão Storage'; fi
            if [ -S "${'$'}{TMPDIR:-${'$'}PREFIX/tmp}/.X11-unix/X1" ]; then echo 'Socket X11 :1: ATIVO'; else echo 'Socket X11 :1: parado (normal se nenhum programa gráfico está aberto)'; fi
            if [ -n "${'$'}PY" ]; then
              for M in kivy pygame tkinter pyglet arcade PyQt5 PyQt6 PySide2 PySide6; do
                if "${'$'}PY" -c 'import importlib.util,sys; sys.exit(0 if importlib.util.find_spec(sys.argv[1]) else 1)' "${'$'}M" >/dev/null 2>&1; then echo "Modulo Termux ${'$'}M: OK"; else echo "Modulo Termux ${'$'}M: nao instalado neste Python"; fi
              done
            fi
            CODEINJECTOR_PROOT_DISTRO=""
            CONFIG_FILE="${'$'}HOME/.codeinjector/termux-x11.conf"
            if [ -f "${'$'}CONFIG_FILE" ]; then . "${'$'}CONFIG_FILE"; fi
            if [ -n "${'$'}CODEINJECTOR_PROOT_DISTRO" ]; then
              echo "PRoot configurado: ${'$'}CODEINJECTOR_PROOT_DISTRO"
              if command -v proot-distro >/dev/null 2>&1; then
                proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- python3 -c 'import importlib.util,sys; [print("Modulo PRoot "+m+": "+("OK" if importlib.util.find_spec(m) else "nao instalado")) for m in sys.argv[1:]]' kivy pygame tkinter pyglet arcade PyQt5 PyQt6 PySide2 PySide6 2>&1 || echo 'Falha ao consultar a distro PRoot; confirme que ela está instalada e contém python3.'
              else echo 'PRoot configurado, mas proot-distro não está instalado.'; fi
            else echo 'PRoot: não configurado (usando Python do Termux)'; fi
            echo '=== Comando para corrigir allow-external-apps ==='
            echo "mkdir -p ~/.termux && touch ~/.termux/termux.properties && if grep -Eq '^[[:space:]]*allow-external-apps[[:space:]]*=' ~/.termux/termux.properties; then sed -i -E 's/^[[:space:]]*allow-external-apps[[:space:]]*=.*/allow-external-apps=true/' ~/.termux/termux.properties; else printf '\\nallow-external-apps=true\\n' >> ~/.termux/termux.properties; fi && termux-reload-settings && termux-setup-storage"
        """.trimIndent()
        val callback = resultPendingIntent(app, diagnosticId)
        val intent = Intent(RUN_COMMAND_ACTION).apply {
            component = ComponentName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
            putExtra(EXTRA_PATH, "\$PREFIX/bin/bash")
            putExtra(EXTRA_ARGUMENTS, arrayOf("-c", shell))
            putExtra(EXTRA_WORKDIR, "~/")
            putExtra(EXTRA_BACKGROUND, false)
            putExtra(EXTRA_SESSION_ACTION, "0")
            putExtra(EXTRA_LABEL, "Diagnosticar CodeInjector / Termux:X11")
            putExtra(EXTRA_DESCRIPTION, "Verifica permissões, armazenamento, X11, Python e módulos comuns.")
            putExtra(EXTRA_PENDING_INTENT, callback)
        }
        startTermuxService(app, intent)
    }

    /** Tenta aplicar preferências suportadas pelo utilitário oficial termux-x11-preference. */
    fun applyX11Preferences(context: Context, preferences: Map<String, String>): Result<Unit> = runCatching {
        val app = context.applicationContext
        check(isInstalled(app, TERMUX_PACKAGE)) { "Termux não está instalado." }
        checkRunCommandPermission(app)
        val allowed = setOf("displayResolutionMode", "displayResolutionExact", "displayScale", "adjustResolution", "touchMode", "PIP", "fullscreen")
        check(preferences.isNotEmpty() && preferences.keys.all { it in allowed }) { "Preferência X11 não permitida." }
        check(preferences.all { (key, value) -> value.length <= 80 && '\n' !in value && '\r' !in value }) { "Valor de preferência inválido." }
        val args = preferences.entries.joinToString(" ") { (key, value) -> shellQuote("$key:$value") }
        val shell = "if ! command -v termux-x11-preference >/dev/null 2>&1; then echo 'termux-x11-preference não encontrado; atualize termux-x11-nightly.' >&2; exit 127; fi; termux-x11-preference $args"
        val intent = Intent(RUN_COMMAND_ACTION).apply {
            component = ComponentName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
            putExtra(EXTRA_PATH, "\$PREFIX/bin/bash")
            putExtra(EXTRA_ARGUMENTS, arrayOf("-c", shell))
            putExtra(EXTRA_WORKDIR, "~/")
            putExtra(EXTRA_BACKGROUND, true)
            putExtra(EXTRA_LABEL, "Preferências Termux:X11")
            putExtra(EXTRA_DESCRIPTION, "Aplica as preferências de tela e toque selecionadas no CodeInjector.")
        }
        startTermuxService(app, intent)
    }

    /** Abre o Termux:X11; launchAdjacent apenas solicita a tela dividida ao Android. */
    fun openX11(context: Context, launchAdjacent: Boolean = false): Result<Unit> = runCatching {
        val app = context.applicationContext
        check(isInstalled(app, X11_PACKAGE)) { "Instale o APK Termux:X11." }
        val intent = app.packageManager.getLaunchIntentForPackage(X11_PACKAGE)
            ?: Intent().setComponent(ComponentName(X11_PACKAGE, "com.termux.x11.MainActivity"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (launchAdjacent && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) intent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
        app.startActivity(intent)
    }

    /** Instala um pacote no mesmo ambiente selecionado para a execução gráfica. */
    fun installPythonPackage(context: Context, packageName: String): Result<Unit> = runCatching {
        val app = context.applicationContext
        check(isInstalled(app, TERMUX_PACKAGE)) { "Instale o Termux antes de gerenciar bibliotecas externas." }
        check(packageName.matches(Regex("[A-Za-z0-9][A-Za-z0-9_.-]{0,99}"))) { "Nome de pacote inválido." }
        checkRunCommandPermission(app)
        val lower = packageName.lowercase()
        val module = frameworks[lower]
        val shell = """
            set -eu
            CODEINJECTOR_PROOT_DISTRO=""
            CONFIG_FILE="${'$'}HOME/.codeinjector/termux-x11.conf"
            if [ -f "${'$'}CONFIG_FILE" ]; then . "${'$'}CONFIG_FILE"; fi
            if [ -n "${'$'}CODEINJECTOR_PROOT_DISTRO" ]; then
              case "${'$'}CODEINJECTOR_PROOT_DISTRO" in *[!a-zA-Z0-9_-]*) echo 'Nome de distro inválido.' >&2; exit 2 ;; esac
              command -v proot-distro >/dev/null 2>&1 || { echo 'Instale proot-distro: pkg install proot-distro' >&2; exit 127; }
              echo '[CodeInjector] Instalando $packageName na distro ${'$'}CODEINJECTOR_PROOT_DISTRO…'
              case '$lower' in
                tkinter) proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get update; exec proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get install -y python3-tk ;;
                kivy) proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get update; exec proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get install -y python3-kivy ;;
                pygame) proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get update; exec proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get install -y python3-pygame ;;
                pyqt5) proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get update; exec proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get install -y python3-pyqt5 ;;
                pyqt6) proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get update; exec proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get install -y python3-pyqt6 ;;
                pyglet) proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get update; exec proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get install -y python3-pyglet ;;
                *) proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get update; proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- apt-get install -y python3-pip; exec proot-distro login "${'$'}CODEINJECTOR_PROOT_DISTRO" -- python3 -m pip install --break-system-packages '$packageName' ;;
              esac
            fi
            if [ '$lower' = 'tkinter' ]; then echo '[CodeInjector] Tkinter não é um pacote pip no Python nativo do Termux. Configure Debian/PRoot e instale python3-tk.' >&2; exit 127; fi
            if [ -x "${'$'}HOME/kv/bin/python" ]; then exec "${'$'}HOME/kv/bin/python" -m pip install '$packageName'; fi
            if command -v python >/dev/null 2>&1; then exec python -m pip install '$packageName'; fi
            if command -v python3 >/dev/null 2>&1; then exec python3 -m pip install '$packageName'; fi
            echo 'Python não encontrado. Execute: pkg install python' >&2; exit 127
        """.trimIndent()
        val intent = Intent(RUN_COMMAND_ACTION).apply {
            component = ComponentName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
            putExtra(EXTRA_PATH, "\$PREFIX/bin/bash")
            putExtra(EXTRA_ARGUMENTS, arrayOf("-c", shell))
            putExtra(EXTRA_WORKDIR, "~/")
            putExtra(EXTRA_BACKGROUND, false)
            putExtra(EXTRA_SESSION_ACTION, "0")
            putExtra(EXTRA_LABEL, "Instalar biblioteca Python: $packageName")
            putExtra(EXTRA_DESCRIPTION, "Instala $packageName no ambiente gráfico escolhido pelo CodeInjector.")
        }
        startTermuxService(app, intent)
    }

    /** Encerra o grupo de processos do programa. O servidor X11 permanece vivo entre execuções. */
    fun stop(context: Context, runId: String, force: Boolean = false) {
        if (!runId.matches(Regex("[A-Za-z0-9_-]{1,64}"))) return
        val app = context.applicationContext
        if (!isInstalled(app, TERMUX_PACKAGE)) return
        val signal = if (force) "KILL" else "TERM"
        val shell = """
            PID_FILE="${'$'}HOME/.codeinjector/pids/$runId.pid"
            ACTIVE_FILE="${'$'}HOME/.codeinjector/active.pid"
            if [ -f "${'$'}PID_FILE" ]; then
              p=${'$'}(cat "${'$'}PID_FILE" 2>/dev/null || true)
              active=${'$'}(cat "${'$'}ACTIVE_FILE" 2>/dev/null || true)
              # O PID específico da execução e o active.pid precisam coincidir.
              # Não dependemos de /proc/.../environ, cuja leitura pode falhar no Android.
              if [ -n "${'$'}p" ] && [ "${'$'}p" = "${'$'}active" ] && case "${'$'}p" in *[!0-9]*|'') false ;; *) true ;; esac && kill -0 "${'$'}p" 2>/dev/null; then
                kill -$signal -- "-${'$'}p" 2>/dev/null || true
                kill -$signal "${'$'}p" 2>/dev/null || true
                if [ '$signal' = 'KILL' ]; then
                  rm -f "${'$'}PID_FILE"
                  [ "${'$'}active" = "${'$'}p" ] && rm -f "${'$'}ACTIVE_FILE"
                fi
              fi
            fi
        """.trimIndent()
        runCatching {
            val intent = Intent(RUN_COMMAND_ACTION).apply {
                component = ComponentName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
                putExtra(EXTRA_PATH, "\$PREFIX/bin/bash")
                putExtra(EXTRA_ARGUMENTS, arrayOf("-c", shell))
                putExtra(EXTRA_WORKDIR, "~/")
                putExtra(EXTRA_BACKGROUND, true)
                putExtra(EXTRA_LABEL, if (force) "Forçar encerramento CodeInjector" else "Parar CodeInjector")
            }
            startTermuxService(app, intent)
        }
    }

    private fun checkRunCommandPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= 23) {
            check(context.checkSelfPermission("com.termux.permission.RUN_COMMAND") == PackageManager.PERMISSION_GRANTED) {
                "Permissão ausente: Android → Apps → CodeInjector → Permissões adicionais → Executar comandos no Termux. No Termux, habilite allow-external-apps=true em ~/.termux/termux.properties."
            }
        }
    }

    private fun resultPendingIntent(context: Context, runId: String): PendingIntent {
        val callbackIntent = Intent(context, TermuxCommandResultReceiver::class.java)
            .setAction(TermuxCommandResultReceiver.ACTION_RESULT)
            .setData(Uri.parse("codeinjector://termux-result/$runId"))
            .putExtra(RUN_ID_EXTRA, runId)
        val flags = PendingIntent.FLAG_ONE_SHOT or if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        return PendingIntent.getBroadcast(context, UUID.randomUUID().hashCode(), callbackIntent, flags)
    }

    private fun startTermuxService(context: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
    }

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    @Suppress("DEPRECATION")
    private fun isInstalled(context: Context, packageName: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= 33) context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
        else context.packageManager.getPackageInfo(packageName, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) { false }
}
